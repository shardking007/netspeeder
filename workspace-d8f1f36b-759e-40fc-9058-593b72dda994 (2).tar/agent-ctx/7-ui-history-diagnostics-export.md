# Task 7 — History / Diagnostics / Export UI

Agent: ui-history-diagnostics-export
Task ID: 7
Scope: Build three client components for the advanced speed test UI.

## Files Created (all lint-clean)

1. `/home/z/my-project/src/components/speed-test/history-panel.tsx`
   - Props: `{ history: SpeedTestResult[]; onClear: () => void; onDelete: (id: string) => void }`
   - Recharts `LineChart` with two lines (emerald download / teal upload), x = formatted timestamp, y = Mbps
   - Custom-scrollbar scrollable list (max-h-96) of past results with timestamp, server name, download/upload/ping, NQS grade badge, per-row trash delete
   - "Clear all" button (CardAction, top-right)
   - Empty state with icon + helper text when `history.length === 0`
   - Card title "Test History" + subtitle "Your speed tests over time (saved locally)"

2. `/home/z/my-project/src/components/speed-test/diagnostics-panel.tsx`
   - Props: `{ connection: ConnectionInfo; dns: DnsResult[]; ping: PingResult }`
   - Two-column definition list (dl/dt/dd) showing: online status, effectiveType, downlink estimate, rtt, saveData, timezone, IP, ISP, location, truncated userAgent (mono)
   - Ping stats grid (min/avg/max/jitter) + received/sent + packet-loss badge
   - DNS list (max-h-44, custom scrollbar) with ms / failed per domain
   - Card title "Network Diagnostics" + subtitle "Your device & connection details"

3. `/home/z/my-project/src/components/speed-test/export-panel.tsx`
   - Props: `{ result: SpeedTestResult | null }`
   - Export JSON (Blob download, `URL.createObjectURL` + revoke on next tick)
   - Export CSV — flattened columns: `timestamp, serverName, downloadMbps, uploadMbps, pingAvg, jitter, packetLoss, nqsTotal, nqsGrade, voipMos, bufferbloatDelta`
   - Copy summary — copies human-readable summary to clipboard, `toast.success`/`toast.error`
   - Share — uses `navigator.share` if available, else clipboard fallback, with toast
   - All buttons disabled when `result === null`; muted helper text "Run a test first to enable export"
   - Card title "Export & Share" + subtitle "Save or share your results"

## Design language followed
- Every file starts with `"use client";`
- Cards: `border-border/60 bg-card/80 backdrop-blur p-5 sm:p-6`
- Labels: `text-xs font-medium uppercase tracking-wider text-muted-foreground`
- Numbers: `tabular-nums`, mono font for technical values
- Palette: emerald / teal / amber / orange / rose (NO blue/indigo primary)
- Motion entrance animations via framer-motion
- Toasts via `import { toast } from "sonner"`
- Custom scrollbar styling: `[&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border`
- Mobile-first responsive layouts

## Lint status
`bun run lint` reports 0 errors / 0 warnings in any of the 3 created files. The 3 remaining errors in lint output belong to other agents' files (speed-gauge.tsx, theme-toggle.tsx, use-speed-test.ts, engine.ts) — out of scope, untouched per instructions.

## Notes for downstream agents (Task 8 — page assembly)
- `HistoryPanel` accepts the full `SpeedTestResult[]` and lifts `onClear` / `onDelete` to the parent so the parent can re-read from `history.ts` after mutation. Recommended wiring: call `clearHistory()` / `deleteResult(id)` inside the parent's handlers and update local state with the returned array.
- `DiagnosticsPanel` is safe to render even when no test has been run yet — pass an empty `dns: []` and a synthetic zero `PingResult`; the panel already guards optional `connection` fields.
- `ExportPanel` is designed to gracefully handle `result === null` (disabled + helper text), so it can be mounted on initial render before any test runs.
