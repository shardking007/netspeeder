"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type {
  SpeedTestResult,
  ProgressEvent,
  TestPhase,
  PingResult,
  ThroughputResult,
  BufferbloatResult,
  DnsResult,
  ConnectionInfo,
} from "@/lib/speedtest/types";
import {
  runPingTest,
  runDownloadTest,
  runUploadTest,
  runBufferbloatTest,
  runDnsTest,
} from "@/lib/speedtest/engine";
import {
  computeNQS,
  predictStreaming,
  predictGaming,
  computeVoIP,
  collectConnectionInfo,
  fetchServerConnectionInfo,
} from "@/lib/speedtest/analysis";
import { getServer } from "@/lib/speedtest/servers";
import { saveResult } from "@/lib/speedtest/history";

interface UseSpeedTestState {
  phase: TestPhase;
  progress: number;
  currentMbps: number;
  currentPing: number;
  message: string;
  running: boolean;
  result: SpeedTestResult | null;
  liveDownloadSamples: ThroughputResult["samples"];
  liveUploadSamples: ThroughputResult["samples"];
  error: string | null;
}

const INITIAL_STATE: UseSpeedTestState = {
  phase: "idle",
  progress: 0,
  currentMbps: 0,
  currentPing: 0,
  message: "",
  running: false,
  result: null,
  liveDownloadSamples: [],
  liveUploadSamples: [],
  error: null,
};

export function useSpeedTest(options?: { onComplete?: (r: SpeedTestResult) => void }) {
  const onCompleteRef = useRef(options?.onComplete);
  useEffect(() => {
    onCompleteRef.current = options?.onComplete;
  });
  const [state, setState] = useState<UseSpeedTestState>(INITIAL_STATE);
  const cancelRef = useRef(false);

  const update = useCallback((patch: Partial<UseSpeedTestState>) => {
    setState((s) => ({ ...s, ...patch }));
  }, []);

  const phaseStartRef = useRef<number>(0);
  const lastPhaseRef = useRef<TestPhase>("idle");

  const onProgress = useCallback(
    (e: ProgressEvent) => {
      if (cancelRef.current) return;
      // Reset phase clock whenever the phase changes so chart x-axis = elapsed s
      const now = Date.now();
      if (e.phase !== lastPhaseRef.current) {
        lastPhaseRef.current = e.phase;
        phaseStartRef.current = now;
      }
      const elapsed = now - phaseStartRef.current;
      setState((s) => ({
        ...s,
        phase: e.phase,
        progress: e.progress,
        currentMbps: e.currentMbps ?? s.currentMbps,
        currentPing: e.currentPing ?? s.currentPing,
        message: e.message ?? s.message,
        // accumulate live samples for the chart (elapsed ms from phase start)
        liveDownloadSamples:
          (e.phase === "download" || e.phase === "bufferbloat-down") &&
          e.currentMbps !== undefined
            ? [
                ...s.liveDownloadSamples.slice(-200),
                {
                  t: elapsed,
                  mbps: e.currentMbps,
                  bytes: 0,
                },
              ]
            : s.liveDownloadSamples,
        liveUploadSamples:
          (e.phase === "upload" || e.phase === "bufferbloat-up") &&
          e.currentMbps !== undefined
            ? [
                ...s.liveUploadSamples.slice(-200),
                {
                  t: elapsed,
                  mbps: e.currentMbps,
                  bytes: 0,
                },
              ]
            : s.liveUploadSamples,
      }));
    },
    []
  );

  const abortCtrlRef = useRef<AbortController | null>(null);

  const run = useCallback(
    async (serverId: string, quickMode = false) => {
      const server = getServer(serverId);
      // Reset the cancel flag from any prior cancel so this run can proceed.
      cancelRef.current = false;
      lastPhaseRef.current = "idle";
      phaseStartRef.current = Date.now();
      // Abort any previous run's in-flight fetches before starting fresh.
      abortCtrlRef.current?.abort();
      const runAbort = new AbortController();
      abortCtrlRef.current = runAbort;
      const signal = runAbort.signal;
      setState({
        ...INITIAL_STATE,
        running: true,
        message: quickMode
          ? `Quick test via ${server.name}…`
          : `Starting test via ${server.name}…`,
      });

      try {
        // 1. Ping (fewer samples in quick mode)
        update({ phase: "ping", message: "Measuring latency & jitter…" });
        const ping: PingResult = await runPingTest(
          server.pingUrl,
          quickMode ? 8 : 18,
          onProgress,
          signal
        );

        // 2. Download (shorter duration in quick mode)
        update({
          phase: "download",
          message: "Measuring download speed…",
          currentPing: ping.avg,
          liveDownloadSamples: [],
        });
        const download: ThroughputResult = await runDownloadTest(
          server.downloadUrl,
          quickMode ? 6000 : 12000,
          onProgress,
          undefined,
          signal
        );

        // 3. Upload (shorter duration in quick mode)
        update({
          phase: "upload",
          message: "Measuring upload speed…",
          liveUploadSamples: [],
        });
        const upload: ThroughputResult = await runUploadTest(
          server.uploadUrl,
          quickMode ? 5000 : 10000,
          onProgress,
          signal
        );

        // 4. Bufferbloat (skipped in quick mode)
        let bufferbloat: BufferbloatResult;
        if (quickMode) {
          bufferbloat = {
            baselineLatency: ping.avg,
            latencyUnderLoad: ping.avg,
            delta: 0,
            grade: "A",
          };
        } else {
          update({
            phase: "bufferbloat-down",
            message: "Measuring bufferbloat…",
          });
          bufferbloat = await runBufferbloatTest(
            server.pingUrl,
            server.downloadUrl,
            server.uploadUrl,
            ping.avg,
            onProgress,
            signal
          );
        }

        // 5. DNS (skipped in quick mode)
        let dns: DnsResult[];
        if (quickMode) {
          dns = [];
        } else {
          update({ phase: "dns", message: "Testing DNS resolution…" });
          dns = await runDnsTest(onProgress, signal);
        }

        // 6. Compute composite scores & predictions
        const nqs = computeNQS(ping, download, upload, bufferbloat);
        const streaming = predictStreaming(download, ping);
        const gaming = predictGaming(ping, download, upload);
        const voip = computeVoIP(ping, download, upload);
        const connection: ConnectionInfo = {
          ...collectConnectionInfo(),
          ...(await fetchServerConnectionInfo()),
        };

        const result: SpeedTestResult = {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          timestamp: Date.now(),
          serverId: server.id,
          serverName: server.name,
          ping,
          download,
          upload,
          bufferbloat,
          dns,
          nqs,
          streaming,
          gaming,
          voip,
          connection,
        };

        saveResult(result);

        update({
          phase: "complete",
          progress: 1,
          message: "Test complete!",
          running: false,
          result,
        });
        onCompleteRef.current?.(result);
      } catch (e) {
        // If the user cancelled (or the abort signal fired), don't show an error
        const isAbort =
          cancelRef.current ||
          (e instanceof DOMException && e.name === "AbortError") ||
          (e instanceof Error && e.name === "AbortError");
        if (isAbort) {
          update({
            running: false,
            phase: "idle",
            message: "Test cancelled",
          });
        } else {
          update({
            phase: "error",
            running: false,
            error: e instanceof Error ? e.message : "Test failed",
            message: "Test failed",
          });
        }
      }
    },
    [onProgress, update]
  );

  const cancel = useCallback(() => {
    cancelRef.current = true;
    abortCtrlRef.current?.abort();
    update({ running: false, phase: "idle", message: "Test cancelled" });
  }, [update]);

  const reset = useCallback(() => {
    cancelRef.current = false;
    setState(INITIAL_STATE);
  }, []);

  return { ...state, run, cancel, reset };
}
