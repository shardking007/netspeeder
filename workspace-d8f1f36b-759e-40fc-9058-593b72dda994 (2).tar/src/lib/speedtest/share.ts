// Encode/decode a speed-test result as a compact, URL-safe base64 string so
// results can be shared via a hash fragment (e.g. #r=eyJ...).
//
// We strip large per-sample arrays before encoding to keep the URL short;
// the shared summary retains all the headline metrics, scores, and predictions.

import type { SpeedTestResult } from "./types";

export interface ShareableResult {
  v: 1; // schema version
  ts: number;
  sn: string; // server name
  d: number; // download mbps
  u: number; // upload mbps
  p: { a: number; j: number; l: number; mn: number; mx: number }; // ping: avg, jitter, loss, min, max
  n: { t: number; g: string; l: string }; // nqs: total, grade, label
  bb: { b: number; l: number; d: number; g: string }; // bufferbloat: baseline, loaded, delta, grade
  vo: { m: number; q: string; r: number }; // voip: mos, quality, rValue
  st: Array<{ p: string; r: string; c: boolean }>; // streaming: platform, resolution, canStream
  gm: Array<{ g: string; gd: string; p: boolean }>; // gaming: genre, grade, playable
  dn: Array<{ d: string; m: number; o: boolean }>; // dns: domain, ms, ok
}

export function encodeResult(result: SpeedTestResult): string {
  const shareable: ShareableResult = {
    v: 1,
    ts: result.timestamp,
    sn: result.serverName,
    d: Math.round(result.download.mbps * 100) / 100,
    u: Math.round(result.upload.mbps * 100) / 100,
    p: {
      a: Math.round(result.ping.avg * 10) / 10,
      j: Math.round(result.ping.jitter * 10) / 10,
      l: Math.round(result.ping.packetLoss * 1000) / 1000,
      mn: Math.round(result.ping.min * 10) / 10,
      mx: Math.round(result.ping.max * 10) / 10,
    },
    n: {
      t: result.nqs.total,
      g: result.nqs.grade,
      l: result.nqs.label,
    },
    bb: {
      b: Math.round(result.bufferbloat.baselineLatency),
      l: Math.round(result.bufferbloat.latencyUnderLoad),
      d: Math.round(result.bufferbloat.delta),
      g: result.bufferbloat.grade,
    },
    vo: {
      m: result.voip.mos,
      q: result.voip.quality,
      r: result.voip.rValue,
    },
    st: result.streaming.map((s) => ({
      p: s.platform,
      r: s.maxResolution,
      c: s.canStream,
    })),
    gm: result.gaming.map((g) => ({
      g: g.genre,
      gd: g.grade,
      p: g.playable,
    })),
    dn: result.dns.map((d) => ({
      d: d.domain,
      m: Math.round(d.lookupMs),
      o: d.ok,
    })),
  };

  // URL-safe base64 (replace + / and strip padding)
  const json = JSON.stringify(shareable);
  const b64 = btoa(json);
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function decodeResult(encoded: string): ShareableResult | null {
  try {
    // restore base64
    let b64 = encoded.replace(/-/g, "+").replace(/_/g, "/");
    while (b64.length % 4) b64 += "=";
    const json = atob(b64);
    const parsed = JSON.parse(json) as ShareableResult;
    if (parsed.v !== 1) return null;
    return parsed;
  } catch {
    return null;
  }
}

/** Read the shareable result from the URL hash, if present. */
export function readSharedFromHash(): ShareableResult | null {
  if (typeof window === "undefined") return null;
  const hash = window.location.hash;
  const match = hash.match(/[#&]r=([^&]+)/);
  if (!match) return null;
  return decodeResult(match[1]);
}

/** Build a shareable URL for a result (current origin + #r=...). */
export function buildShareableUrl(result: SpeedTestResult): string {
  if (typeof window === "undefined") return "";
  const encoded = encodeResult(result);
  const base = window.location.origin + window.location.pathname;
  return `${base}#r=${encoded}`;
}
