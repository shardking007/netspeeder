import type {
  PingResult,
  ThroughputResult,
  BufferbloatResult,
  NetworkQualityScore,
  QualityBreakdown,
  StreamingCapability,
  GamingGrade,
  VoIPScore,
  ConnectionInfo,
} from "./types";

// ---------------------------------------------------------------------------
// NETWORK QUALITY SCORE — composite score (0..100)
// ---------------------------------------------------------------------------

function clampScore(n: number): number {
  return Math.max(0, Math.min(100, Math.round(n)));
}

function scoreFromBandwidth(mbps: number, target: number): number {
  // log-scale saturation: full score at target, decays gracefully below.
  if (mbps >= target) return 100;
  // 50% score at target/10
  const ratio = mbps / target;
  return clampScore(100 * (Math.log10(1 + 9 * ratio) / Math.log10(1 + 9)));
}

function scoreFromLatency(ms: number): number {
  // 0 ms -> 100, 30 ms -> ~80, 100 ms -> ~50, 300+ ms -> ~10
  if (ms <= 0) return 100;
  const s = 100 - (100 * Math.log10(1 + ms)) / Math.log10(1 + 300);
  return clampScore(s);
}

function scoreFromJitter(ms: number): number {
  if (ms <= 0) return 100;
  const s = 100 - (100 * Math.log10(1 + ms)) / Math.log10(1 + 100);
  return clampScore(s);
}

function scoreFromPacketLoss(loss: number): number {
  // loss is 0..1
  if (loss <= 0) return 100;
  const s = 100 * Math.exp(-loss * 20);
  return clampScore(s);
}

function scoreFromBufferbloat(delta: number): number {
  if (delta < 5) return 100;
  if (delta < 15) return 90;
  if (delta < 30) return 75;
  if (delta < 60) return 55;
  if (delta < 120) return 35;
  return 15;
}

function gradeFromScore(score: number): NetworkQualityScore["grade"] {
  if (score >= 95) return "A+";
  if (score >= 85) return "A";
  if (score >= 70) return "B";
  if (score >= 55) return "C";
  if (score >= 40) return "D";
  return "F";
}

function labelFromScore(score: number): string {
  if (score >= 95) return "Exceptional";
  if (score >= 85) return "Excellent";
  if (score >= 70) return "Very Good";
  if (score >= 55) return "Good";
  if (score >= 40) return "Fair";
  if (score >= 25) return "Poor";
  return "Bad";
}

export function computeNQS(
  ping: PingResult,
  download: ThroughputResult,
  upload: ThroughputResult,
  bufferbloat: BufferbloatResult
): NetworkQualityScore {
  const latencyScore = scoreFromLatency(ping.avg);
  const jitterScore = scoreFromJitter(ping.jitter);
  const lossScore = scoreFromPacketLoss(ping.packetLoss);
  const downScore = scoreFromBandwidth(download.mbps, 100);
  const upScore = scoreFromBandwidth(upload.mbps, 40);
  const bloatScore = scoreFromBufferbloat(bufferbloat.delta);

  const breakdown: QualityBreakdown[] = [
    {
      label: "Latency",
      score: latencyScore,
      weight: 0.22,
      value: `${ping.avg.toFixed(1)} ms`,
    },
    {
      label: "Jitter",
      score: jitterScore,
      weight: 0.13,
      value: `${ping.jitter.toFixed(1)} ms`,
    },
    {
      label: "Packet Loss",
      score: lossScore,
      weight: 0.15,
      value: `${(ping.packetLoss * 100).toFixed(1)}%`,
    },
    {
      label: "Download",
      score: downScore,
      weight: 0.25,
      value: `${download.mbps.toFixed(1)} Mbps`,
    },
    {
      label: "Upload",
      score: upScore,
      weight: 0.15,
      value: `${upload.mbps.toFixed(1)} Mbps`,
    },
    {
      label: "Bufferbloat",
      score: bloatScore,
      weight: 0.1,
      value: `${bufferbloat.delta.toFixed(0)} ms`,
    },
  ];

  const total = clampScore(
    breakdown.reduce((sum, b) => sum + b.score * b.weight, 0)
  );

  return {
    total,
    grade: gradeFromScore(total),
    label: labelFromScore(total),
    breakdown,
  };
}

// ---------------------------------------------------------------------------
// STREAMING CAPABILITY PREDICTOR
// ---------------------------------------------------------------------------

interface StreamProfile {
  platform: string;
  tiers: { resolution: string; minDown: number; bitrate: string; rec: string }[];
}

const STREAM_PROFILES: StreamProfile[] = [
  {
    platform: "Netflix",
    tiers: [
      { resolution: "4K HDR", minDown: 25, bitrate: "15-25 Mbps", rec: "Ultra HD" },
      { resolution: "1080p", minDown: 5, bitrate: "3-5 Mbps", rec: "Full HD" },
      { resolution: "720p", minDown: 2.5, bitrate: "1.5-2.5 Mbps", rec: "HD" },
      { resolution: "480p", minDown: 1, bitrate: "0.5-1 Mbps", rec: "SD" },
    ],
  },
  {
    platform: "YouTube",
    tiers: [
      { resolution: "8K", minDown: 50, bitrate: "40-80 Mbps", rec: "Premium 8K" },
      { resolution: "4K 60fps", minDown: 20, bitrate: "15-25 Mbps", rec: "Ultra HD" },
      { resolution: "1440p", minDown: 8, bitrate: "6-10 Mbps", rec: "QHD" },
      { resolution: "1080p", minDown: 5, bitrate: "3-5 Mbps", rec: "Full HD" },
      { resolution: "720p", minDown: 2.5, bitrate: "1.5-2.5 Mbps", rec: "HD" },
    ],
  },
  {
    platform: "Disney+",
    tiers: [
      { resolution: "4K UHD", minDown: 25, bitrate: "15-25 Mbps", rec: "Ultra HD" },
      { resolution: "1080p", minDown: 5, bitrate: "3-5 Mbps", rec: "Full HD" },
      { resolution: "720p", minDown: 2.5, bitrate: "1.5-2.5 Mbps", rec: "HD" },
    ],
  },
  {
    platform: "Twitch Live",
    tiers: [
      { resolution: "1080p60", minDown: 6, bitrate: "4-6 Mbps", rec: "Live stream" },
      { resolution: "720p60", minDown: 3, bitrate: "2-3 Mbps", rec: "Live stream" },
      { resolution: "480p", minDown: 1.5, bitrate: "0.8-1.5 Mbps", rec: "Live stream" },
    ],
  },
  {
    platform: "Zoom / Video Call",
    tiers: [
      { resolution: "1080p Group", minDown: 3.5, bitrate: "3 Mbps", rec: "Group call" },
      { resolution: "720p Group", minDown: 2, bitrate: "1.5 Mbps", rec: "Group call" },
      { resolution: "1-on-1", minDown: 1, bitrate: "0.6 Mbps", rec: "Single call" },
    ],
  },
];

export function predictStreaming(
  download: ThroughputResult,
  ping: PingResult
): StreamingCapability[] {
  // Add a small safety margin (90% of measured downlink) and a latency gate
  const usableDown = download.mbps * 0.9;
  return STREAM_PROFILES.map((p) => {
    // pick the highest tier that the connection can sustain
    let chosen = p.tiers[p.tiers.length - 1];
    for (const tier of p.tiers) {
      if (usableDown >= tier.minDown) {
        chosen = tier;
        break;
      }
    }
    const canStream = usableDown >= chosen.minDown && ping.avg < 300;
    const recommendation =
      usableDown >= chosen.minDown
        ? ping.avg < 80
          ? `${chosen.rec} — smooth playback`
          : `${chosen.rec} — occasional buffering`
        : `${chosen.rec} — may buffer`;
    return {
      platform: p.platform,
      maxResolution: chosen.resolution,
      bitrate: chosen.bitrate,
      canStream,
      recommendation,
    };
  });
}

// ---------------------------------------------------------------------------
// GAMING GRADE PREDICTOR
// ---------------------------------------------------------------------------

interface GenreSpec {
  genre: string;
  maxLatency: number; // ms, beyond which unplayable
  maxJitter: number;
  minDown: number;
  minUp: number;
}

const GENRES: GenreSpec[] = [
  { genre: "Competitive FPS", maxLatency: 50, maxJitter: 10, minDown: 3, minUp: 1 },
  { genre: "Fighting Games", maxLatency: 30, maxJitter: 5, minDown: 3, minUp: 1 },
  { genre: "MOBA / RTS", maxLatency: 80, maxJitter: 20, minDown: 4, minUp: 1 },
  { genre: "MMO / RPG", maxLatency: 150, maxJitter: 30, minDown: 5, minUp: 1.5 },
  { genre: "Casual / Co-op", maxLatency: 200, maxJitter: 50, minDown: 3, minUp: 0.5 },
  { genre: "Cloud Gaming (Stadia-like)", maxLatency: 40, maxJitter: 8, minDown: 25, minUp: 5 },
];

function gameGradeFromScore(score: number): GamingGrade["grade"] {
  if (score >= 92) return "S";
  if (score >= 80) return "A";
  if (score >= 65) return "B";
  if (score >= 45) return "C";
  return "D";
}

function gameLabel(grade: GamingGrade["grade"]): string {
  switch (grade) {
    case "S":
      return "Tournament-ready";
    case "A":
      return "Excellent";
    case "B":
      return "Good";
    case "C":
      return "Playable";
    case "D":
      return "Struggling";
  }
}

export function predictGaming(
  ping: PingResult,
  download: ThroughputResult,
  upload: ThroughputResult
): GamingGrade[] {
  return GENRES.map((g) => {
    const latencyScore = Math.max(0, 1 - ping.avg / g.maxLatency);
    const jitterScore = Math.max(0, 1 - ping.jitter / g.maxJitter);
    const downScore = download.mbps >= g.minDown ? 1 : download.mbps / g.minDown;
    const upScore = upload.mbps >= g.minUp ? 1 : upload.mbps / g.minUp;
    const lossPenalty = Math.max(0, 1 - ping.packetLoss * 8);
    const score = clampScore(
      (latencyScore * 0.45 +
        jitterScore * 0.2 +
        downScore * 0.15 +
        upScore * 0.1 +
        lossPenalty * 0.1) *
        100
    );
    const grade = gameGradeFromScore(score);
    const playable =
      ping.avg <= g.maxLatency &&
      ping.jitter <= g.maxJitter &&
      download.mbps >= g.minDown &&
      upload.mbps >= g.minUp &&
      ping.packetLoss < 0.05;
    const note = playable
      ? grade === "S"
        ? "Lag-free, pro-level responsiveness"
        : "Smooth and responsive"
      : `Latency ${ping.avg.toFixed(0)}ms exceeds ${g.maxLatency}ms threshold`;
    return {
      genre: g.genre,
      grade,
      label: gameLabel(grade),
      playable,
      note,
    };
  });
}

// ---------------------------------------------------------------------------
// VoIP / MOS score — based on ITU-T G.107 E-model simplification
// ---------------------------------------------------------------------------

export function computeVoIP(
  ping: PingResult,
  download: ThroughputResult,
  upload: ThroughputResult
): VoIPScore {
  const latency = Math.max(ping.avg, 1);
  const effectiveLatency = latency + ping.jitter * 2;
  // penalty for latency (R model uses ~ late-packet penalty)
  const latencyPenalty =
    effectiveLatency < 150
      ? 0
      : (effectiveLatency - 150) / (400 - 150) * 15;
  // packet loss penalty
  const lossPenalty = ping.packetLoss * 100 * 2.5;
  // bandwidth penalty — need at least ~0.1 Mbps for voice
  const bwOk = Math.min(upload.mbps, download.mbps);
  const bwPenalty = bwOk >= 0.5 ? 0 : (0.5 - bwOk) * 40;

  const R = Math.max(0, Math.min(100, 93.2 - latencyPenalty - lossPenalty - bwPenalty));
  // MOS = 1 + 0.035*R + 7e-6 * R * (R-60) * (100-R)
  const mos = Math.max(
    1,
    Math.min(4.5, 1 + 0.035 * R + 7e-6 * R * (R - 60) * (100 - R))
  );

  let quality: VoIPScore["quality"];
  let recommendation: string;
  if (mos >= 4.2) {
    quality = "Excellent";
    recommendation = "Crystal-clear calls, no perceived delay";
  } else if (mos >= 3.8) {
    quality = "Good";
    recommendation = "Clear calls with minimal artifacts";
  } else if (mos >= 3.1) {
    quality = "Fair";
    recommendation = "Noticeable delay; some clipping possible";
  } else if (mos >= 2.2) {
    quality = "Poor";
    recommendation = "Calls may be choppy; use a wired connection";
  } else {
    quality = "Bad";
    recommendation = "Voice calls will be very degraded";
  }

  return {
    mos: Math.round(mos * 10) / 10,
    quality,
    rValue: Math.round(R),
    recommendation,
  };
}

// ---------------------------------------------------------------------------
// CONNECTION INFO
// ---------------------------------------------------------------------------

export function collectConnectionInfo(): ConnectionInfo {
  const nav = navigator as Navigator & {
    connection?: {
      effectiveType?: string;
      downlink?: number;
      rtt?: number;
      saveData?: boolean;
    };
  };
  const c = nav.connection;
  return {
    effectiveType: c?.effectiveType,
    downlink: c?.downlink,
    rtt: c?.rtt,
    saveData: c?.saveData,
    userAgent: navigator.userAgent,
    online: navigator.onLine,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  };
}

/**
 * Fetch server-side connection info (IP, region, city) from the /api/speedtest/info
 * endpoint. Returns null if the fetch fails.
 */
export async function fetchServerConnectionInfo(): Promise<{
  ip?: string;
  region?: string;
  city?: string;
  country?: string;
} | null> {
  try {
    const res = await fetch("/api/speedtest/info", { cache: "no-store" });
    if (!res.ok) return null;
    const data = await res.json();
    return {
      ip: data.ip,
      region: data.region,
      city: data.city,
      country: data.region,
    };
  } catch {
    return null;
  }
}
