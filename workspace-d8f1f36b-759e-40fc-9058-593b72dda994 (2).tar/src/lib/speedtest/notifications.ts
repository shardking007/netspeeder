// Browser Notification helper for firing native OS notifications when the
// tab is backgrounded (document.hidden === true).

export type NotificationPermission = "default" | "granted" | "denied" | "unsupported";

export function getNotificationPermission(): NotificationPermission {
  if (typeof window === "undefined" || !("Notification" in window)) {
    return "unsupported";
  }
  return Notification.permission as NotificationPermission;
}

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === "undefined" || !("Notification" in window)) {
    return "unsupported";
  }
  if (Notification.permission === "granted") return "granted";
  if (Notification.permission === "denied") return "denied";
  try {
    const result = await Notification.requestPermission();
    return result as NotificationPermission;
  } catch {
    return "denied";
  }
}

/**
 * Fire a notification. Only fires if:
 * - Notifications are supported and permitted
 * - The tab is hidden (backgrounded) — if the tab is visible, the in-app toast
 *   is sufficient and we don't want duplicate OS notifications
 */
export function fireNotification(
  title: string,
  options?: { body?: string; icon?: string; tag?: string }
): void {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  if (!document.hidden) return; // only notify when backgrounded
  try {
    const n = new Notification(title, {
      body: options?.body,
      icon: options?.icon,
      tag: options?.tag ?? "zspeed",
      silent: false,
    });
    // Focus the window on click
    n.onclick = () => {
      window.focus();
      n.close();
    };
    // Auto-close after 10s
    setTimeout(() => n.close(), 10_000);
  } catch {
    /* notification creation can fail if permissions changed */
  }
}
