import type { SpeedTestResult } from "./types";

const KEY = "zspeed_history_v1";
const MAX = 100;

type Listener = () => void;
const listeners = new Set<Listener>();

// Cached snapshot so getSnapshot returns a stable reference between changes.
// useSyncExternalStore requires referential stability to avoid render loops.
let cached: SpeedTestResult[] | null = null;
let cachedRaw: string | null = null;

function readRaw(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

function refreshCache() {
  const raw = readRaw();
  if (raw === cachedRaw && cached !== null) return cached;
  cachedRaw = raw;
  if (!raw) {
    cached = EMPTY;
    return cached;
  }
  try {
    const parsed = JSON.parse(raw) as SpeedTestResult[];
    cached = Array.isArray(parsed) ? parsed.slice(0, MAX) : EMPTY;
  } catch {
    cached = EMPTY;
  }
  return cached;
}

function notify() {
  listeners.forEach((l) => l());
}

function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  if (typeof window !== "undefined") {
    window.addEventListener("storage", onStorage);
  }
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0 && typeof window !== "undefined") {
      window.removeEventListener("storage", onStorage);
    }
  };
}

function onStorage(e: StorageEvent) {
  if (e.key === KEY) {
    cached = null;
    cachedRaw = null;
    notify();
  }
}

function getSnapshot(): SpeedTestResult[] {
  if (cached === null) refreshCache();
  return cached!;
}

function getServerSnapshot(): SpeedTestResult[] {
  return EMPTY;
}

const EMPTY: SpeedTestResult[] = [];

export const historyStore = {
  subscribe,
  getSnapshot,
  getServerSnapshot,
};

export function loadHistory(): SpeedTestResult[] {
  if (typeof window === "undefined") return [];
  return getSnapshot();
}

export function saveResult(result: SpeedTestResult): void {
  if (typeof window === "undefined") return;
  const history = getSnapshot();
  const next = [result, ...history].slice(0, MAX);
  try {
    const serialized = JSON.stringify(next);
    window.localStorage.setItem(KEY, serialized);
    cachedRaw = serialized;
    cached = next;
  } catch {
    /* quota — ignore */
  }
  notify();
}

export function clearHistory(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(KEY);
  cachedRaw = null;
  cached = EMPTY;
  notify();
}

export function deleteResult(id: string): void {
  const next = getSnapshot().filter((r) => r.id !== id);
  if (typeof window !== "undefined") {
    const serialized = JSON.stringify(next);
    window.localStorage.setItem(KEY, serialized);
    cachedRaw = serialized;
    cached = next;
  }
  notify();
}
