// Core types for the advanced speed test engine

export type TestPhase =
  | "idle"
  | "ping"
  | "download"
  | "upload"
  | "bufferbloat-down"
  | "bufferbloat-up"
  | "dns"
  | "complete"
  | "error";

export interface PingSample {
  rtt: number; // milliseconds
  timestamp: number;
}

export interface PingResult {
  min: number;
  max: number;
  avg: number;
  jitter: number; // mean abs deviation of consecutive differences
  packetLoss: number; // 0..1
  samples: PingSample[];
  sent: number;
  received: number;
}

export interface ThroughputSample {
  t: number; // elapsed ms from start of phase
  mbps: number; // instantaneous Mbps
  bytes: number; // cumulative bytes
}

export interface ThroughputResult {
  mbps: number; // final/average Mbps
  bytes: number;
  durationMs: number;
  samples: ThroughputSample[];
  peakMbps: number;
  minMbps: number;
}

export interface BufferbloatResult {
  baselineLatency: number; // avg ping with no load
  latencyUnderLoad: number; // avg ping while saturating link
  delta: number; // latencyUnderLoad - baselineLatency
  grade: "A" | "B" | "C" | "D" | "F";
}

export interface DnsResult {
  domain: string;
  lookupMs: number;
  ok: boolean;
  error?: string;
}

export interface QualityBreakdown {
  label: string;
  score: number; // 0..100
  weight: number;
  value: string;
}

export interface NetworkQualityScore {
  total: number; // 0..100
  grade: "A+" | "A" | "B" | "C" | "D" | "F";
  label: string;
  breakdown: QualityBreakdown[];
}

export interface StreamingCapability {
  platform: string;
  maxResolution: string;
  bitrate: string;
  canStream: boolean;
  recommendation: string;
}

export interface GamingGrade {
  genre: string;
  grade: "S" | "A" | "B" | "C" | "D";
  label: string;
  playable: boolean;
  note: string;
}

export interface VoIPScore {
  mos: number; // 1..5 Mean Opinion Score
  quality: "Excellent" | "Good" | "Fair" | "Poor" | "Bad";
  rValue: number; // 0..100 R-factor
  recommendation: string;
}

export interface ConnectionInfo {
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
  saveData?: boolean;
  ip?: string;
  isp?: string;
  city?: string;
  country?: string;
  timezone?: string;
  userAgent: string;
  online: boolean;
}

export interface ServerEndpoint {
  id: string;
  name: string;
  location: string;
  downloadUrl: string;
  uploadUrl: string;
  pingUrl: string;
  sponsor?: string;
  flag?: string;
}

export interface SpeedTestResult {
  id: string;
  timestamp: number;
  serverId: string;
  serverName: string;
  ping: PingResult;
  download: ThroughputResult;
  upload: ThroughputResult;
  bufferbloat: BufferbloatResult;
  dns: DnsResult[];
  nqs: NetworkQualityScore;
  streaming: StreamingCapability[];
  gaming: GamingGrade[];
  voip: VoIPScore;
  connection: ConnectionInfo;
}

export interface ProgressEvent {
  phase: TestPhase;
  progress: number; // 0..1
  currentMbps?: number;
  currentPing?: number;
  message?: string;
}

export type ProgressCallback = (e: ProgressEvent) => void;
