// Persisted user settings (selected server, theme, default test duration).
// Uses a tiny external store compatible with useSyncExternalStore.

const KEY = "zspeed_settings_v1";

export interface UserSettings {
  serverId: string;
  autoStartOnLoad: boolean;
  shareOptIn: boolean; // user agrees to use shareable links
  reducedMotion: boolean; // respect reduced motion preference
  // Scheduled auto-test
  autoTestEnabled: boolean;
  autoTestIntervalMin: number; // minutes between auto tests
  autoTestQuickMode: boolean; // use quick mode for auto tests
  autoTestLastRun: number; // timestamp of last auto-test run (0 = never)
}

const DEFAULT_SETTINGS: UserSettings = {
  serverId: "local-edge",
  autoStartOnLoad: false,
  shareOptIn: true,
  reducedMotion: false,
  autoTestEnabled: false,
  autoTestIntervalMin: 30,
  autoTestQuickMode: true,
  autoTestLastRun: 0,
};

type Listener = () => void;
const listeners = new Set<Listener>();
let cached: UserSettings | null = null;
let cachedRaw: string | null = null;

function readRaw(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

function refreshCache(): UserSettings {
  const raw = readRaw();
  if (raw === cachedRaw && cached) return cached;
  cachedRaw = raw;
  if (!raw) {
    cached = { ...DEFAULT_SETTINGS };
    return cached;
  }
  try {
    const parsed = JSON.parse(raw) as Partial<UserSettings>;
    cached = { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    cached = { ...DEFAULT_SETTINGS };
  }
  return cached;
}

function notify() {
  listeners.forEach((l) => l());
}

function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  if (typeof window !== "undefined") {
    window.addEventListener("storage", onStorage);
  }
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0 && typeof window !== "undefined") {
      window.removeEventListener("storage", onStorage);
    }
  };
}

function onStorage(e: StorageEvent) {
  if (e.key === KEY) {
    cached = null;
    cachedRaw = null;
    notify();
  }
}

function getSnapshot(): UserSettings {
  if (cached === null) refreshCache();
  return cached!;
}

function getServerSnapshot(): UserSettings {
  return DEFAULT_SETTINGS;
}

export const settingsStore = {
  subscribe,
  getSnapshot,
  getServerSnapshot,
};

export function updateSettings(patch: Partial<UserSettings>): void {
  if (typeof window === "undefined") return;
  const next = { ...getSnapshot(), ...patch };
  try {
    const serialized = JSON.stringify(next);
    window.localStorage.setItem(KEY, serialized);
    cachedRaw = serialized;
    cached = next;
  } catch {
    /* quota — ignore */
  }
  notify();
}
