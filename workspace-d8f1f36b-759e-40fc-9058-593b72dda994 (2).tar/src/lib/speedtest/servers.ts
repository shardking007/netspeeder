import type { ServerEndpoint } from "./types";

// Available test servers. We primarily use the app's own API endpoints
// (same origin -> goes through the gateway on port 3000), plus a couple of
// public CDN-based endpoints for cross-server comparison.
export const SERVERS: ServerEndpoint[] = [
  {
    id: "local-edge",
    name: "Z.ai Edge Node",
    location: "Local Gateway",
    downloadUrl: "/api/speedtest/download",
    uploadUrl: "/api/speedtest/upload",
    pingUrl: "/api/speedtest/ping",
    sponsor: "Z.ai",
    flag: "⚡",
  },
  {
    id: "cloudflare-cdn",
    name: "Cloudflare CDN",
    location: "Global Anycast",
    downloadUrl: "https://speed.cloudflare.com/__down?bytes=",
    uploadUrl: "https://speed.cloudflare.com/__up",
    pingUrl: "https://speed.cloudflare.com/__down?bytes=0",
    sponsor: "Cloudflare",
    flag: "🌐",
  },
  {
    id: "jsdelivr-cdn",
    name: "jsDelivr CDN",
    location: "Global Anycast",
    // jsDelivr serves static files; we use a known large asset for download.
    downloadUrl:
      "https://cdn.jsdelivr.net/npm/@babel/standalone@7.24.7/babel.min.js?bust=",
    uploadUrl: "/api/speedtest/upload",
    pingUrl: "https://cdn.jsdelivr.net/npm/react@18.2.0/package.json",
    sponsor: "jsDelivr",
    flag: "📦",
  },
];

export function getServer(id: string): ServerEndpoint {
  return SERVERS.find((s) => s.id === id) ?? SERVERS[0];
}
