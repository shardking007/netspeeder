// Lightweight i18n system for ZSpeed.
// Supports English (en) and Chinese (zh) with a useSyncExternalStore-compatible
// store so language changes re-render all subscribed components.

export type Lang = "en" | "zh";

export type TranslationKey = keyof typeof translations.en;

const translations = {
  en: {
    // Header
    "app.title": "ZSpeed",
    "app.subtitle": "Advanced Internet Speed Checker",
    "app.badge": "Pro",
    // Hero
    "hero.testYourConnection": "Test Your Connection",
    "hero.latestResult": "Latest Result",
    "hero.speedTest": "Speed Test",
    "hero.liveMeasurement": "Live Measurement",
    "hero.running": "Running",
    "hero.ready": "Ready",
    "hero.down": "Down",
    "hero.up": "Up",
    "hero.ping": "Ping",
    // Control panel
    "control.testServer": "Test server",
    "control.selectServer": "Select server",
    "control.quick": "Quick",
    "control.full": "Full",
    "control.startTest": "Start Test",
    "control.quickTest": "Quick Test",
    "control.stop": "Stop",
    // Phases
    "phase.measuringLatency": "Measuring latency & jitter…",
    "phase.measuringDownload": "Measuring download speed…",
    "phase.measuringUpload": "Measuring upload speed…",
    "phase.measuringBufferbloat": "Measuring bufferbloat…",
    "phase.testingDns": "Testing DNS resolution…",
    "phase.starting": "Starting test via",
    "phase.startingQuick": "Quick test via",
    "phase.testComplete": "Test complete!",
    "phase.testCancelled": "Test cancelled",
    "phase.testFailed": "Test failed",
    // Tabs
    "tab.overview": "Overview",
    "tab.quality": "Quality",
    "tab.compare": "Compare",
    "tab.streaming": "Streaming",
    "tab.gaming": "Gaming",
    "tab.voip": "VoIP",
    "tab.dns": "DNS",
    "tab.monitor": "Monitor",
    "tab.diagnostics": "Diagnostics",
    "tab.history": "History",
    "tab.export": "Export",
    // Footer
    "footer.tagline": "runs entirely in your browser. Results saved locally, never uploaded.",
    "footer.startStop": "Start/Stop",
    "footer.switchTabs": "Switch tabs",
  },
  zh: {
    // Header
    "app.title": "ZSpeed",
    "app.subtitle": "高级网络测速器",
    "app.badge": "专业版",
    // Hero
    "hero.testYourConnection": "测试您的网络",
    "hero.latestResult": "最新结果",
    "hero.speedTest": "测速",
    "hero.liveMeasurement": "实时测量中",
    "hero.running": "运行中",
    "hero.ready": "就绪",
    "hero.down": "下行",
    "hero.up": "上行",
    "hero.ping": "延迟",
    // Control panel
    "control.testServer": "测试服务器",
    "control.selectServer": "选择服务器",
    "control.quick": "快速",
    "control.full": "完整",
    "control.startTest": "开始测试",
    "control.quickTest": "快速测试",
    "control.stop": "停止",
    // Phases
    "phase.measuringLatency": "正在测量延迟与抖动…",
    "phase.measuringDownload": "正在测量下载速度…",
    "phase.measuringUpload": "正在测量上传速度…",
    "phase.measuringBufferbloat": "正在测量缓冲膨胀…",
    "phase.testingDns": "正在测试 DNS 解析…",
    "phase.starting": "通过以下服务器开始测试",
    "phase.startingQuick": "通过以下服务器快速测试",
    "phase.testComplete": "测试完成！",
    "phase.testCancelled": "测试已取消",
    "phase.testFailed": "测试失败",
    // Tabs
    "tab.overview": "概览",
    "tab.compare": "对比",
    "tab.streaming": "流媒体",
    "tab.quality": "质量",
    "tab.gaming": "游戏",
    "tab.voip": "通话",
    "tab.dns": "DNS",
    "tab.monitor": "监控",
    "tab.diagnostics": "诊断",
    "tab.history": "历史",
    "tab.export": "导出",
    // Footer
    "footer.tagline": "完全在浏览器中运行。结果保存在本地，绝不上传。",
    "footer.startStop": "开始/停止",
    "footer.switchTabs": "切换标签",
  },
};

const KEY = "zspeed_lang";
const DEFAULT_LANG: Lang = "en";

type Listener = () => void;
const listeners = new Set<Listener>();
let cachedLang: Lang | null = null;

function readLang(): Lang {
  if (typeof window === "undefined") return DEFAULT_LANG;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw === "en" || raw === "zh") return raw;
  } catch {
    /* ignore */
  }
  return DEFAULT_LANG;
}

function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  if (typeof window !== "undefined") {
    window.addEventListener("storage", onStorage);
  }
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0 && typeof window !== "undefined") {
      window.removeEventListener("storage", onStorage);
    }
  };
}

function onStorage(e: StorageEvent) {
  if (e.key === KEY) {
    cachedLang = null;
    notify();
  }
}

function notify() {
  listeners.forEach((l) => l());
}

function getSnapshot(): Lang {
  if (cachedLang === null) cachedLang = readLang();
  return cachedLang;
}

function getServerSnapshot(): Lang {
  return DEFAULT_LANG;
}

export const langStore = {
  subscribe,
  getSnapshot,
  getServerSnapshot,
};

export function setLang(lang: Lang): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, lang);
  } catch {
    /* ignore */
  }
  cachedLang = lang;
  notify();
}

export function t(key: TranslationKey, lang: Lang): string {
  return translations[lang]?.[key] ?? translations.en[key] ?? key;
}
