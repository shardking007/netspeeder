import type {
  PingResult,
  PingSample,
  ThroughputResult,
  ThroughputSample,
  ProgressCallback,
  BufferbloatResult,
  DnsResult,
  ProgressEvent,
} from "./types";

// ---------------------------------------------------------------------------
// PING
// ---------------------------------------------------------------------------

/**
 * Link an external AbortSignal to an internal AbortController so that when the
 * external signal aborts (e.g. user clicks Stop), the internal one aborts too.
 */
function linkSignal(
  internal: AbortController,
  external?: AbortSignal | null
): void {
  if (!external) return;
  if (external.aborted) {
    internal.abort();
    return;
  }
  external.addEventListener("abort", () => internal.abort(), { once: true });
}

/**
 * Send a single ping by issuing a HEAD/GET request with a cache-buster and
 * measuring the round-trip time. Returns the RTT in ms, or null on failure.
 */
async function singlePing(
  url: string,
  timeoutMs = 4000,
  externalSignal?: AbortSignal | null
): Promise<number | null> {
  const controller = new AbortController();
  linkSignal(controller, externalSignal);
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const start = performance.now();
  try {
    const bust = `${url}${url.includes("?") ? "&" : "?"}__t=${start}`;
    const res = await fetch(bust, {
      method: "GET",
      cache: "no-store",
      mode: "cors",
      signal: controller.signal,
      headers: { Accept: "application/octet-stream, */*" },
    });
    // Force read so the connection fully completes (better RTT accuracy)
    await res.arrayBuffer();
    const rtt = performance.now() - start;
    clearTimeout(timer);
    return rtt;
  } catch {
    clearTimeout(timer);
    return null;
  }
}

export async function runPingTest(
  url: string,
  count = 20,
  onProgress?: ProgressCallback,
  externalSignal?: AbortSignal | null
): Promise<PingResult> {
  const samples: PingSample[] = [];
  let sent = 0;
  let received = 0;

  // warm-up request (ignored in stats) to establish the connection
  await singlePing(url, 5000, externalSignal);

  for (let i = 0; i < count; i++) {
    if (externalSignal?.aborted) break;
    sent++;
    const rtt = await singlePing(url, 4000, externalSignal);
    if (rtt !== null) {
      received++;
      samples.push({ rtt, timestamp: Date.now() });
    }
    onProgress?.({
      phase: "ping",
      progress: (i + 1) / count,
      currentPing: rtt ?? undefined,
      message: `Pinging… ${i + 1}/${count}`,
    });
  }

  return computePingStats(samples, sent, received);
}

export function computePingStats(
  samples: PingSample[],
  sent: number,
  received: number
): PingResult {
  if (samples.length === 0) {
    return {
      min: 0,
      max: 0,
      avg: 0,
      jitter: 0,
      packetLoss: sent > 0 ? 1 : 0,
      samples: [],
      sent,
      received,
    };
  }
  const rtts = samples.map((s) => s.rtt);
  const min = Math.min(...rtts);
  const max = Math.max(...rtts);
  const avg = rtts.reduce((a, b) => a + b, 0) / rtts.length;

  // jitter = mean of absolute differences of consecutive samples
  let jitterSum = 0;
  for (let i = 1; i < rtts.length; i++) {
    jitterSum += Math.abs(rtts[i] - rtts[i - 1]);
  }
  const jitter = rtts.length > 1 ? jitterSum / (rtts.length - 1) : 0;

  return {
    min,
    max,
    avg,
    jitter,
    packetLoss: sent > 0 ? (sent - received) / sent : 0,
    samples,
    sent,
    received,
  };
}

// ---------------------------------------------------------------------------
// DOWNLOAD
// ---------------------------------------------------------------------------

/**
 * Stream-download data and report instantaneous throughput.
 * Supports both same-origin /api/speedtest/download?bytes=N endpoints and
 * external CDNs that append a byte-range as a query string.
 */
export async function runDownloadTest(
  baseUrl: string,
  durationMs = 12000,
  onProgress?: ProgressCallback,
  targetBytes?: number,
  externalSignal?: AbortSignal | null
): Promise<ThroughputResult> {
  const samples: ThroughputSample[] = [];
  const start = performance.now();

  // Choose a chunk size based on expected link speed; start small, grow.
  const CHUNK_SIZES = [256 * 1024, 1024 * 1024, 4 * 1024 * 1024, 12 * 1024 * 1024];
  let chunkIdx = 0;
  let totalBytes = 0;
  let lastReport = start;
  let lastBytes = 0;
  let peak = 0;
  let min = Infinity;
  let aborted = false;

  const abortController = new AbortController();
  linkSignal(abortController, externalSignal);

  // overall time budget
  const budgetTimer = setTimeout(() => {
    aborted = true;
    abortController.abort();
  }, durationMs);

  // if external signal already aborted, stop now
  if (externalSignal?.aborted) aborted = true;

  try {
    while (!aborted) {
      const size =
        targetBytes !== undefined
          ? Math.min(remainingForTarget(targetBytes, totalBytes), CHUNK_SIZES[Math.min(chunkIdx, CHUNK_SIZES.length - 1)])
          : CHUNK_SIZES[Math.min(chunkIdx, CHUNK_SIZES.length - 1)];

      if (size <= 0) break;

      // Build URL. Same-origin /api/speedtest/download takes ?bytes=.
      // External CDN (cloudflare) takes bytes appended to query. jsDelivr ignores.
      let url: string;
      if (baseUrl.startsWith("http")) {
        // external — append size as bytes query if it's the cloudflare pattern
        if (baseUrl.includes("__down?bytes=") || baseUrl.endsWith("=")) {
          url = `${baseUrl}${size}&__t=${start}`;
        } else {
          url = `${baseUrl}${baseUrl.includes("?") ? "&" : "?"}__t=${start}-${totalBytes}`;
        }
      } else {
        url = `${baseUrl}?bytes=${size}&__t=${start}-${totalBytes}`;
      }

      const t0 = performance.now();
      let res: Response;
      try {
        res = await fetch(url, {
          cache: "no-store",
          mode: "cors",
          signal: abortController.signal,
        });
      } catch {
        // network error or abort — stop the test
        break;
      }
      if (!res.ok && res.status !== 206) break;

      const reader = res.body?.getReader();
      if (!reader) {
        // fallback: read whole buffer
        const buf = await res.arrayBuffer();
        const now = performance.now();
        totalBytes += buf.byteLength;
        recordSample(samples, now - start, totalBytes);
        chunkIdx++;
        continue;
      }

      // stream read for accurate instantaneous throughput
      while (true) {
        if (aborted) break;
        let readResult: ReadableStreamReadResult<Uint8Array>;
        try {
          readResult = await reader.read();
        } catch {
          // abort or stream error — stop reading
          break;
        }
        const { done, value } = readResult;
        if (done) break;
        const now = performance.now();
        totalBytes += value?.byteLength ?? 0;
        if (now - lastReport >= 200) {
          const elapsed = (now - lastReport) / 1000;
          const chunk = totalBytes - lastBytes;
          const instMbps = (chunk * 8) / elapsed / 1_000_000;
          peak = Math.max(peak, instMbps);
          if (instMbps > 0) min = Math.min(min, instMbps);
          samples.push({ t: now - start, mbps: instMbps, bytes: totalBytes });
          lastReport = now;
          lastBytes = totalBytes;
          onProgress?.({
            phase: "download",
            progress: Math.min((now - start) / durationMs, 0.99),
            currentMbps: instMbps,
            message: "Downloading…",
          });
        }
        if (now - start >= durationMs) {
          aborted = true;
          break;
        }
      }
      // Release the reader's lock so the stream can be cancelled
      try {
        reader.releaseLock();
      } catch {
        /* already released */
      }
      chunkIdx++;
      if (performance.now() - start >= durationMs) {
        aborted = true;
      }
    }
  } finally {
    clearTimeout(budgetTimer);
  }

  const end = performance.now();
  const duration = end - start;
  const mbps = totalBytes > 0 ? (totalBytes * 8) / (duration / 1000) / 1_000_000 : 0;

  onProgress?.({ phase: "download", progress: 1, currentMbps: mbps });

  return {
    mbps,
    bytes: totalBytes,
    durationMs: duration,
    samples,
    peakMbps: peak === 0 ? mbps : peak,
    minMbps: min === Infinity ? mbps : min,
  };
}

function remainingForTarget(target: number, current: number): number {
  return Math.max(0, target - current);
}

// ---------------------------------------------------------------------------
// UPLOAD
// ---------------------------------------------------------------------------

export async function runUploadTest(
  uploadUrl: string,
  durationMs = 10000,
  onProgress?: ProgressCallback,
  externalSignal?: AbortSignal | null
): Promise<ThroughputResult> {
  const samples: ThroughputSample[] = [];
  const start = performance.now();
  let totalBytes = 0;
  let peak = 0;
  let min = Infinity;
  let lastReport = start;
  let lastBytes = 0;
  let aborted = false;

  const CHUNK = 1 * 1024 * 1024; // 1MB per request — balance between payload & overhead
  const payload = new Uint8Array(CHUNK);
  // fill pseudo-random (cheap) to avoid compression artefacts biasing throughput
  for (let i = 0; i < CHUNK; i += 4096) payload[i] = (i & 0xff);

  const abortController = new AbortController();
  linkSignal(abortController, externalSignal);
  const budgetTimer = setTimeout(() => {
    aborted = true;
    abortController.abort();
  }, durationMs);
  if (externalSignal?.aborted) aborted = true;

  // parallelism = 3 streams to better saturate uplink
  const STREAMS = 3;
  let streamsInFlight = 0;

  async function uploadOnce(): Promise<number> {
    if (aborted) return 0;
    streamsInFlight++;
    const t0 = performance.now();
    try {
      const res = await fetch(`${uploadUrl}?__t=${t0}-${totalBytes}`, {
        method: "POST",
        cache: "no-store",
        mode: "cors",
        signal: abortController.signal,
        headers: { "Content-Type": "application/octet-stream" },
        body: payload,
      });
      if (!res.ok) return 0;
      const now = performance.now();
      const sent = CHUNK;
      totalBytes += sent;
      if (now - lastReport >= 200) {
        const elapsed = (now - lastReport) / 1000;
        const chunk = totalBytes - lastBytes;
        const instMbps = (chunk * 8) / elapsed / 1_000_000;
        peak = Math.max(peak, instMbps);
        if (instMbps > 0) min = Math.min(min, instMbps);
        samples.push({ t: now - start, mbps: instMbps, bytes: totalBytes });
        lastReport = now;
        lastBytes = totalBytes;
        onProgress?.({
          phase: "upload",
          progress: Math.min((now - start) / durationMs, 0.99),
          currentMbps: instMbps,
          message: "Uploading…",
        });
      }
      return sent;
    } catch {
      return 0;
    } finally {
      streamsInFlight--;
    }
  }

  try {
    // Kick off streams; keep filling until budget exhausted
    const workers: Promise<void>[] = [];
    for (let s = 0; s < STREAMS; s++) {
      workers.push(
        (async () => {
          while (!aborted && performance.now() - start < durationMs) {
            await uploadOnce();
          }
        })()
      );
    }
    await Promise.all(workers);
  } finally {
    clearTimeout(budgetTimer);
    aborted = true;
  }

  const end = performance.now();
  const duration = end - start;
  const mbps = totalBytes > 0 ? (totalBytes * 8) / (duration / 1000) / 1_000_000 : 0;
  // streamsInFlight unused after; suppress lint
  void streamsInFlight;
  onProgress?.({ phase: "upload", progress: 1, currentMbps: mbps });

  return {
    mbps,
    bytes: totalBytes,
    durationMs: duration,
    samples,
    peakMbps: peak === 0 ? mbps : peak,
    minMbps: min === Infinity ? mbps : min,
  };
}

// ---------------------------------------------------------------------------
// BUFFERBLOAT — measure latency while saturating the link
// ---------------------------------------------------------------------------

export async function runBufferbloatTest(
  pingUrl: string,
  downloadUrl: string,
  uploadUrl: string,
  baseline: number,
  onProgress?: ProgressCallback,
  externalSignal?: AbortSignal | null
): Promise<BufferbloatResult> {
  // Run a ping loop concurrently with a download test, then an upload test.
  const downSamples: number[] = [];
  const upSamples: number[] = [];

  // DOWNLOAD under load (with hard timeout safety net)
  const downPromise = Promise.race([
    runDownloadTest(downloadUrl, 5000, (e) => {
      onProgress?.({
        phase: "bufferbloat-down",
        progress: e.progress * 0.5,
        currentMbps: e.currentMbps,
        message: "Measuring latency under download load…",
      });
    }, undefined, externalSignal),
    new Promise<{ mbps: number; samples: never[] }>((resolve) =>
      setTimeout(() => resolve({ mbps: 0, samples: [] }), 6000)
    ),
  ]);

  const downPing = (async () => {
    const end = performance.now() + 5000;
    while (performance.now() < end && !externalSignal?.aborted) {
      const rtt = await singlePing(pingUrl, 3000, externalSignal);
      if (rtt !== null) downSamples.push(rtt);
    }
  })();

  await Promise.all([downPromise, downPing]);

  // UPLOAD under load (with hard timeout safety net)
  const upPromise = Promise.race([
    runUploadTest(uploadUrl, 5000, (e) => {
      onProgress?.({
        phase: "bufferbloat-up",
        progress: 0.5 + e.progress * 0.5,
        currentMbps: e.currentMbps,
        message: "Measuring latency under upload load…",
      });
    }, externalSignal),
    new Promise<{ mbps: number; samples: never[] }>((resolve) =>
      setTimeout(() => resolve({ mbps: 0, samples: [] }), 6000)
    ),
  ]);

  const upPing = (async () => {
    const end = performance.now() + 5000;
    while (performance.now() < end && !externalSignal?.aborted) {
      const rtt = await singlePing(pingUrl, 3000, externalSignal);
      if (rtt !== null) upSamples.push(rtt);
    }
  })();

  await Promise.all([upPromise, upPing]);

  const downAvg = downSamples.length
    ? downSamples.reduce((a, b) => a + b, 0) / downSamples.length
    : baseline;
  const upAvg = upSamples.length
    ? upSamples.reduce((a, b) => a + b, 0) / upSamples.length
    : baseline;

  // worst-case delta drives the grade
  const downDelta = Math.max(0, downAvg - baseline);
  const upDelta = Math.max(0, upAvg - baseline);
  const worstDelta = Math.max(downDelta, upDelta);
  const latencyUnderLoad = Math.max(downAvg, upAvg);
  const delta = Math.max(0, latencyUnderLoad - baseline);

  let grade: BufferbloatResult["grade"] = "A";
  if (worstDelta < 10) grade = "A";
  else if (worstDelta < 30) grade = "B";
  else if (worstDelta < 60) grade = "C";
  else if (worstDelta < 120) grade = "D";
  else grade = "F";

  onProgress?.({ phase: "bufferbloat-up", progress: 1 });

  return {
    baselineLatency: baseline,
    latencyUnderLoad,
    delta,
    grade,
  };
}

// ---------------------------------------------------------------------------
// DNS — measure how long it takes to resolve a fresh domain
// ---------------------------------------------------------------------------

const DNS_TARGETS = [
  "google.com",
  "cloudflare.com",
  "github.com",
  "wikipedia.org",
  "youtube.com",
];

export async function runDnsTest(
  onProgress?: ProgressCallback,
  externalSignal?: AbortSignal | null
): Promise<DnsResult[]> {
  const results: DnsResult[] = [];
  // Use our own DoH proxy endpoint so timing reflects a real resolution
  // against a random subdomain (forces fresh lookups, avoids local cache).
  for (let i = 0; i < DNS_TARGETS.length; i++) {
    if (externalSignal?.aborted) break;
    const domain = DNS_TARGETS[i];
    const randomSub = `${Math.random().toString(36).slice(2)}.${domain}`;
    const start = performance.now();
    let ok = true;
    let error: string | undefined;
    try {
      const res = await fetch(
        `/api/speedtest/dns?domain=${encodeURIComponent(randomSub)}&type=A&__t=${start}`,
        { cache: "no-store", signal: externalSignal ?? undefined }
      );
      const data = await res.json();
      if (!data.ok) {
        ok = false;
        error = data.error ?? "resolution failed";
      }
    } catch (e) {
      ok = false;
      error = e instanceof Error ? e.message : "unknown error";
    }
    const lookupMs = performance.now() - start;
    results.push({ domain, lookupMs, ok, error });
    onProgress?.({
      phase: "dns",
      progress: (i + 1) / DNS_TARGETS.length,
      message: `Resolving ${domain}…`,
    });
  }
  return results;
}

// ---------------------------------------------------------------------------
// helper to record a throughput sample
// ---------------------------------------------------------------------------

function recordSample(
  samples: ThroughputSample[],
  elapsedMs: number,
  totalBytes: number
) {
  const last = samples[samples.length - 1];
  if (last) {
    const dt = (elapsedMs - last.t) / 1000;
    const db = totalBytes - last.bytes;
    if (dt > 0) {
      samples.push({
        t: elapsedMs,
        mbps: (db * 8) / dt / 1_000_000,
        bytes: totalBytes,
      });
      return;
    }
  }
  samples.push({ t: elapsedMs, mbps: 0, bytes: totalBytes });
}

export type { ProgressEvent };

// ---------------------------------------------------------------------------
// SERVER SHOWDOWN — parallel multi-server ping + quick download comparison
// ---------------------------------------------------------------------------

export interface ShowdownEntry {
  serverId: string;
  serverName: string;
  flag?: string;
  location: string;
  pingMs: number; // avg ping
  downloadMbps: number; // quick download throughput
  ok: boolean;
  error?: string;
}

export interface ShowdownProgress {
  /** 0..1 overall progress */
  progress: number;
  /** which server just reported a result */
  serverId?: string;
  message: string;
}

/**
 * Run a fast parallel comparison across all provided servers: each server
 * gets a 5-ping average + a single 2MB download, all kicked off concurrently.
 * Returns once every server has reported (or errored).
 */
export async function runServerShowdown(
  servers: Array<{
    id: string;
    name: string;
    location: string;
    flag?: string;
    pingUrl: string;
    downloadUrl: string;
  }>,
  onProgress?: (p: ShowdownProgress) => void,
  externalSignal?: AbortSignal | null
): Promise<ShowdownEntry[]> {
  const total = servers.length;
  let done = 0;

  const tasks = servers.map(async (s): Promise<ShowdownEntry> => {
    // ping + download run concurrently for this server
    const pingPromise = (async () => {
      const samples: number[] = [];
      // 4 samples + warmup
      await singlePing(s.pingUrl, 5000, externalSignal);
      for (let i = 0; i < 4; i++) {
        if (externalSignal?.aborted) break;
        const rtt = await singlePing(s.pingUrl, 3000, externalSignal);
        if (rtt !== null) samples.push(rtt);
      }
      return samples.length
        ? samples.reduce((a, b) => a + b, 0) / samples.length
        : 0;
    })();

    const downloadPromise = (async () => {
      try {
        const res = await runDownloadTest(
          s.downloadUrl,
          4000, // short — only need a rough estimate
          undefined,
          2 * 1024 * 1024, // target 2MB then stop
          externalSignal
        );
        return res.mbps;
      } catch {
        return 0;
      }
    })();

    const [pingMs, downloadMbps] = await Promise.all([pingPromise, downloadPromise]);

    done++;
    onProgress?.({
      progress: done / total,
      serverId: s.id,
      message: `${s.name} → ${downloadMbps.toFixed(1)} Mbps / ${pingMs.toFixed(
        0
      )} ms`,
    });

    return {
      serverId: s.id,
      serverName: s.name,
      flag: s.flag,
      location: s.location,
      pingMs,
      downloadMbps,
      ok: downloadMbps > 0 || pingMs > 0,
    };
  });

  return Promise.all(tasks);
}

// ---------------------------------------------------------------------------
// LIVE MONITOR — continuous ping stream with real-time stats
// ---------------------------------------------------------------------------

export interface MonitorSample {
  rtt: number | null; // null = packet lost
  timestamp: number;
}

export interface MonitorStats {
  current: number | null;
  avg: number;
  min: number;
  max: number;
  jitter: number;
  lossRate: number; // 0..1
  samples: MonitorSample[]; // recent window
  sent: number;
  received: number;
}

/**
 * Run a continuous ping monitor that calls `onSample` after each ping and
 * `onStats` with rolling stats. Runs forever until the signal aborts.
 * `intervalMs` controls the delay between pings (default 1000ms).
 * `windowSize` controls how many recent samples are kept for stats (default 60).
 */
export async function runLiveMonitor(
  url: string,
  onSample: (sample: MonitorSample, stats: MonitorStats) => void,
  options?: {
    intervalMs?: number;
    windowSize?: number;
    signal?: AbortSignal | null;
  }
): Promise<void> {
  const intervalMs = options?.intervalMs ?? 1000;
  const windowSize = options?.windowSize ?? 60;
  const signal = options?.signal ?? null;

  // warm-up
  await singlePing(url, 5000, signal);

  const samples: MonitorSample[] = [];
  let sent = 0;
  let received = 0;

  while (!signal?.aborted) {
    const rtt = await singlePing(url, 4000, signal);
    sent++;
    const sample: MonitorSample = { rtt, timestamp: Date.now() };
    if (rtt !== null) received++;
    samples.push(sample);
    if (samples.length > windowSize) samples.shift();

    const stats = computeMonitorStats(samples, sent, received);
    onSample(sample, stats);

    if (signal?.aborted) break;
    // wait for interval (interruptible)
    await new Promise<void>((resolve) => {
      const t = setTimeout(resolve, intervalMs);
      if (signal) {
        signal.addEventListener(
          "abort",
          () => {
            clearTimeout(t);
            resolve();
          },
          { once: true }
        );
      }
    });
  }
}

export function computeMonitorStats(
  samples: MonitorSample[],
  sent: number,
  received: number
): MonitorStats {
  const ok = samples.filter((s) => s.rtt !== null);
  const rtts = ok.map((s) => s.rtt as number);
  if (rtts.length === 0) {
    return {
      current: null,
      avg: 0,
      min: 0,
      max: 0,
      jitter: 0,
      lossRate: sent > 0 ? (sent - received) / sent : 0,
      samples,
      sent,
      received,
    };
  }
  const current = rtts[rtts.length - 1];
  const avg = rtts.reduce((a, b) => a + b, 0) / rtts.length;
  const min = Math.min(...rtts);
  const max = Math.max(...rtts);
  let jitterSum = 0;
  for (let i = 1; i < rtts.length; i++) {
    jitterSum += Math.abs(rtts[i] - rtts[i - 1]);
  }
  const jitter = rtts.length > 1 ? jitterSum / (rtts.length - 1) : 0;
  return {
    current,
    avg,
    min,
    max,
    jitter,
    lossRate: sent > 0 ? (sent - received) / sent : 0,
    samples,
    sent,
    received,
  };
}

