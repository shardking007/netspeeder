// Global / regional benchmark data for comparing a user's measured speed
// against common connection types and global medians.
//
// Reference points are approximate, drawn from public broadband reports
// (Ookla Speedtest Global Index, ITU, FCC Measuring Broadband America).
// They are static reference values used purely for contextual comparison.

export interface ConnectionBenchmark {
  id: string;
  name: string;
  emoji: string;
  downloadMbps: number; // typical median
  uploadMbps: number;
  latencyMs: number;
  color: string; // tailwind text color class
  description: string;
}

export const CONNECTION_BENCHMARKS: ConnectionBenchmark[] = [
  {
    id: "fiber",
    name: "Fiber (FTTH)",
    emoji: "⚡",
    downloadMbps: 950,
    uploadMbps: 950,
    latencyMs: 6,
    color: "text-emerald-500",
    description: "Symmetric gigabit fiber-to-the-home",
  },
  {
    id: "cable",
    name: "Cable (DOCSIS)",
    emoji: "🔌",
    downloadMbps: 320,
    uploadMbps: 30,
    latencyMs: 18,
    color: "text-teal-500",
    description: "Typical cable broadband hybrid fiber-coax",
  },
  {
    id: "5g",
    name: "5G Mobile",
    emoji: "📱",
    downloadMbps: 180,
    uploadMbps: 60,
    latencyMs: 25,
    color: "text-cyan-500",
    description: "Sub-6 5G cellular in good coverage",
  },
  {
    id: "starlink",
    name: "Satellite (LEO)",
    emoji: "🛰️",
    downloadMbps: 150,
    uploadMbps: 18,
    latencyMs: 42,
    color: "text-amber-500",
    description: "Low-Earth-orbit satellite (Starlink-class)",
  },
  {
    id: "global-avg",
    name: "Global Median",
    emoji: "🌍",
    downloadMbps: 95,
    uploadMbps: 40,
    latencyMs: 22,
    color: "text-violet-500",
    description: "Global median fixed broadband (Ookla index)",
  },
  {
    id: "4g",
    name: "4G LTE",
    emoji: "📶",
    downloadMbps: 35,
    uploadMbps: 9,
    latencyMs: 55,
    color: "text-orange-500",
    description: "4G LTE cellular with good signal",
  },
  {
    id: "dsl",
    name: "DSL",
    emoji: "☎️",
    downloadMbps: 18,
    uploadMbps: 3,
    latencyMs: 35,
    color: "text-rose-500",
    description: "Legacy copper DSL telephone line",
  },
  {
    id: "geo-sat",
    name: "Geostationary Sat",
    emoji: "📡",
    downloadMbps: 20,
    uploadMbps: 3,
    latencyMs: 600,
    color: "text-rose-600",
    description: "Traditional high-orbit satellite (Hughes/Viasat)",
  },
];

export interface ComparisonVerdict {
  /** which benchmark the user's download speed most closely matches */
  closest: ConnectionBenchmark;
  /** percentile ranking vs the global median download (0-100) */
  percentileGlobal: number;
  /** how many connection types the user is faster than (out of the list) */
  fasterThanCount: number;
  /** total benchmarks */
  totalBenchmarks: number;
  /** human-readable summary */
  summary: string;
}

export function compareToBenchmarks(
  downloadMbps: number,
  latencyMs: number
): ComparisonVerdict {
  // Find the closest connection type by download speed (log distance, since
  // speeds span several orders of magnitude)
  let closest = CONNECTION_BENCHMARKS[0];
  let bestDist = Infinity;
  for (const b of CONNECTION_BENCHMARKS) {
    const dist = Math.abs(
      Math.log10(Math.max(1, downloadMbps)) - Math.log10(Math.max(1, b.downloadMbps))
    );
    if (dist < bestDist) {
      bestDist = dist;
      closest = b;
    }
  }

  // Global percentile: where does the user's download fall relative to the
  // global median (95 Mbps)? Use a log-normal-ish mapping.
  const globalMedian = 95;
  const ratio = downloadMbps / globalMedian;
  // > median => above 50th percentile. We map ratio -> percentile with a
  // saturating curve so 10x median ~= 99th and 0.1x ~= ~5th.
  let percentile: number;
  if (ratio >= 1) {
    percentile = 50 + 49 * (1 - 1 / (1 + Math.log10(ratio) * 1.4));
  } else {
    percentile = 50 * (1 - 1 / (1 + Math.log10(1 / ratio) * 1.4));
  }
  percentile = Math.max(1, Math.min(99, Math.round(percentile)));

  // Count how many benchmarks the user beats on download
  const fasterThanCount = CONNECTION_BENCHMARKS.filter(
    (b) => downloadMbps >= b.downloadMbps
  ).length;

  const fasterThanGlobal = downloadMbps >= globalMedian;
  const summary = fasterThanGlobal
    ? `Faster than ${percentile}% of global connections — comparable to ${closest.name}.`
    : `Slower than the global median — comparable to ${closest.name}. Latency ${
        latencyMs <= closest.latencyMs ? "is better than" : "matches"
      } this tier.`;

  return {
    closest,
    percentileGlobal: percentile,
    fasterThanCount,
    totalBenchmarks: CONNECTION_BENCHMARKS.length,
    summary,
  };
}

/**
 * Heuristically guess the user's connection type from measured download,
 * upload, and latency. Returns the best-matching benchmark plus a confidence
 * label (high/medium/low) and an explanation.
 *
 * The heuristic uses both bandwidth AND latency so a 1 Gbps / 600ms link is
 * classified as satellite (latency dominates), not fiber.
 */
export function detectConnectionType(
  downloadMbps: number,
  uploadMbps: number,
  latencyMs: number
): {
  benchmark: ConnectionBenchmark;
  confidence: "high" | "medium" | "low";
  explanation: string;
} {
  // Refinement: if the browser exposes navigator.connection.type, use it directly
  // (high confidence). This is available in some browsers (e.g., Chrome on Android).
  if (typeof navigator !== "undefined") {
    const nav = navigator as Navigator & {
      connection?: {
        type?: string;
        effectiveType?: string;
      };
    };
    const connType = nav.connection?.type;
    if (connType && connType !== "unknown") {
      const typeMap: Record<string, string> = {
        wifi: "fiber",
        ethernet: "cable",
        cellular: "4g",
        wimax: "5g",
      };
      const targetId = typeMap[connType];
      if (targetId) {
        const benchmark = CONNECTION_BENCHMARKS.find(
          (b) => b.id === targetId
        );
        if (benchmark) {
          return {
            benchmark,
            confidence: "high",
            explanation: `Browser reports connection type "${connType}" — classified as ${benchmark.name} with high confidence.`,
          };
        }
      }
    }
  }

  // Latency gates first — these are very distinctive.
  if (latencyMs >= 300) {
    const benchmark =
      CONNECTION_BENCHMARKS.find((b) => b.id === "geo-sat")!;
    return {
      benchmark,
      confidence: "high",
      explanation: `Latency of ${Math.round(
        latencyMs
      )}ms is characteristic of high-orbit satellite — the high RTT is the giveaway, not the bandwidth.`,
    };
  }
  if (latencyMs >= 80 && downloadMbps < 200) {
    const benchmark = CONNECTION_BENCHMARKS.find((b) => b.id === "4g")!;
    return {
      benchmark,
      confidence: "medium",
      explanation: `Latency ${Math.round(
        latencyMs
      )}ms with ${Math.round(
        downloadMbps
      )} Mbps down suggests 4G LTE cellular (or a congested wireless link).`,
    };
  }

  // Symmetric-ish high bandwidth + low latency => fiber
  const symmetryRatio = uploadMbps / Math.max(downloadMbps, 1);
  if (
    downloadMbps >= 200 &&
    symmetryRatio >= 0.5 &&
    latencyMs < 25
  ) {
    const benchmark = CONNECTION_BENCHMARKS.find((b) => b.id === "fiber")!;
    return {
      benchmark,
      confidence: "high",
      explanation: `Symmetric high bandwidth (${Math.round(
        downloadMbps
      )}/${Math.round(
        uploadMbps
      )} Mbps) with low latency (${Math.round(
        latencyMs
      )}ms) is the signature of fiber-to-the-home.`,
    };
  }

  // High download + low upload + low latency => cable
  if (
    downloadMbps >= 50 &&
    downloadMbps < 800 &&
    symmetryRatio < 0.4 &&
    latencyMs < 35
  ) {
    const benchmark = CONNECTION_BENCHMARKS.find((b) => b.id === "cable")!;
    return {
      benchmark,
      confidence: "medium",
      explanation: `Asymmetric ${Math.round(
        downloadMbps
      )}/${Math.round(
        uploadMbps
      )} Mbps with ${Math.round(
        latencyMs
      )}ms latency matches typical cable/DOCSIS broadband.`,
    };
  }

  // Mid bandwidth, low-ish latency => 5G mobile
  if (
    downloadMbps >= 50 &&
    downloadMbps < 400 &&
    latencyMs >= 20 &&
    latencyMs < 60
  ) {
    const benchmark = CONNECTION_BENCHMARKS.find((b) => b.id === "5g")!;
    return {
      benchmark,
      confidence: "medium",
      explanation: `${Math.round(downloadMbps)} Mbps with ${Math.round(
        latencyMs
      )}ms latency is consistent with sub-6 5G mobile.`,
    };
  }

  // LEO satellite: moderate bandwidth + 30-80ms latency
  if (
    downloadMbps >= 50 &&
    downloadMbps < 400 &&
    latencyMs >= 30 &&
    latencyMs < 90
  ) {
    const benchmark =
      CONNECTION_BENCHMARKS.find((b) => b.id === "starlink")!;
    return {
      benchmark,
      confidence: "low",
      explanation: `${Math.round(downloadMbps)} Mbps with ${Math.round(
        latencyMs
      )}ms latency could be LEO satellite (Starlink-class) or 5G — could go either way.`,
    };
  }

  // Fallback: pick by download speed alone
  const verdict = compareToBenchmarks(downloadMbps, latencyMs);
  return {
    benchmark: verdict.closest,
    confidence: "low",
    explanation: `Best-guess match by download speed (${Math.round(
      downloadMbps
    )} Mbps) — latency ${Math.round(
      latencyMs
    )}ms doesn't strongly identify a specific tier.`,
  };
}

