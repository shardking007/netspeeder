// Formatting helpers

export function formatMbps(mbps: number): string {
  if (!isFinite(mbps) || mbps < 0) return "0.00";
  if (mbps >= 1000) return (mbps / 1000).toFixed(2) + " Gbps".replace("Gbps", "Gbps");
  if (mbps >= 100) return mbps.toFixed(1);
  return mbps.toFixed(2);
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export function formatMs(ms: number): string {
  if (!isFinite(ms) || ms < 0) return "—";
  if (ms < 10) return ms.toFixed(1) + " ms";
  return Math.round(ms) + " ms";
}

export function unitForSpeed(mbps: number): "Mbps" | "Gbps" {
  return mbps >= 1000 ? "Gbps" : "Mbps";
}

export function scaledSpeed(mbps: number): number {
  return mbps >= 1000 ? mbps / 1000 : mbps;
}
