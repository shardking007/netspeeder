"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CalendarClock,
  Play,
  Square,
  Clock,
  History,
  Zap,
  Timer,
  Settings2,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { settingsStore, updateSettings } from "@/lib/speedtest/settings";
import { useSyncExternalStore } from "react";
import { toast } from "sonner";

interface ScheduledAutoTestProps {
  /** Trigger a test run with the given quick-mode flag */
  onRunTest: (quickMode: boolean) => void;
  /** Whether a test is currently running (don't auto-trigger during a run) */
  isRunning: boolean;
}

export function ScheduledAutoTest({ onRunTest, isRunning }: ScheduledAutoTestProps) {
  const settings = useSyncExternalStore(
    settingsStore.subscribe,
    settingsStore.getSnapshot,
    settingsStore.getServerSnapshot
  );
  const [now, setNow] = useState(Date.now());
  const isRunningRef = useRef(isRunning);
  isRunningRef.current = isRunning;

  // Tick every second for the countdown display
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  // The scheduler: every 10s, check if it's time to auto-run
  useEffect(() => {
    if (!settings.autoTestEnabled) return;
    const check = setInterval(() => {
      if (isRunningRef.current) return;
      const last = settings.autoTestLastRun || 0;
      const elapsed = Date.now() - last;
      const intervalMs = settings.autoTestIntervalMin * 60 * 1000;
      if (elapsed >= intervalMs) {
        toast.info("Scheduled auto-test starting", {
          description: `Running ${settings.autoTestQuickMode ? "quick" : "full"} test automatically`,
          icon: <CalendarClock className="h-4 w-4" />,
        });
        updateSettings({ autoTestLastRun: Date.now() });
        onRunTest(settings.autoTestQuickMode);
      }
    }, 10_000);
    return () => clearInterval(check);
  }, [
    settings.autoTestEnabled,
    settings.autoTestIntervalMin,
    settings.autoTestQuickMode,
    settings.autoTestLastRun,
    onRunTest,
  ]);

  // Compute time until next run
  const intervalMs = settings.autoTestIntervalMin * 60 * 1000;
  const lastRun = settings.autoTestLastRun || 0;
  const elapsed = now - lastRun;
  const remaining = Math.max(0, intervalMs - elapsed);
  const progress = lastRun === 0 ? 0 : Math.min(1, elapsed / intervalMs);

  const fmtCountdown = (ms: number) => {
    const s = Math.ceil(ms / 1000);
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}m ${sec.toString().padStart(2, "0")}s`;
  };

  const fmtLastRun = (ts: number) => {
    if (ts === 0) return "never";
    const diff = Date.now() - ts;
    if (diff < 60_000) return "just now";
    if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
    return `${Math.floor(diff / 3_600_000)}h ago`;
  };

  const handleToggle = (enabled: boolean) => {
    updateSettings({ autoTestEnabled: enabled });
    if (enabled) {
      toast.success("Auto-test scheduled", {
        description: `Will run every ${settings.autoTestIntervalMin} min`,
        icon: <CalendarClock className="h-4 w-4" />,
      });
    } else {
      toast("Auto-test disabled");
    }
  };

  const handleRunNow = useCallback(() => {
    updateSettings({ autoTestLastRun: Date.now() });
    onRunTest(settings.autoTestQuickMode);
  }, [onRunTest, settings.autoTestQuickMode]);

  return (
    <Card
      className={`border bg-card/80 p-5 backdrop-blur transition-colors duration-300 sm:p-6 ${
        settings.autoTestEnabled
          ? "border-violet-500/40 shadow-lg shadow-violet-500/10"
          : "border-border/60"
      }`}
    >
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <CalendarClock className="h-3.5 w-3.5 text-violet-500" />
            Scheduled Auto-Test
            {settings.autoTestEnabled && (
              <motion.span
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-1 rounded-full bg-violet-500/15 px-2 py-0.5 text-[10px] font-bold text-violet-600 dark:text-violet-400"
              >
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-violet-400 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-violet-500" />
                </span>
                ACTIVE
              </motion.span>
            )}
          </div>
          <h3 className="mt-1 text-lg font-bold tracking-tight">
            Run tests automatically
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Automatically run a speed test every N minutes and log it to history
          </p>
        </div>
        <Switch
          id="auto-test-toggle"
          checked={settings.autoTestEnabled}
          onCheckedChange={handleToggle}
        />
      </div>

      <AnimatePresence>
        {settings.autoTestEnabled && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="space-y-4">
              {/* Countdown / progress */}
              <div className="rounded-lg border border-border/60 bg-background/40 p-3.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 font-medium uppercase tracking-wider text-muted-foreground">
                    <Timer className="h-3 w-3 text-violet-500" />
                    Next test in
                  </span>
                  <span className="text-sm font-bold tabular-nums text-violet-600 dark:text-violet-400">
                    {fmtCountdown(remaining)}
                  </span>
                </div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted/60">
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500"
                    style={{ width: `${progress * 100}%` }}
                    transition={{ ease: "linear" }}
                  />
                </div>
                <div className="mt-2 flex items-center justify-between text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <History className="h-2.5 w-2.5" />
                    Last: {fmtLastRun(lastRun)}
                  </span>
                  <span>Interval: {settings.autoTestIntervalMin} min</span>
                </div>
              </div>

              {/* Interval slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                  <span>Interval</span>
                  <span className="tabular-nums text-violet-600 dark:text-violet-400">
                    {settings.autoTestIntervalMin} min
                  </span>
                </div>
                <Slider
                  value={[settings.autoTestIntervalMin]}
                  onValueChange={(v) => updateSettings({ autoTestIntervalMin: v[0] })}
                  min={5}
                  max={120}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-[9px] text-muted-foreground">
                  <span>5m</span>
                  <span>30m</span>
                  <span>60m</span>
                  <span>120m</span>
                </div>
              </div>

              {/* Quick mode toggle */}
              <div className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-amber-500" />
                  <div>
                    <Label
                      htmlFor="auto-quick"
                      className="cursor-pointer text-xs font-semibold"
                    >
                      Quick mode
                    </Label>
                    <p className="text-[10px] text-muted-foreground">
                      Faster tests (~15s vs ~35s), skips bufferbloat/DNS
                    </p>
                  </div>
                </div>
                <Switch
                  id="auto-quick"
                  checked={settings.autoTestQuickMode}
                  onCheckedChange={(v) => updateSettings({ autoTestQuickMode: v })}
                />
              </div>

              {/* Run now button */}
              <Button
                onClick={handleRunNow}
                disabled={isRunning}
                className="w-full gap-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white hover:from-violet-700 hover:to-fuchsia-700"
              >
                <Play className="h-3.5 w-3.5" />
                {isRunning ? "Test running…" : "Run now & reset timer"}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!settings.autoTestEnabled && (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border/60 bg-background/30 py-6 text-center">
          <Settings2 className="mb-2 h-6 w-6 text-muted-foreground/50" />
          <p className="text-xs font-medium">Auto-test is off</p>
          <p className="mt-0.5 max-w-xs text-[10px] text-muted-foreground">
            Toggle on to run tests automatically every N minutes. Results are
            saved to your history automatically.
          </p>
        </div>
      )}
    </Card>
  );
}
