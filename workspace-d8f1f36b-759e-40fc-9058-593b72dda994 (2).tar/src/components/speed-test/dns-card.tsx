"use client";

import { motion } from "framer-motion";
import { Check, X, Globe, Server } from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatMs } from "@/lib/speedtest/format";
import type { DnsResult } from "@/lib/speedtest/types";

interface DnsCardProps {
  results: DnsResult[];
}

function lookupColorClass(ms: number): string {
  if (ms < 50) return "text-emerald-500";
  if (ms < 150) return "text-amber-500";
  return "text-rose-500";
}

function lookupBgClass(ms: number): string {
  if (ms < 50) return "bg-emerald-500";
  if (ms < 150) return "bg-amber-500";
  return "bg-rose-500";
}

export function DnsCard({ results }: DnsCardProps) {
  const okResults = results.filter((r) => r.ok && isFinite(r.lookupMs));
  const avgMs =
    okResults.length > 0
      ? okResults.reduce((s, r) => s + r.lookupMs, 0) / okResults.length
      : 0;

  const maxMs = Math.max(...okResults.map((r) => r.lookupMs), 1);

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="px-0">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <Globe className="h-4 w-4 text-muted-foreground" />
          DNS Resolution Speed
        </CardTitle>
        <CardDescription>
          How quickly each domain resolves to an IP address
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        {/* Average highlight */}
        <div className="mb-4 flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/30 px-3 py-2.5">
          <div className="flex items-center gap-2">
            <Server className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Average Lookup
            </span>
          </div>
          <span
            className={`text-2xl font-bold tabular-nums ${lookupColorClass(avgMs)}`}
          >
            {formatMs(avgMs)}
          </span>
        </div>

        {/* Mobile: card list */}
        <div className="flex flex-col gap-2 sm:hidden">
          {results.map((r, i) => (
            <motion.div
              key={r.domain + i}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, delay: i * 0.03 }}
              className="rounded-lg border border-border/60 bg-muted/20 p-3"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-sm font-medium">{r.domain}</span>
                <div
                  className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${
                    r.ok
                      ? "bg-emerald-500/15 text-emerald-500"
                      : "bg-rose-500/15 text-rose-500"
                  }`}
                >
                  {r.ok ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                </div>
              </div>
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                  <div
                    className={`h-full ${lookupBgClass(r.lookupMs)}`}
                    style={{
                      width: `${Math.min(100, (r.lookupMs / maxMs) * 100)}%`,
                    }}
                  />
                </div>
                <span
                  className={`text-xs font-semibold tabular-nums ${lookupColorClass(
                    r.lookupMs
                  )}`}
                >
                  {r.ok ? formatMs(r.lookupMs) : "failed"}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Desktop: table */}
        <div className="hidden sm:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="pl-0">Domain</TableHead>
                <TableHead className="w-32 text-right">Lookup Time</TableHead>
                <TableHead className="w-40">Relative</TableHead>
                <TableHead className="w-16 text-center pr-0">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.map((r, i) => (
                <motion.tr
                  key={r.domain + i}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25, delay: i * 0.03 }}
                  className="border-b transition-colors hover:bg-muted/50"
                >
                  <TableCell className="pl-0 font-medium">{r.domain}</TableCell>
                  <TableCell
                    className={`text-right font-semibold tabular-nums ${lookupColorClass(
                      r.lookupMs
                    )}`}
                  >
                    {r.ok ? formatMs(r.lookupMs) : "—"}
                  </TableCell>
                  <TableCell>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                      <motion.div
                        className={`h-full ${lookupBgClass(r.lookupMs)}`}
                        initial={{ width: 0 }}
                        animate={{
                          width: `${Math.min(100, (r.lookupMs / maxMs) * 100)}%`,
                        }}
                        transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 + i * 0.03 }}
                      />
                    </div>
                  </TableCell>
                  <TableCell className="pr-0 text-center">
                    <div
                      className={`mx-auto flex h-6 w-6 items-center justify-center rounded-full ${
                        r.ok
                          ? "bg-emerald-500/15 text-emerald-500"
                          : "bg-rose-500/15 text-rose-500"
                      }`}
                    >
                      {r.ok ? (
                        <Check className="h-3.5 w-3.5" />
                      ) : (
                        <X className="h-3.5 w-3.5" />
                      )}
                    </div>
                  </TableCell>
                </motion.tr>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Legend */}
        <div className="mt-4 flex flex-wrap items-center gap-4 text-[10px] text-muted-foreground">
          <span className="font-medium uppercase tracking-wider">Lookup zones:</span>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span>&lt; 50 ms</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-amber-500" />
            <span>&lt; 150 ms</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-rose-500" />
            <span>≥ 150 ms</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
