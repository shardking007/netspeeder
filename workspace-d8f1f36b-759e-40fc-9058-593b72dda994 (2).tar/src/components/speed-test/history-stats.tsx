"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import {
  Trophy,
  TrendingUp,
  TrendingDown,
  Gauge,
  Timer,
  Activity,
  History as HistoryIcon,
  Calendar,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { SpeedTestResult } from "@/lib/speedtest/types";
import { formatMbps, formatMs } from "@/lib/speedtest/format";
import { format } from "date-fns";

interface HistoryStatsProps {
  history: SpeedTestResult[];
}

export function HistoryStats({ history }: HistoryStatsProps) {
  const stats = useMemo(() => {
    if (history.length === 0) return null;
    const downloads = history.map((r) => r.download.mbps);
    const uploads = history.map((r) => r.upload.mbps);
    const pings = history.map((r) => r.ping.avg);
    const scores = history.map((r) => r.nqs.total);

    const bestDown = Math.max(...downloads);
    const bestUp = Math.max(...uploads);
    const bestPing = Math.min(...pings);
    const avgDown =
      downloads.reduce((a, b) => a + b, 0) / downloads.length;
    const avgUp = uploads.reduce((a, b) => a + b, 0) / uploads.length;
    const avgPing = pings.reduce((a, b) => a + b, 0) / pings.length;
    const avgScore =
      scores.reduce((a, b) => a + b, 0) / scores.length;
    const bestScore = Math.max(...scores);

    // Trend: compare last 3 vs previous 3
    const recent = downloads.slice(0, 3);
    const prev = downloads.slice(3, 6);
    const recentAvg = recent.length
      ? recent.reduce((a, b) => a + b, 0) / recent.length
      : 0;
    const prevAvg = prev.length
      ? prev.reduce((a, b) => a + b, 0) / prev.length
      : 0;
    const trendPct =
      prevAvg > 0 ? ((recentAvg - prevAvg) / prevAvg) * 100 : 0;

    const firstTest = history[history.length - 1];
    const lastTest = history[0];
    const spanMs = firstTest.timestamp - lastTest.timestamp;

    return {
      count: history.length,
      bestDown,
      bestUp,
      bestPing,
      avgDown,
      avgUp,
      avgPing,
      avgScore,
      bestScore,
      trendPct,
      firstTest,
      lastTest,
      spanMs,
    };
  }, [history]);

  if (!stats) {
    return null;
  }

  const trendUp = stats.trendPct > 2;
  const trendDown = stats.trendPct < -2;
  const trendFlat = Math.abs(stats.trendPct) <= 2;

  const spanHours = stats.spanMs / 3_600_000;
  const spanDays = Math.floor(spanHours / 24);
  const spanRemainingHours = Math.round(spanHours % 24);

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Trophy className="h-3.5 w-3.5 text-amber-500" />
            History Stats
          </div>
          <h3 className="mt-1 text-lg font-bold tracking-tight">
            Your testing summary
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Aggregated stats across all {stats.count} saved test
            {stats.count !== 1 ? "s" : ""}
          </p>
        </div>
        {spanHours > 0 && (
          <Badge variant="outline" className="gap-1.5">
            <Calendar className="h-3 w-3" />
            {spanDays > 0
              ? `${spanDays}d ${spanRemainingHours}h`
              : `${Math.round(spanHours)}h`}{" "}
            span
          </Badge>
        )}
      </div>

      {/* Trend banner */}
      {stats.count >= 4 && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className={`mb-4 flex items-center gap-2 rounded-lg border p-3 ${
            trendUp
              ? "border-emerald-500/30 bg-emerald-500/5"
              : trendDown
              ? "border-rose-500/30 bg-rose-500/5"
              : "border-border/60 bg-background/40"
          }`}
        >
          {trendUp ? (
            <TrendingUp className="h-4 w-4 text-emerald-500" />
          ) : trendDown ? (
            <TrendingDown className="h-4 w-4 text-rose-500" />
          ) : (
            <Activity className="h-4 w-4 text-muted-foreground" />
          )}
          <p className="text-sm leading-snug">
            {trendUp
              ? "Your connection is trending up"
              : trendDown
              ? "Your connection is trending down"
              : "Your connection is stable"}
            {Math.abs(stats.trendPct) > 2 && (
              <span
                className={`ml-1 font-bold tabular-nums ${
                  trendUp
                    ? "text-emerald-600 dark:text-emerald-400"
                    : "text-rose-600 dark:text-rose-400"
                }`}
              >
                {stats.trendPct > 0 ? "+" : ""}
                {stats.trendPct.toFixed(1)}%
              </span>
            )}
            <span className="text-muted-foreground">
              {" "}(last 3 vs previous 3 tests)
            </span>
          </p>
        </motion.div>
      )}

      {/* Best stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatTile
          icon={<Trophy className="h-3 w-3" />}
          label="Best Down"
          value={formatMbps(stats.bestDown)}
          unit="Mbps"
          color="text-emerald-500"
          accent="from-emerald-500/10"
        />
        <StatTile
          icon={<Trophy className="h-3 w-3" />}
          label="Best Up"
          value={formatMbps(stats.bestUp)}
          unit="Mbps"
          color="text-teal-500"
          accent="from-teal-500/10"
        />
        <StatTile
          icon={<Timer className="h-3 w-3" />}
          label="Best Ping"
          value={formatMs(stats.bestPing)}
          unit=""
          color="text-amber-500"
          accent="from-amber-500/10"
        />
        <StatTile
          icon={<Gauge className="h-3 w-3" />}
          label="Best NQS"
          value={`${Math.round(stats.bestScore)}`}
          unit="/100"
          color="text-violet-500"
          accent="from-violet-500/10"
        />
      </div>

      {/* Average stats */}
      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <AvgTile label="Avg Down" value={formatMbps(stats.avgDown)} unit="Mbps" />
        <AvgTile label="Avg Up" value={formatMbps(stats.avgUp)} unit="Mbps" />
        <AvgTile label="Avg Ping" value={formatMs(stats.avgPing)} unit="" />
        <AvgTile
          label="Avg NQS"
          value={`${Math.round(stats.avgScore)}`}
          unit="/100"
        />
      </div>

      {/* Footer: first/last test */}
      <div className="mt-4 flex items-center justify-between border-t border-border/60 pt-3 text-[10px] text-muted-foreground">
        <span className="flex items-center gap-1">
          <HistoryIcon className="h-2.5 w-2.5" />
          First: {format(new Date(stats.firstTest.timestamp), "MMM d, HH:mm")}
        </span>
        <span>
          Latest: {format(new Date(stats.lastTest.timestamp), "MMM d, HH:mm")}
        </span>
      </div>
    </Card>
  );
}

function StatTile({
  icon,
  label,
  value,
  unit,
  color,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit: string;
  color: string;
  accent: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={`group relative overflow-hidden rounded-xl border border-border/60 bg-gradient-to-br ${accent} to-transparent p-3`}
    >
      <div className="flex items-center gap-1 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        <span className={color}>{icon}</span>
        {label}
      </div>
      <div className="mt-1 text-xl font-bold tabular-nums sm:text-2xl">
        {value}
      </div>
      {unit && (
        <div className="text-[10px] text-muted-foreground">{unit}</div>
      )}
      <Trophy className="absolute -right-2 -top-2 h-8 w-8 text-amber-500/5 transition-colors group-hover:text-amber-500/10" />
    </motion.div>
  );
}

function AvgTile({
  label,
  value,
  unit,
}: {
  label: string;
  value: string;
  unit: string;
}) {
  return (
    <div className="rounded-xl border border-border/60 bg-background/40 p-3 text-center">
      <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className="mt-0.5 text-base font-semibold tabular-nums sm:text-lg">
        {value}
      </div>
      {unit && (
        <div className="text-[9px] text-muted-foreground">{unit}</div>
      )}
    </div>
  );
}
