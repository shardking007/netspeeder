"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { unitForSpeed, scaledSpeed, formatMs } from "@/lib/speedtest/format";

interface SpeedGaugeProps {
  value: number; // mbps
  label?: string;
  sublabel?: string;
  pingMode?: boolean;
  pingValue?: number; // ms
  active?: boolean;
}

/**
 * "Speed Tower" — a vertical liquid-fill speed display.
 * Completely replaces the circular gauge with a creative vertical approach:
 * - A glassmorphic vertical bar that fills from bottom to top
 * - Animated "liquid" surface with wave effect
 * - Large number display with count-up
 * - Tier markers on the side (like a thermometer)
 * - Rising bubble particles when active
 * - Gradient that shifts color by speed tier
 */
export function SpeedGauge({
  value,
  label = "Download",
  sublabel,
  pingMode = false,
  pingValue = 0,
  active = false,
}: SpeedGaugeProps) {
  const unit = pingMode ? "ms" : unitForSpeed(value);
  const scaled = pingMode ? pingValue : scaledSpeed(value);

  // Map value to fill ratio (0..1)
  const maxVal = pingMode ? 200 : 1000;
  const ratio = pingMode
    ? 1 - Math.min(pingValue / maxVal, 1) // lower ping = better = higher fill
    : Math.min(value / maxVal, 1);

  // Count-up animation
  const [displayValue, setDisplayValue] = useState(0);
  const targetValue = pingMode ? pingValue : scaled;
  const rafRef = useRef<number>(0);

  useEffect(() => {
    cancelAnimationFrame(rafRef.current);
    const start = displayValue;
    const diff = targetValue - start;
    if (Math.abs(diff) < 0.01) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setDisplayValue(targetValue);
      return;
    }
    const startTime = performance.now();
    const duration = 700;
    const tick = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplayValue(start + diff * eased);
      if (t < 1) {
        rafRef.current = requestAnimationFrame(tick);
      }
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [targetValue]);

  // Accent color by tier
  const accent = pingMode
    ? pingValue < 20
      ? "#10b981"
      : pingValue < 60
      ? "#14b8a6"
      : pingValue < 120
      ? "#f59e0b"
      : "#ef4444"
    : value >= 500
    ? "#10b981"
    : value >= 100
    ? "#14b8a6"
    : value >= 25
    ? "#f59e0b"
    : value >= 5
    ? "#f97316"
    : "#ef4444";

  const accentSoft = accent + "33"; // hex with low alpha
  const accentMid = accent + "66";

  const formatted = pingMode
    ? formatMs(displayValue)
    : displayValue >= 1000
    ? (displayValue / 1000).toFixed(2)
    : displayValue.toFixed(displayValue >= 100 ? 0 : 1);

  // Tier markers (like a thermometer scale)
  const tiers = pingMode
    ? [
        { label: "0", pos: 1.0 },
        { label: "50", pos: 0.75 },
        { label: "100", pos: 0.5 },
        { label: "150", pos: 0.25 },
        { label: "200", pos: 0.0 },
      ]
    : [
        { label: "0", pos: 0.0 },
        { label: "250", pos: 0.25 },
        { label: "500", pos: 0.5 },
        { label: "750", pos: 0.75 },
        { label: "1G", pos: 1.0 },
      ];

  // Bubble particles
  const BUBBLES = 8;

  // Wave animation offset
  const [waveOffset, setWaveOffset] = useState(0);
  useEffect(() => {
    if (!active) return;
    const interval = setInterval(() => {
      setWaveOffset((prev) => prev + 1);
    }, 50);
    return () => clearInterval(interval);
  }, [active]);

  // Fill height as percentage
  const fillPct = ratio * 100;

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Large number display */}
      <div className="text-center">
        <motion.div
          key={Math.round(targetValue)}
          initial={{ opacity: 0.5, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="flex items-baseline justify-center gap-2"
        >
          <span
            className="text-5xl font-black tabular-nums tracking-tight sm:text-6xl"
            style={{ color: accent }}
          >
            {formatted}
          </span>
          <span className="text-lg font-semibold text-muted-foreground">
            {unit}
          </span>
        </motion.div>
        <div className="mt-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground/60">
          {label}
        </div>
      </div>

      {/* The tower */}
      <div className="relative flex items-stretch gap-3">
        {/* Tier markers (left side) */}
        <div className="relative flex w-8 flex-col justify-between py-1">
          {tiers.map((t, i) => (
            <div key={i} className="flex items-center gap-1">
              <span className="text-[9px] font-semibold tabular-nums text-muted-foreground/50">
                {t.label}
              </span>
              <div className="h-px w-2 bg-muted-foreground/30" />
            </div>
          ))}
        </div>

        {/* The vertical bar */}
        <div
          className="relative h-[260px] w-20 overflow-hidden rounded-2xl border border-border/60 bg-muted/20 backdrop-blur sm:h-[300px] sm:w-24"
          style={{
            boxShadow: active
              ? `inset 0 0 20px ${accentSoft}, 0 0 30px ${accentSoft}`
              : `inset 0 0 10px ${accentSoft}`,
          }}
        >
          {/* Liquid fill */}
          <motion.div
            className="absolute inset-x-0 bottom-0"
            style={{
              background: `linear-gradient(to top, ${accent}, ${accentMid})`,
              boxShadow: `0 0 20px ${accent}, inset 0 0 10px ${accent}80`,
            }}
            initial={{ height: "0%" }}
            animate={{ height: `${fillPct}%` }}
            transition={{ type: "spring", stiffness: 60, damping: 15 }}
          >
            {/* Wave surface (animated SVG) */}
            <svg
              className="absolute -top-3 left-0 w-full"
              height="12"
              viewBox="0 0 100 12"
              preserveAspectRatio="none"
            >
              <motion.path
                d={`M 0 6 Q 25 ${4 + Math.sin(waveOffset * 0.3) * 2} 50 6 T 100 6 L 100 12 L 0 12 Z`}
                fill={accent}
                animate={{
                  d: [
                    `M 0 6 Q 25 ${4 + Math.sin(waveOffset * 0.3) * 2} 50 6 T 100 6 L 100 12 L 0 12 Z`,
                    `M 0 6 Q 25 ${8 + Math.sin((waveOffset + 1) * 0.3) * 2} 50 6 T 100 6 L 100 12 L 0 12 Z`,
                    `M 0 6 Q 25 ${4 + Math.sin((waveOffset + 2) * 0.3) * 2} 50 6 T 100 6 L 100 12 L 0 12 Z`,
                  ],
                }}
                transition={{ duration: 0.6, repeat: Infinity, ease: "linear" }}
              />
            </svg>

            {/* Rising bubbles when active */}
            {active && (
              <>
                {Array.from({ length: BUBBLES }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute rounded-full bg-white/40"
                    style={{
                      width: `${3 + (i % 3) * 2}px`,
                      height: `${3 + (i % 3) * 2}px`,
                      left: `${15 + (i * 11) % 70}%`,
                    }}
                    initial={{ bottom: "0%", opacity: 0 }}
                    animate={{
                      bottom: ["0%", "90%"],
                      opacity: [0, 0.8, 0],
                    }}
                    transition={{
                      duration: 2 + (i % 4) * 0.5,
                      repeat: Infinity,
                      delay: i * 0.3,
                      ease: "easeOut",
                    }}
                  />
                ))}
              </>
            )}
          </motion.div>

          {/* Glass shine overlay */}
          <div className="pointer-events-none absolute inset-0 rounded-2xl bg-gradient-to-r from-white/5 via-transparent to-white/10" />

          {/* Center reticle line (shows current level) */}
          <motion.div
            className="absolute inset-x-0 h-0.5"
            style={{
              bottom: `${fillPct}%`,
              background: `linear-gradient(to right, transparent, ${accent}, transparent)`,
            }}
            animate={{ opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        </div>

        {/* Right-side indicator arrow */}
        <div className="relative flex w-6 flex-col justify-between py-1">
          {tiers.map((t, i) => {
            const isActive = Math.abs(t.pos - ratio) < 0.06;
            return (
              <motion.div
                key={i}
                animate={{
                  x: isActive ? [0, 4, 0] : 0,
                  opacity: isActive ? 1 : 0.3,
                }}
                transition={{ duration: 0.5, repeat: isActive ? Infinity : 0 }}
                className="flex items-center"
              >
                <div
                  className="h-0 w-0"
                  style={{
                    borderTop: "4px solid transparent",
                    borderBottom: "4px solid transparent",
                    borderLeft: `6px solid ${isActive ? accent : "#6b7280"}`,
                  }}
                />
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Bottom sublabel / status */}
      <div className="text-center">
        {sublabel ? (
          <div className="text-xs text-muted-foreground">{sublabel}</div>
        ) : (
          active && (
            <motion.div
              animate={{ opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="flex items-center gap-1.5 text-xs font-medium"
              style={{ color: accent }}
            >
              <span className="relative flex h-2 w-2">
                <span
                  className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-75"
                  style={{ background: accent }}
                />
                <span
                  className="relative inline-flex h-2 w-2 rounded-full"
                  style={{ background: accent }}
                />
              </span>
              LIVE
            </motion.div>
          )
        )}
      </div>
    </div>
  );
}
