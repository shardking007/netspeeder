"use client";

import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { useEffect } from "react";
import { Gauge } from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { NetworkQualityScore } from "@/lib/speedtest/types";

interface QualityScoreCardProps {
  nqs: NetworkQualityScore;
}

function scoreColor(s: number): string {
  if (s >= 70) return "oklch(0.72 0.19 152)";
  if (s >= 40) return "oklch(0.80 0.16 80)";
  return "oklch(0.65 0.22 25)";
}

function scoreTextClass(s: number): string {
  if (s >= 70) return "text-emerald-500";
  if (s >= 40) return "text-amber-500";
  return "text-rose-500";
}

function CountUp({
  to,
  duration = 1,
}: {
  to: number;
  duration?: number;
}) {
  const count = useMotionValue(0);
  const rounded = useTransform(count, (v) => Math.round(v).toString());

  useEffect(() => {
    const controls = animate(count, to, {
      duration,
      ease: "easeOut",
    });
    return controls.stop;
  }, [to, count, duration]);

  return <motion.span>{rounded}</motion.span>;
}

export function QualityScoreCard({ nqs }: QualityScoreCardProps) {
  const { total, grade, label, breakdown } = nqs;
  const totalColor = scoreColor(total);

  // Circular ring parameters
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const arcRatio = total / 100;
  const dashOffset = circumference * (1 - arcRatio);

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="px-0">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <Gauge className="h-4 w-4 text-muted-foreground" />
          Network Quality Score
        </CardTitle>
        <CardDescription>
          Composite grade blending bandwidth, latency, jitter, loss & bufferbloat
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
          {/* Radial score display */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="relative flex h-[180px] w-[180px] shrink-0 items-center justify-center"
          >
            <svg viewBox="0 0 180 180" className="h-full w-full">
              <circle
                cx="90"
                cy="90"
                r={radius}
                fill="none"
                stroke="currentColor"
                className="text-muted/40"
                strokeWidth="12"
              />
              <motion.circle
                cx="90"
                cy="90"
                r={radius}
                fill="none"
                stroke={totalColor}
                strokeWidth="12"
                strokeLinecap="round"
                transform="rotate(-90 90 90)"
                strokeDasharray={circumference}
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset: dashOffset }}
                transition={{ duration: 1, ease: "easeOut" }}
                style={{ filter: `drop-shadow(0 0 8px ${totalColor}66)` }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-bold tabular-nums sm:text-5xl">
                <CountUp to={total} />
              </span>
              <span className="mt-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                of 100
              </span>
            </div>
            <div
              className="absolute -bottom-1 flex h-12 w-12 items-center justify-center rounded-full text-base font-bold"
              style={{
                backgroundColor: `${totalColor}1a`,
                color: totalColor,
                border: `2px solid ${totalColor}`,
              }}
            >
              {grade}
            </div>
          </motion.div>

          {/* Label + breakdown */}
          <div className="flex w-full flex-col gap-4">
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-semibold">{label}</span>
              <span className={`text-xs font-semibold ${scoreTextClass(total)}`}>
                Grade {grade}
              </span>
            </div>

            <div className="flex flex-col gap-3">
              {breakdown.map((b, i) => {
                const color = scoreColor(b.score);
                return (
                  <motion.div
                    key={b.label}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.15 + i * 0.05 }}
                    className="flex flex-col gap-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-baseline gap-2">
                        <span className="font-medium">{b.label}</span>
                        <span className="text-muted-foreground">{b.value}</span>
                      </div>
                      <div className="flex items-baseline gap-2">
                        <span
                          className="font-semibold tabular-nums"
                          style={{ color }}
                        >
                          {b.score}
                        </span>
                        <span className="text-muted-foreground">
                          w {(b.weight * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    <Progress
                      value={b.score}
                      className="h-1.5 bg-muted"
                      style={
                        {
                          // The Progress indicator uses bg-primary via class; override the
                          // indicator color through a CSS variable on the root.
                          ["--primary" as string]: color,
                        } as React.CSSProperties
                      }
                    />
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
