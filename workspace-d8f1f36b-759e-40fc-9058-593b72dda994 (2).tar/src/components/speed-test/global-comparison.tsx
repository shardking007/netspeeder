"use client";

import { motion } from "framer-motion";
import { Globe2, TrendingUp, Gauge, Sparkles, Fingerprint } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { ThroughputResult, PingResult } from "@/lib/speedtest/types";
import {
  CONNECTION_BENCHMARKS,
  compareToBenchmarks,
  detectConnectionType,
} from "@/lib/speedtest/benchmarks";
import { formatMbps } from "@/lib/speedtest/format";

interface GlobalComparisonProps {
  download: ThroughputResult;
  upload: ThroughputResult;
  ping: PingResult;
}

export function GlobalComparison({ download, upload, ping }: GlobalComparisonProps) {
  const verdict = compareToBenchmarks(download.mbps, ping.avg);
  const detection = detectConnectionType(
    download.mbps,
    upload.mbps,
    ping.avg
  );
  const userDownload = download.mbps;

  // Build a scale from the slowest to fastest benchmark for the bar chart,
  // ensuring the user's value is visible.
  const allSpeeds = [...CONNECTION_BENCHMARKS.map((b) => b.downloadMbps), userDownload];
  const maxSpeed = Math.max(...allSpeeds) * 1.1;

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Globe2 className="h-3.5 w-3.5 text-violet-500" />
            Global Comparison
          </div>
          <h3 className="mt-1 text-lg font-bold tracking-tight">
            How you compare worldwide
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Your connection vs common connection types & the global median
          </p>
        </div>
        <div className="flex flex-col items-end">
          <div className="text-3xl font-bold tabular-nums text-violet-500">
            {verdict.percentileGlobal}
            <span className="text-base text-muted-foreground">th</span>
          </div>
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Percentile
          </span>
        </div>
      </div>

      {/* Summary banner */}
      <div className="mb-5 flex items-center gap-2 rounded-lg border border-violet-500/20 bg-violet-500/5 p-3">
        <TrendingUp className="h-4 w-4 shrink-0 text-violet-500" />
        <p className="text-sm leading-snug text-foreground/90">
          {verdict.summary}
        </p>
      </div>

      {/* Auto-detect badge */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="mb-5 flex flex-col gap-2 rounded-lg border border-emerald-500/20 bg-gradient-to-br from-emerald-500/10 to-teal-500/5 p-3.5 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-500/15">
            <Fingerprint className="h-4.5 w-4.5 text-emerald-500" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              <Sparkles className="h-2.5 w-2.5" />
              Auto-detected connection
            </div>
            <div className="mt-0.5 flex items-center gap-2">
              <span className="text-base">
                {detection.benchmark.emoji}
              </span>
              <span className="text-sm font-bold">
                {detection.benchmark.name}
              </span>
              <Badge
                variant="outline"
                className={`h-4 px-1 text-[9px] ${
                  detection.confidence === "high"
                    ? "border-emerald-500/50 text-emerald-600 dark:text-emerald-400"
                    : detection.confidence === "medium"
                    ? "border-amber-500/50 text-amber-600 dark:text-amber-400"
                    : "border-muted-foreground/40 text-muted-foreground"
                }`}
              >
                {detection.confidence === "high"
                  ? "HIGH CONF"
                  : detection.confidence === "medium"
                  ? "MED CONF"
                  : "LOW CONF"}
              </Badge>
            </div>
          </div>
        </div>
        <p className="text-xs leading-snug text-muted-foreground sm:max-w-xs sm:text-right">
          {detection.explanation}
        </p>
      </motion.div>

      {/* Bar chart: user vs each connection type (log scale) */}
      <div className="space-y-2">
        {/* User's line — highlighted */}
        <ComparisonRow
          label="Your Connection"
          emoji="🎯"
          speed={userDownload}
          maxSpeed={maxSpeed}
          highlight
        />
        <div className="my-2 h-px bg-border/60" />
        {CONNECTION_BENCHMARKS.map((b, i) => (
          <ComparisonRow
            key={b.id}
            label={b.name}
            emoji={b.emoji}
            speed={b.downloadMbps}
            maxSpeed={maxSpeed}
            color={b.color}
            delay={i * 0.04}
            userSpeed={userDownload}
            description={b.description}
          />
        ))}
      </div>

      {/* Quick stats footer */}
      <div className="mt-5 grid grid-cols-3 gap-3 border-t border-border/60 pt-4">
        <Stat
          icon={<Gauge className="h-3.5 w-3.5" />}
          label="Your Download"
          value={`${formatMbps(userDownload)} Mbps`}
        />
        <Stat
          icon={<TrendingUp className="h-3.5 w-3.5" />}
          label="Faster than"
          value={`${verdict.fasterThanCount}/${verdict.totalBenchmarks} types`}
        />
        <Stat
          icon={<Globe2 className="h-3.5 w-3.5" />}
          label="Closest tier"
          value={`${verdict.closest.emoji} ${verdict.closest.name}`}
        />
      </div>
    </Card>
  );
}

function ComparisonRow({
  label,
  emoji,
  speed,
  maxSpeed,
  color = "text-foreground",
  highlight = false,
  delay = 0,
  userSpeed,
  description,
}: {
  label: string;
  emoji: string;
  speed: number;
  maxSpeed: number;
  color?: string;
  highlight?: boolean;
  delay?: number;
  userSpeed?: number;
  description?: string;
}) {
  // log scale so we can compare fiber (950) to DSL (18) on one bar
  const logMax = Math.log10(maxSpeed);
  const logSpeed = Math.log10(Math.max(1, speed));
  const widthPct = Math.max(2, (logSpeed / logMax) * 100);

  const isUserFaster = userSpeed !== undefined && userSpeed >= speed;

  return (
    <div className="flex items-center gap-3">
      <div className="flex w-32 shrink-0 items-center gap-1.5 sm:w-40">
        <span className="text-sm">{emoji}</span>
        <span
          className={`truncate text-xs font-medium sm:text-sm ${
            highlight ? "font-bold text-violet-500" : "text-foreground/80"
          }`}
        >
          {label}
        </span>
      </div>
      <div className="relative h-7 flex-1 overflow-hidden rounded-md bg-muted/40">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${widthPct}%` }}
          transition={{ duration: 0.6, delay, ease: "easeOut" }}
          className={`flex h-full items-center justify-end rounded-md pr-2 ${
            highlight
              ? "bg-gradient-to-r from-violet-500 to-fuchsia-500"
              : isUserFaster
              ? "bg-muted-foreground/40"
              : "bg-emerald-500/70"
          }`}
        >
          <span
            className={`text-[10px] font-semibold tabular-nums ${
              highlight || !isUserFaster ? "text-white" : "text-foreground/70"
            }`}
          >
            {formatMbps(speed)}
          </span>
        </motion.div>
      </div>
      <div className="hidden w-8 text-right sm:block">
        {userSpeed !== undefined && !highlight && (
          <Badge
            variant="outline"
            className={`h-5 px-1 text-[9px] ${
              isUserFaster
                ? "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                : "border-rose-500/40 text-rose-600 dark:text-rose-400"
            }`}
          >
            {isUserFaster ? "WIN" : "LOSE"}
          </Badge>
        )}
      </div>
      {description && (
        <div className="hidden text-[10px] text-muted-foreground lg:block lg:w-44 xl:w-52">
          {description}
        </div>
      )}
    </div>
  );
}

function Stat({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-border/60 bg-background/40 p-2.5">
      <div className="flex items-center gap-1 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className="mt-1 truncate text-sm font-semibold tabular-nums">{value}</div>
    </div>
  );
}
