"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  GitCompareArrows,
  ArrowDown,
  ArrowUp,
  Timer,
  Activity,
  Shield,
  Trophy,
  Minus,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { SpeedTestResult } from "@/lib/speedtest/types";
import { formatMbps, formatMs } from "@/lib/speedtest/format";
import { format } from "date-fns";

interface ResultsComparisonProps {
  history: SpeedTestResult[];
}

const GRADE_COLOR: Record<string, string> = {
  "A+": "text-emerald-500",
  A: "text-emerald-500",
  B: "text-teal-500",
  C: "text-amber-500",
  D: "text-orange-500",
  F: "text-rose-500",
};

export function ResultsComparison({ history }: ResultsComparisonProps) {
  const [leftId, setLeftId] = useState<string>(history[0]?.id ?? "");
  const [rightId, setRightId] = useState<string>(
    history[1]?.id ?? history[0]?.id ?? ""
  );

  const left = useMemo(
    () => history.find((r) => r.id === leftId),
    [history, leftId]
  );
  const right = useMemo(
    () => history.find((r) => r.id === rightId),
    [history, rightId]
  );

  if (history.length < 2) {
    return (
      <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <GitCompareArrows className="mb-2 h-8 w-8 text-muted-foreground/50" />
          <p className="text-sm font-medium">Need at least 2 results to compare</p>
          <p className="mt-1 max-w-xs text-xs text-muted-foreground">
            Run a few tests, then come back here to see a side-by-side diff of
            your connection over time.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <GitCompareArrows className="h-3.5 w-3.5 text-fuchsia-500" />
            Results Comparison
          </div>
          <h3 className="mt-1 text-lg font-bold tracking-tight">
            Compare two tests side-by-side
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            See how your connection changed between runs
          </p>
        </div>
      </div>

      {/* Selectors */}
      <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Test A
          </label>
          <Select value={leftId} onValueChange={setLeftId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select result A" />
            </SelectTrigger>
            <SelectContent>
              {history.map((r) => (
                <SelectItem key={r.id} value={r.id} disabled={r.id === rightId}>
                  {format(new Date(r.timestamp), "MMM d, HH:mm:ss")} ·{" "}
                  {formatMbps(r.download.mbps)} Mbps
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="mb-1 block text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Test B
          </label>
          <Select value={rightId} onValueChange={setRightId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select result B" />
            </SelectTrigger>
            <SelectContent>
              {history.map((r) => (
                <SelectItem key={r.id} value={r.id} disabled={r.id === leftId}>
                  {format(new Date(r.timestamp), "MMM d, HH:mm:ss")} ·{" "}
                  {formatMbps(r.download.mbps)} Mbps
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {left && right && (
        <AnimatePresence mode="wait">
          <motion.div
            key={`${leftId}-${rightId}`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-3"
          >
            {/* Timestamp row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border border-border/60 bg-background/40 p-3">
                <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                  Test A
                </div>
                <div className="mt-0.5 text-sm font-semibold">
                  {format(new Date(left.timestamp), "MMM d, yyyy · HH:mm:ss")}
                </div>
                <div className="text-xs text-muted-foreground">
                  {left.serverName}
                </div>
              </div>
              <div className="rounded-lg border border-border/60 bg-background/40 p-3">
                <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                  Test B
                </div>
                <div className="mt-0.5 text-sm font-semibold">
                  {format(new Date(right.timestamp), "MMM d, yyyy · HH:mm:ss")}
                </div>
                <div className="text-xs text-muted-foreground">
                  {right.serverName}
                </div>
              </div>
            </div>

            {/* Metric comparisons */}
            <ComparisonRow
              icon={<ArrowDown className="h-3.5 w-3.5" />}
              label="Download"
              left={left.download.mbps}
              right={right.download.mbps}
              format={formatMbps}
              unit="Mbps"
              higherBetter
            />
            <ComparisonRow
              icon={<ArrowUp className="h-3.5 w-3.5" />}
              label="Upload"
              left={left.upload.mbps}
              right={right.upload.mbps}
              format={formatMbps}
              unit="Mbps"
              higherBetter
            />
            <ComparisonRow
              icon={<Timer className="h-3.5 w-3.5" />}
              label="Ping (avg)"
              left={left.ping.avg}
              right={right.ping.avg}
              format={(v) => formatMs(v)}
              unit=""
              higherBetter={false}
            />
            <ComparisonRow
              icon={<Activity className="h-3.5 w-3.5" />}
              label="Jitter"
              left={left.ping.jitter}
              right={right.ping.jitter}
              format={(v) => formatMs(v)}
              unit=""
              higherBetter={false}
            />
            <ComparisonRow
              icon={<Shield className="h-3.5 w-3.5" />}
              label="NQS Score"
              left={left.nqs.total}
              right={right.nqs.total}
              format={(v) => `${Math.round(v)}`}
              unit="/100"
              higherBetter
            />
            <ComparisonRow
              icon={<Activity className="h-3.5 w-3.5" />}
              label="VoIP MOS"
              left={left.voip.mos}
              right={right.voip.mos}
              format={(v) => v.toFixed(1)}
              unit="/5"
              higherBetter
            />

            {/* Grade summary */}
            <div className="grid grid-cols-2 gap-3 border-t border-border/60 pt-4">
              <div className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
                <div>
                  <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                    Test A grade
                  </div>
                  <div
                    className={`text-2xl font-bold ${GRADE_COLOR[left.nqs.grade] ?? ""}`}
                  >
                    {left.nqs.grade}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  {left.nqs.label}
                </div>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
                <div>
                  <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                    Test B grade
                  </div>
                  <div
                    className={`text-2xl font-bold ${GRADE_COLOR[right.nqs.grade] ?? ""}`}
                  >
                    {right.nqs.grade}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  {right.nqs.label}
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      )}
    </Card>
  );
}

function ComparisonRow({
  icon,
  label,
  left,
  right,
  format: fmt,
  unit,
  higherBetter,
}: {
  icon: React.ReactNode;
  label: string;
  left: number;
  right: number;
  format: (v: number) => string;
  unit: string;
  higherBetter: boolean;
}) {
  const delta = right - left;
  const pctChange = left !== 0 ? (delta / Math.abs(left)) * 100 : 0;
  const improved = higherBetter ? delta > 0 : delta < 0;
  const worsened = higherBetter ? delta < 0 : delta > 0;
  const neutral = Math.abs(delta) < 0.01;

  const winnerLeft = improved ? false : worsened ? true : null;

  return (
    <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3 rounded-lg border border-border/60 bg-background/40 p-3">
      {/* Left value */}
      <div
        className={`text-right ${
          winnerLeft === true
            ? "text-emerald-500"
            : winnerLeft === false
            ? "text-muted-foreground"
            : ""
        }`}
      >
        <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        <div className="text-lg font-bold tabular-nums sm:text-xl">
          {fmt(left)}
          {unit && (
            <span className="ml-1 text-[10px] font-normal text-muted-foreground">
              {unit}
            </span>
          )}
        </div>
      </div>

      {/* Delta */}
      <div className="flex flex-col items-center">
        <div
          className={`flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold ${
            neutral
              ? "bg-muted text-muted-foreground"
              : improved
              ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
              : "bg-rose-500/15 text-rose-600 dark:text-rose-400"
          }`}
        >
          {neutral ? (
            <Minus className="h-2.5 w-2.5" />
          ) : improved ? (
            <TrendingUp className="h-2.5 w-2.5" />
          ) : (
            <TrendingDown className="h-2.5 w-2.5" />
          )}
          {neutral
            ? "0%"
            : `${pctChange > 0 ? "+" : ""}${pctChange.toFixed(1)}%`}
        </div>
        <div className="mt-0.5 flex items-center gap-1 text-[9px] uppercase tracking-wider text-muted-foreground">
          {icon}
          {label}
        </div>
      </div>

      {/* Right value */}
      <div
        className={`text-left ${
          winnerLeft === false
            ? "text-emerald-500"
            : winnerLeft === true
            ? "text-muted-foreground"
            : ""
        }`}
      >
        <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        <div className="text-lg font-bold tabular-nums sm:text-xl">
          {fmt(right)}
          {unit && (
            <span className="ml-1 text-[10px] font-normal text-muted-foreground">
              {unit}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
