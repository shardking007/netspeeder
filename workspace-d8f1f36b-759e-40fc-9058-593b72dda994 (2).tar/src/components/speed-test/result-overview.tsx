"use client";

import { motion } from "framer-motion";
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  Activity,
  Waves,
  PackageX,
} from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { formatMbps, formatMs } from "@/lib/speedtest/format";
import type { SpeedTestResult } from "@/lib/speedtest/types";

interface ResultOverviewProps {
  result: SpeedTestResult;
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit?: string;
  sublabel: string;
  accent: string;
}

function StatCard({
  icon,
  label,
  value,
  unit,
  sublabel,
  accent,
}: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="relative flex flex-col gap-2 rounded-xl border border-border/60 bg-card/80 p-4 backdrop-blur"
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <span
          className="flex h-7 w-7 items-center justify-center rounded-md"
          style={{ backgroundColor: `${accent}1a`, color: accent }}
        >
          {icon}
        </span>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="text-3xl font-bold tabular-nums sm:text-4xl">
          {value}
        </span>
        {unit && (
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            {unit}
          </span>
        )}
      </div>
      <span className="text-xs text-muted-foreground">{sublabel}</span>
    </motion.div>
  );
}

export function ResultOverview({ result }: ResultOverviewProps) {
  const { download, upload, ping } = result;

  const stats: StatCardProps[] = [
    {
      icon: <ArrowDownToLine className="h-4 w-4" />,
      label: "Download",
      value: formatMbps(download.mbps),
      unit: download.mbps >= 1000 ? "Gbps" : "Mbps",
      sublabel: `peak ${formatMbps(download.peakMbps)} Mbps`,
      accent: "oklch(0.72 0.19 152)",
    },
    {
      icon: <ArrowUpFromLine className="h-4 w-4" />,
      label: "Upload",
      value: formatMbps(upload.mbps),
      unit: upload.mbps >= 1000 ? "Gbps" : "Mbps",
      sublabel: `peak ${formatMbps(upload.peakMbps)} Mbps`,
      accent: "oklch(0.78 0.18 180)",
    },
    {
      icon: <Activity className="h-4 w-4" />,
      label: "Ping",
      value: formatMs(ping.avg).replace(" ms", ""),
      unit: "ms",
      sublabel: `min ${formatMs(ping.min).replace(" ms", "")} ms`,
      accent: "oklch(0.80 0.16 80)",
    },
    {
      icon: <Waves className="h-4 w-4" />,
      label: "Jitter",
      value: ping.jitter < 10 ? ping.jitter.toFixed(1) : Math.round(ping.jitter).toString(),
      unit: "ms",
      sublabel: `max ${formatMs(ping.max).replace(" ms", "")} ms`,
      accent: "oklch(0.75 0.18 130)",
    },
    {
      icon: <PackageX className="h-4 w-4" />,
      label: "Packet Loss",
      value: (ping.packetLoss * 100).toFixed(ping.packetLoss < 0.01 ? 2 : 1),
      unit: "%",
      sublabel: `${ping.received}/${ping.sent} packets received`,
      accent:
        ping.packetLoss < 0.01
          ? "oklch(0.72 0.19 152)"
          : ping.packetLoss < 0.05
            ? "oklch(0.80 0.16 80)"
            : "oklch(0.65 0.22 25)",
    },
  ];

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="px-0">
        <CardTitle className="text-base font-semibold">Test Results</CardTitle>
        <CardDescription>
          Headline measurements from the latest speed test
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {stats.map((s) => (
            <StatCard key={s.label} {...s} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
