"use client";

import { motion } from "framer-motion";
import {
  Activity,
  Clock,
  Globe,
  Wifi,
  WifiOff,
  Network as NetworkIcon,
  Save,
  Server,
  Timer,
  Monitor,
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { ConnectionInfo, DnsResult, PingResult } from "@/lib/speedtest/types";
import { formatMs } from "@/lib/speedtest/format";

interface DiagnosticsPanelProps {
  connection: ConnectionInfo;
  dns: DnsResult[];
  ping: PingResult;
}

interface Row {
  label: string;
  value: string;
  icon: React.ReactNode;
  mono?: boolean;
  truncate?: boolean;
}

function effectiveTypeLabel(t?: string): string {
  if (!t) return "Unknown";
  const map: Record<string, string> = {
    "slow-2g": "Slow 2G",
    "2g": "2G",
    "3g": "3G",
    "4g": "4G",
  };
  return map[t] ?? t.toUpperCase();
}

export function DiagnosticsPanel({
  connection,
  dns,
  ping,
}: DiagnosticsPanelProps) {
  const rows: Row[] = [
    {
      label: "Online status",
      value: connection.online ? "Online" : "Offline",
      icon: connection.online ? (
        <Wifi className="h-3.5 w-3.5 text-emerald-500" />
      ) : (
        <WifiOff className="h-3.5 w-3.5 text-rose-500" />
      ),
    },
    {
      label: "Effective type",
      value: effectiveTypeLabel(connection.effectiveType),
      icon: <NetworkIcon className="h-3.5 w-3.5 text-teal-500" />,
      mono: true,
    },
    {
      label: "Downlink estimate",
      value:
        typeof connection.downlink === "number"
          ? `${connection.downlink.toFixed(1)} Mbps`
          : "Unknown",
      icon: <Activity className="h-3.5 w-3.5 text-emerald-500" />,
      mono: true,
    },
    {
      label: "Round-trip time",
      value:
        typeof connection.rtt === "number" ? formatMs(connection.rtt) : "Unknown",
      icon: <Timer className="h-3.5 w-3.5 text-amber-500" />,
      mono: true,
    },
    {
      label: "Save-Data",
      value:
        typeof connection.saveData === "boolean"
          ? connection.saveData
            ? "Enabled"
            : "Disabled"
          : "Unknown",
      icon: <Save className="h-3.5 w-3.5 text-orange-500" />,
    },
    {
      label: "Timezone",
      value: connection.timezone || "Unknown",
      icon: <Clock className="h-3.5 w-3.5 text-teal-500" />,
      mono: true,
    },
    ...(connection.ip
      ? [
          {
            label: "IP address",
            value: connection.ip,
            icon: <Globe className="h-3.5 w-3.5 text-emerald-500" />,
            mono: true,
          } as Row,
        ]
      : []),
    ...(connection.isp
      ? [
          {
            label: "ISP",
            value: connection.isp,
            icon: <Server className="h-3.5 w-3.5 text-amber-500" />,
          } as Row,
        ]
      : []),
    ...(connection.city || connection.country
      ? [
          {
            label: "Location",
            value: [connection.city, connection.country]
              .filter(Boolean)
              .join(", "),
            icon: <Globe className="h-3.5 w-3.5 text-teal-500" />,
          } as Row,
        ]
      : []),
    {
      label: "User agent",
      value: connection.userAgent || "Unknown",
      icon: <Monitor className="h-3.5 w-3.5 text-muted-foreground" />,
      mono: true,
      truncate: true,
    },
  ];

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <NetworkIcon className="h-4 w-4 text-teal-500" />
          Network Diagnostics
        </CardTitle>
        <CardDescription>Your device &amp; connection details</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <motion.dl
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="grid grid-cols-1 gap-x-6 gap-y-1 sm:grid-cols-2"
        >
          {rows.map((row, i) => (
            <div
              key={`${row.label}-${i}`}
              className="flex items-center justify-between gap-3 border-b border-border/40 py-2 last:border-b-0"
            >
              <dt className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                {row.icon}
                {row.label}
              </dt>
              <dd
                className={[
                  "min-w-0 truncate text-right text-sm",
                  row.mono ? "font-mono" : "",
                  "text-foreground",
                ].join(" ")}
                title={row.value}
              >
                {row.value}
              </dd>
            </div>
          ))}
        </motion.dl>

        <Separator />

        <div className="space-y-3">
          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Ping sample stats
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat label="Min" value={formatMs(ping.min)} accent="emerald" />
            <Stat label="Avg" value={formatMs(ping.avg)} accent="amber" />
            <Stat label="Max" value={formatMs(ping.max)} accent="orange" />
            <Stat label="Jitter" value={formatMs(ping.jitter)} accent="teal" />
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <Badge variant="outline" className="gap-1 font-mono">
              <Activity className="h-3 w-3 text-emerald-500" />
              {ping.received}/{ping.sent} received
            </Badge>
            <Badge
              variant="outline"
              className={
                ping.packetLoss > 0.02
                  ? "border-transparent bg-rose-500/15 text-rose-600 dark:text-rose-400"
                  : "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
              }
            >
              {(ping.packetLoss * 100).toFixed(1)}% loss
            </Badge>
          </div>
        </div>

        {dns.length > 0 && (
          <>
            <Separator />
            <div className="space-y-3">
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                DNS resolution
              </div>
              <div className="max-h-44 space-y-1.5 overflow-y-auto pr-1 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-track]:bg-transparent">
                {dns.map((d) => (
                  <div
                    key={d.domain}
                    className="flex items-center justify-between gap-3 rounded-md border border-border/40 bg-background/40 px-2.5 py-1.5"
                  >
                    <span className="truncate font-mono text-xs text-muted-foreground">
                      {d.domain}
                    </span>
                    <span className="flex items-center gap-2">
                      {d.ok ? (
                        <span className="font-mono text-xs tabular-nums text-foreground">
                          {formatMs(d.lookupMs)}
                        </span>
                      ) : (
                        <Badge className="border-transparent bg-rose-500/15 text-rose-600 dark:text-rose-400">
                          failed
                        </Badge>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function Stat({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent: "emerald" | "teal" | "amber" | "orange";
}) {
  const accentClass: Record<typeof accent, string> = {
    emerald: "text-emerald-500",
    teal: "text-teal-500",
    amber: "text-amber-500",
    orange: "text-orange-500",
  };
  return (
    <div className="rounded-md border border-border/40 bg-background/40 p-2.5">
      <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div
        className={`mt-0.5 font-mono text-sm font-semibold tabular-nums ${accentClass[accent]}`}
      >
        {value}
      </div>
    </div>
  );
}
