"use client";

import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Copy,
  Download,
  FileJson,
  FileText,
  Link2,
  Share2,
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { formatMbps, formatMs } from "@/lib/speedtest/format";
import { buildShareableUrl } from "@/lib/speedtest/share";
import type { SpeedTestResult } from "@/lib/speedtest/types";

interface ExportPanelProps {
  result: SpeedTestResult | null;
}

const CSV_HEADERS: Array<keyof CsvRow> = [
  "timestamp",
  "serverName",
  "downloadMbps",
  "uploadMbps",
  "pingAvg",
  "jitter",
  "packetLoss",
  "nqsTotal",
  "nqsGrade",
  "voipMos",
  "bufferbloatDelta",
];

interface CsvRow {
  timestamp: number;
  serverName: string;
  downloadMbps: number;
  uploadMbps: number;
  pingAvg: number;
  jitter: number;
  packetLoss: number;
  nqsTotal: number;
  nqsGrade: string;
  voipMos: number;
  bufferbloatDelta: number;
}

function downloadBlob(filename: string, blob: Blob): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  // Revoke on next tick so the click has time to dispatch.
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

function flattenForCsv(r: SpeedTestResult): CsvRow {
  return {
    timestamp: r.timestamp,
    serverName: r.serverName,
    downloadMbps: Number(r.download.mbps.toFixed(3)),
    uploadMbps: Number(r.upload.mbps.toFixed(3)),
    pingAvg: Number(r.ping.avg.toFixed(2)),
    jitter: Number(r.ping.jitter.toFixed(2)),
    packetLoss: Number(r.ping.packetLoss.toFixed(4)),
    nqsTotal: Math.round(r.nqs.total),
    nqsGrade: r.nqs.grade,
    voipMos: Number(r.voip.mos.toFixed(2)),
    bufferbloatDelta: Number(r.bufferbloat.delta.toFixed(2)),
  };
}

function escapeCsvCell(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (/[",\n]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function buildCsv(r: SpeedTestResult): string {
  const row = flattenForCsv(r);
  const headerLine = CSV_HEADERS.join(",");
  const line = CSV_HEADERS.map((h) => escapeCsvCell(row[h])).join(",");
  return `${headerLine}\n${line}\n`;
}

function buildSummary(r: SpeedTestResult): string {
  const lines = [
    "Internet Speed Test Results",
    "===========================",
    `Time: ${new Date(r.timestamp).toLocaleString()}`,
    `Server: ${r.serverName}`,
    "",
    `Download : ${formatMbps(r.download.mbps)} Mbps`,
    `Upload   : ${formatMbps(r.upload.mbps)} Mbps`,
    `Ping avg : ${formatMs(r.ping.avg)} (jitter ${formatMs(r.ping.jitter)}, loss ${(r.ping.packetLoss * 100).toFixed(1)}%)`,
    `Bufferbloat: ${formatMs(r.bufferbloat.delta)} (grade ${r.bufferbloat.grade})`,
    "",
    `Network Quality Score: ${Math.round(r.nqs.total)} / 100 (grade ${r.nqs.grade} — ${r.nqs.label})`,
    `VoIP MOS: ${r.voip.mos.toFixed(2)} (${r.voip.quality})`,
  ];

  if (r.streaming.length > 0) {
    lines.push("", "Streaming capability:");
    for (const s of r.streaming) {
      lines.push(`  • ${s.platform}: ${s.maxResolution} @ ${s.bitrate}`);
    }
  }

  if (r.connection.ip || r.connection.isp) {
    lines.push("", "Connection:");
    if (r.connection.ip) lines.push(`  IP : ${r.connection.ip}`);
    if (r.connection.isp) lines.push(`  ISP: ${r.connection.isp}`);
    if (r.connection.city || r.connection.country) {
      lines.push(
        `  Loc: ${[r.connection.city, r.connection.country].filter(Boolean).join(", ")}`
      );
    }
  }

  return lines.join("\n");
}

export function ExportPanel({ result }: ExportPanelProps) {
  const disabled = !result;

  function handleJson() {
    if (!result) return;
    try {
      const blob = new Blob([JSON.stringify(result, null, 2)], {
        type: "application/json",
      });
      const ts = new Date(result.timestamp).toISOString().replace(/[:.]/g, "-");
      downloadBlob(`speedtest-${ts}.json`, blob);
      toast.success("JSON file downloaded");
    } catch {
      toast.error("Failed to export JSON");
    }
  }

  function handleCsv() {
    if (!result) return;
    try {
      const blob = new Blob([buildCsv(result)], { type: "text/csv" });
      const ts = new Date(result.timestamp).toISOString().replace(/[:.]/g, "-");
      downloadBlob(`speedtest-${ts}.csv`, blob);
      toast.success("CSV file downloaded");
    } catch {
      toast.error("Failed to export CSV");
    }
  }

  async function handleCopySummary() {
    if (!result) return;
    const text = buildSummary(result);
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Summary copied to clipboard");
    } catch {
      toast.error("Failed to copy summary");
    }
  }

  async function handleShare() {
    if (!result) return;
    const text = buildSummary(result);
    const url = buildShareableUrl(result);
    const nav = navigator as Navigator & {
      share?: (data: { title?: string; text?: string; url?: string }) => Promise<void>;
    };
    try {
      if (nav.share) {
        await nav.share({
          title: "Speed Test Results",
          text,
          url,
        });
        toast.success("Shared successfully");
      } else {
        await navigator.clipboard.writeText(`${text}\n\n${url}`);
        toast.success("Shareable link + summary copied to clipboard");
      }
    } catch {
      toast.error("Failed to share results");
    }
  }

  async function handleCopyLink() {
    if (!result) return;
    const url = buildShareableUrl(result);
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Shareable link copied", {
        description: "Anyone with this URL can view your result",
      });
    } catch {
      toast.error("Failed to copy link");
    }
  }

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Download className="h-4 w-4 text-emerald-500" />
          Export &amp; Share
        </CardTitle>
        <CardDescription>Save or share your results</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {disabled ? (
          <motion.p
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="rounded-md border border-dashed border-border/60 bg-muted/20 px-4 py-6 text-center text-xs text-muted-foreground"
          >
            Run a test first to enable export
          </motion.p>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <Button
                variant="outline"
                onClick={handleJson}
                className="justify-start gap-2"
              >
                <FileJson className="h-4 w-4 text-teal-500" />
                <span className="flex flex-col items-start leading-tight">
                  <span className="text-sm font-medium">Export JSON</span>
                  <span className="text-[10px] text-muted-foreground">
                    Full raw result
                  </span>
                </span>
              </Button>
              <Button
                variant="outline"
                onClick={handleCsv}
                className="justify-start gap-2"
              >
                <FileText className="h-4 w-4 text-emerald-500" />
                <span className="flex flex-col items-start leading-tight">
                  <span className="text-sm font-medium">Export CSV</span>
                  <span className="text-[10px] text-muted-foreground">
                    Flattened metrics
                  </span>
                </span>
              </Button>
            </div>

            <Separator />

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <Button
                variant="secondary"
                onClick={handleCopySummary}
                className="justify-start gap-2"
              >
                <Copy className="h-4 w-4 text-amber-500" />
                <span className="flex flex-col items-start leading-tight">
                  <span className="text-sm font-medium">Copy summary</span>
                  <span className="text-[10px] text-muted-foreground">
                    Human-readable text
                  </span>
                </span>
              </Button>
              <Button
                variant="secondary"
                onClick={handleCopyLink}
                className="justify-start gap-2"
              >
                <Link2 className="h-4 w-4 text-violet-500" />
                <span className="flex flex-col items-start leading-tight">
                  <span className="text-sm font-medium">Copy share link</span>
                  <span className="text-[10px] text-muted-foreground">
                    URL with embedded result
                  </span>
                </span>
              </Button>
            </div>

            <Button
              onClick={handleShare}
              className="w-full justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white hover:from-emerald-700 hover:to-teal-700"
            >
              <Share2 className="h-4 w-4" />
              <span className="flex flex-col items-start leading-tight">
                <span className="text-sm font-medium">Share via system dialog</span>
                <span className="text-[10px] text-white/70">
                  Native share / clipboard fallback
                </span>
              </span>
            </Button>

            {result && (
              <div className="rounded-md border border-border/40 bg-background/40 p-3 text-xs text-muted-foreground">
                <div className="mb-1.5 text-[10px] font-medium uppercase tracking-wider">
                  Snapshot
                </div>
                <div className="grid grid-cols-2 gap-y-1 sm:grid-cols-3">
                  <Snap label="Download" value={`${formatMbps(result.download.mbps)} Mbps`} />
                  <Snap label="Upload" value={`${formatMbps(result.upload.mbps)} Mbps`} />
                  <Snap label="Ping" value={formatMs(result.ping.avg)} />
                  <Snap label="NQS" value={`${Math.round(result.nqs.total)} (${result.nqs.grade})`} />
                  <Snap label="VoIP MOS" value={result.voip.mos.toFixed(2)} />
                  <Snap
                    label="Bufferbloat"
                    value={`${formatMs(result.bufferbloat.delta)} (${result.bufferbloat.grade})`}
                  />
                </div>
              </div>
            )}
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}

function Snap({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[10px] uppercase tracking-wider text-muted-foreground/70">
        {label}
      </span>
      <span className="font-mono text-xs tabular-nums text-foreground">{value}</span>
    </div>
  );
}
