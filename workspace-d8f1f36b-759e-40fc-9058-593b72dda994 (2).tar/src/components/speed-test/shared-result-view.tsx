"use client";

import { motion } from "framer-motion";
import {
  Link2,
  ArrowDown,
  ArrowUp,
  Timer,
  Activity,
  Shield,
  PhoneCall,
  Clapperboard,
  Gamepad2,
  Globe,
  Zap,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { ShareableResult } from "@/lib/speedtest/share";

interface SharedResultViewProps {
  data: ShareableResult;
}

const GRADE_COLOR: Record<string, string> = {
  "A+": "text-emerald-500",
  A: "text-emerald-500",
  B: "text-teal-500",
  C: "text-amber-500",
  D: "text-orange-500",
  F: "text-rose-500",
};

const GAME_GRADE_COLOR: Record<string, string> = {
  S: "text-emerald-500",
  A: "text-teal-500",
  B: "text-amber-500",
  C: "text-orange-500",
  D: "text-rose-500",
};

export function SharedResultView({ data }: SharedResultViewProps) {
  const date = new Date(data.ts);
  const dateStr = date.toLocaleString();

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-5"
    >
      {/* Banner */}
      <Card className="overflow-hidden border-violet-500/30 bg-gradient-to-br from-violet-500/10 via-card/80 to-emerald-500/5 p-5 backdrop-blur-xl sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-violet-500">
              <Link2 className="h-3.5 w-3.5" />
              Shared Result
            </div>
            <h2 className="mt-1 text-lg font-bold tracking-tight sm:text-xl">
              Connection test from {dateStr}
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Measured via {data.sn} · Saved {new Date().getFullYear()}
            </p>
          </div>
          <div className="text-right">
            <div className={`text-4xl font-bold ${GRADE_COLOR[data.n.g] ?? "text-foreground"}`}>
              {data.n.t}
            </div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
              NQS / 100 · {data.n.g}
            </div>
          </div>
        </div>
      </Card>

      {/* Headline metrics */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MetricCard
          icon={<ArrowDown className="h-3.5 w-3.5" />}
          label="Download"
          value={`${data.d}`}
          unit="Mbps"
          color="text-emerald-500"
        />
        <MetricCard
          icon={<ArrowUp className="h-3.5 w-3.5" />}
          label="Upload"
          value={`${data.u}`}
          unit="Mbps"
          color="text-teal-500"
        />
        <MetricCard
          icon={<Timer className="h-3.5 w-3.5" />}
          label="Ping"
          value={`${data.p.a}`}
          unit="ms"
          color="text-amber-500"
        />
        <MetricCard
          icon={<Activity className="h-3.5 w-3.5" />}
          label="Jitter"
          value={`${data.p.j}`}
          unit="ms"
          color="text-cyan-500"
        />
      </div>

      {/* Quality breakdown */}
      <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
        <div className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          <Shield className="h-3.5 w-3.5 text-emerald-500" />
          Quality Summary
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <SummaryRow label="Packet Loss" value={`${(data.p.l * 100).toFixed(1)}%`} />
          <SummaryRow label="Ping Range" value={`${data.p.mn}–${data.p.mx} ms`} />
          <SummaryRow
            label="Bufferbloat"
            value={`${data.bb.g} grade (+${data.bb.d}ms)`}
          />
        </div>
      </Card>

      {/* Streaming */}
      <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
        <div className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          <Clapperboard className="h-3.5 w-3.5 text-rose-500" />
          Streaming Capabilities
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          {data.st.map((s) => (
            <div
              key={s.p}
              className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 px-3 py-2"
            >
              <span className="text-sm font-medium">{s.p}</span>
              <Badge
                className={
                  s.c
                    ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                    : "border-rose-500/40 bg-rose-500/10 text-rose-600 dark:text-rose-400"
                }
                variant="outline"
              >
                {s.r}
              </Badge>
            </div>
          ))}
        </div>
      </Card>

      {/* Gaming */}
      <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
        <div className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          <Gamepad2 className="h-3.5 w-3.5 text-teal-500" />
          Gaming Grades
        </div>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {data.gm.map((g) => (
            <div
              key={g.g}
              className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 px-3 py-2"
            >
              <span className="truncate text-xs font-medium">{g.g}</span>
              <div className="flex items-center gap-1.5">
                <span className={`text-sm font-bold ${GAME_GRADE_COLOR[g.gd] ?? ""}`}>
                  {g.gd}
                </span>
                {g.p ? (
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                ) : (
                  <span className="h-1.5 w-1.5 rounded-full bg-rose-500" />
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* VoIP + DNS */}
      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
          <div className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <PhoneCall className="h-3.5 w-3.5 text-cyan-500" />
            VoIP Quality
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-bold tabular-nums">{data.vo.m}</span>
            <span className="text-sm text-muted-foreground">/ 5.0 MOS</span>
          </div>
          <div className="mt-1 text-sm text-muted-foreground">
            {data.vo.q} · R-value {data.vo.r}
          </div>
        </Card>

        <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
          <div className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Globe className="h-3.5 w-3.5 text-violet-500" />
            DNS Resolution
          </div>
          <div className="space-y-1">
            {data.dn.map((d) => (
              <div
                key={d.d}
                className="flex items-center justify-between text-xs"
              >
                <span className="text-muted-foreground">{d.d}</span>
                <span
                  className={
                    d.o
                      ? d.m < 50
                        ? "font-semibold text-emerald-500"
                        : d.m < 150
                        ? "font-semibold text-amber-500"
                        : "font-semibold text-rose-500"
                      : "text-rose-500"
                  }
                >
                  {d.o ? `${d.m} ms` : "failed"}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* CTA */}
      <Card className="border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 to-teal-500/5 p-5 text-center backdrop-blur sm:p-6">
        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/15">
          <Zap className="h-6 w-6 text-emerald-500" />
        </div>
        <h3 className="text-base font-semibold">Want to measure your own connection?</h3>
        <p className="mt-1 text-xs text-muted-foreground">
          This result was shared with you. Run your own comprehensive test to get
          your Network Quality Score, gaming grades, and more.
        </p>
        <button
          onClick={() => {
            if (typeof window !== "undefined") {
              window.location.hash = "";
              window.location.reload();
            }
          }}
          className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-emerald-500/20 transition hover:from-emerald-600 hover:to-teal-600"
        >
          <Zap className="h-3.5 w-3.5" />
          Run my own test
        </button>
      </Card>
    </motion.div>
  );
}

function MetricCard({
  icon,
  label,
  value,
  unit,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit: string;
  color: string;
}) {
  return (
    <Card className="border-border/60 bg-card/80 p-4 backdrop-blur">
      <div className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        <span className={color}>{icon}</span>
        {label}
      </div>
      <div className="mt-1 text-2xl font-bold tabular-nums sm:text-3xl">
        {value}
      </div>
      <div className="text-[10px] text-muted-foreground">{unit}</div>
    </Card>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border/60 bg-background/40 p-2.5">
      <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className="mt-0.5 text-sm font-semibold tabular-nums">{value}</div>
    </div>
  );
}
