"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import { Activity } from "lucide-react";
import { Card } from "@/components/ui/card";
import type { PingResult } from "@/lib/speedtest/types";
import { formatMs } from "@/lib/speedtest/format";

interface StabilitySparklineProps {
  ping: PingResult;
}

/**
 * Visualises the per-sample round-trip times from a ping test as a sparkline,
 * highlighting stability vs jitter. Standard speed tests just show one number;
 * this shows the actual per-packet behaviour.
 */
export function StabilitySparkline({ ping }: StabilitySparklineProps) {
  const samples = ping.samples;
  const rtts = samples.map((s) => s.rtt);

  const stats = useMemo(() => {
    if (rtts.length === 0) return null;
    const mean = rtts.reduce((a, b) => a + b, 0) / rtts.length;
    const variance =
      rtts.reduce((a, b) => a + (b - mean) ** 2, 0) / rtts.length;
    const stdDev = Math.sqrt(variance);
    // coefficient of variation — stability metric
    const cv = mean > 0 ? stdDev / mean : 0;
    return { mean, stdDev, cv };
  }, [rtts]);

  if (!stats || rtts.length === 0) {
    return null;
  }

  // Build sparkline path. x scales across width, y scales by max rtt.
  const W = 100;
  const H = 36;
  const maxR = Math.max(...rtts, 1);
  const minR = Math.min(...rtts, 0);
  const range = Math.max(maxR - minR, 1);
  const stepX = W / Math.max(rtts.length - 1, 1);

  const points = rtts.map((r, i) => {
    const x = i * stepX;
    const y = H - ((r - minR) / range) * (H - 4) - 2;
    return { x, y, r };
  });

  // smooth line path
  const linePath = points
    .map((p, i) => {
      if (i === 0) return `M ${p.x} ${p.y}`;
      const prev = points[i - 1];
      const cx = (prev.x + p.x) / 2;
      return `Q ${cx} ${prev.y}, ${cx} ${(prev.y + p.y) / 2} T ${p.x} ${p.y}`;
    })
    .join(" ");

  const areaPath = `${linePath} L ${W} ${H} L 0 ${H} Z`;

  // Stability verdict from coefficient of variation
  const stability =
    stats.cv < 0.1
      ? { label: "Rock solid", color: "text-emerald-500", grade: "A" }
      : stats.cv < 0.25
      ? { label: "Stable", color: "text-teal-500", grade: "B" }
      : stats.cv < 0.5
      ? { label: "Some variance", color: "text-amber-500", grade: "C" }
      : { label: "Unstable", color: "text-rose-500", grade: "D" };

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Activity className="h-3.5 w-3.5 text-teal-500" />
            Connection Stability
          </div>
          <h3 className="mt-1 text-lg font-bold tracking-tight">
            Per-packet latency trace
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {rtts.length} ping samples — see how each round-trip varied
          </p>
        </div>
        <div className="text-right">
          <div className={`text-2xl font-bold ${stability.color}`}>
            {stability.grade}
          </div>
          <div className={`text-[10px] font-semibold uppercase tracking-wider ${stability.color}`}>
            {stability.label}
          </div>
        </div>
      </div>

      {/* Sparkline */}
      <div className="relative h-20 w-full overflow-hidden rounded-lg bg-muted/20 p-2">
        <svg
          viewBox={`0 0 ${W} ${H}`}
          preserveAspectRatio="none"
          className="h-full w-full"
        >
          <defs>
            <linearGradient id="spark-grad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="oklch(0.72 0.19 152)" stopOpacity={0.5} />
              <stop offset="100%" stopColor="oklch(0.72 0.19 152)" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          {/* baseline (mean) */}
          <line
            x1="0"
            y1={H - ((stats.mean - minR) / range) * (H - 4) - 2}
            x2={W}
            y2={H - ((stats.mean - minR) / range) * (H - 4) - 2}
            stroke="currentColor"
            className="text-muted-foreground/30"
            strokeWidth="0.5"
            strokeDasharray="2 2"
          />
          <motion.path
            d={areaPath}
            fill="url(#spark-grad)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          />
          <motion.path
            d={linePath}
            fill="none"
            stroke="oklch(0.72 0.19 152)"
            strokeWidth="1.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1, ease: "easeInOut" }}
          />
          {/* sample dots */}
          {points.map((p, i) => (
            <motion.circle
              key={i}
              cx={p.x}
              cy={p.y}
              r="0.8"
              fill="oklch(0.72 0.19 152)"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.05 * i }}
            />
          ))}
        </svg>
      </div>

      {/* Stats row */}
      <div className="mt-4 grid grid-cols-4 gap-2">
        <StatBox label="Mean" value={formatMs(stats.mean)} />
        <StatBox label="Std Dev" value={formatMs(stats.stdDev)} />
        <StatBox
          label="Range"
          value={`${Math.round(minR)}–${Math.round(maxR)}ms`}
        />
        <StatBox
          label="Variation"
          value={`${Math.round(stats.cv * 100)}%`}
          accent={stability.color}
        />
      </div>
    </Card>
  );
}

function StatBox({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent?: string;
}) {
  return (
    <div className="rounded-lg border border-border/60 bg-background/40 p-2.5 text-center">
      <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div
        className={`mt-0.5 text-sm font-bold tabular-nums ${accent ?? ""}`}
      >
        {value}
      </div>
    </div>
  );
}
