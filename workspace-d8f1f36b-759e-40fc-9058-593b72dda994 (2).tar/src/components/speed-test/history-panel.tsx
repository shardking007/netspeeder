"use client";

import { useCallback, useMemo } from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  History as HistoryIcon,
  Trash2,
  Download as DownloadIcon,
  Upload as UploadIcon,
  Gauge,
  Image as ImageIcon,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardAction } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { formatMbps, formatMs } from "@/lib/speedtest/format";
import type { SpeedTestResult, NetworkQualityScore } from "@/lib/speedtest/types";

interface HistoryPanelProps {
  history: SpeedTestResult[];
  onClear: () => void;
  onDelete: (id: string) => void;
}

const GRADE_STYLES: Record<string, string> = {
  "A+": "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  A: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  B: "border-transparent bg-teal-500/15 text-teal-600 dark:text-teal-400",
  C: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  D: "border-transparent bg-orange-500/15 text-orange-600 dark:text-orange-400",
  F: "border-transparent bg-rose-500/15 text-rose-600 dark:text-rose-400",
};

function gradeClass(grade: NetworkQualityScore["grade"]): string {
  return GRADE_STYLES[grade] ?? "border-transparent bg-muted text-muted-foreground";
}

function downloadLabel(v: number) {
  return `${formatMbps(v)} Mbps`;
}

export function HistoryPanel({ history, onClear, onDelete }: HistoryPanelProps) {
  const chartData = useMemo(
    () =>
      history
        .slice()
        .sort((a, b) => a.timestamp - b.timestamp)
        .map((r) => ({
          timestamp: r.timestamp,
          label: format(new Date(r.timestamp), "MMM d HH:mm"),
          download: Number(r.download.mbps.toFixed(2)),
          upload: Number(r.upload.mbps.toFixed(2)),
        })),
    [history]
  );

  const hasHistory = history.length > 0;

  const handleExportImage = useCallback(() => {
    if (chartData.length === 0) {
      toast.error("No data to export", {
        description: "Run a few tests first to build history",
      });
      return;
    }
    const canvas = document.createElement("canvas");
    const W = 800;
    const H = 400;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Background
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(0, 0, W, H);

    // Title
    ctx.fillStyle = "#10b981";
    ctx.font = "bold 22px sans-serif";
    ctx.fillText("ZSpeed — History Trend", 24, 36);
    ctx.fillStyle = "#6b7280";
    ctx.font = "12px sans-serif";
    ctx.fillText(
      `${chartData.length} tests · ${format(new Date(chartData[0].timestamp), "MMM d")} – ${format(new Date(chartData[chartData.length - 1].timestamp), "MMM d, HH:mm")}`,
      24,
      56
    );

    // Chart area
    const chartX = 48;
    const chartY = 90;
    const chartW = W - 72;
    const chartH = 220;
    ctx.fillStyle = "#111";
    ctx.fillRect(chartX, chartY, chartW, chartH);

    // Grid lines
    ctx.strokeStyle = "#1f2937";
    ctx.lineWidth = 0.5;
    const maxDown = Math.max(...chartData.map((d) => d.download), 1);
    const maxUp = Math.max(...chartData.map((d) => d.upload), 1);
    const maxVal = Math.max(maxDown, maxUp) * 1.1;
    for (let i = 0; i <= 4; i++) {
      const y = chartY + (chartH / 4) * i;
      ctx.beginPath();
      ctx.moveTo(chartX, y);
      ctx.lineTo(chartX + chartW, y);
      ctx.stroke();
      // Y-axis labels
      const val = maxVal * (1 - i / 4);
      ctx.fillStyle = "#4b5563";
      ctx.font = "9px sans-serif";
      ctx.fillText(val > 1000 ? `${(val / 1000).toFixed(1)}G` : `${Math.round(val)}`, 8, y + 3);
    }

    // Plot download line
    const stepX = chartData.length > 1 ? chartW / (chartData.length - 1) : 0;
    const plotLine = (key: "download" | "upload", color: string, fill: string) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      chartData.forEach((d, i) => {
        const x = chartX + i * stepX;
        const y = chartY + chartH - (d[key] / maxVal) * chartH;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      // gradient fill
      ctx.lineTo(chartX + (chartData.length - 1) * stepX, chartY + chartH);
      ctx.lineTo(chartX, chartY + chartH);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, chartY, 0, chartY + chartH);
      grad.addColorStop(0, fill);
      grad.addColorStop(1, "transparent");
      ctx.fillStyle = grad;
      ctx.fill();

      // dots
      ctx.fillStyle = color;
      chartData.forEach((d, i) => {
        const x = chartX + i * stepX;
        const y = chartY + chartH - (d[key] / maxVal) * chartH;
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fill();
      });
    };
    plotLine("download", "#10b981", "rgba(16,185,129,0.25)");
    plotLine("upload", "#14b8a6", "rgba(20,184,166,0.25)");

    // Legend
    const legY = chartY + chartH + 20;
    ctx.fillStyle = "#10b981";
    ctx.beginPath();
    ctx.arc(chartX + 6, legY, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#d1d5db";
    ctx.font = "11px sans-serif";
    ctx.fillText("Download", chartX + 16, legY + 4);
    ctx.fillStyle = "#14b8a6";
    ctx.beginPath();
    ctx.arc(chartX + 96, legY, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#d1d5db";
    ctx.fillText("Upload", chartX + 106, legY + 4);

    // Stats summary
    const stats = chartData.reduce(
      (acc, d) => {
        acc.downSum += d.download;
        acc.upSum += d.upload;
        acc.downMax = Math.max(acc.downMax, d.download);
        acc.upMax = Math.max(acc.upMax, d.upload);
        return acc;
      },
      { downSum: 0, upSum: 0, downMax: 0, upMax: 0 }
    );
    const statY = H - 36;
    const drawSummary = (x: number, label: string, value: string, color: string) => {
      ctx.fillStyle = "#6b7280";
      ctx.font = "9px sans-serif";
      ctx.fillText(label, x, statY);
      ctx.fillStyle = color;
      ctx.font = "bold 14px sans-serif";
      ctx.fillText(value, x, statY + 16);
    };
    drawSummary(24, "AVG DOWN", `${formatMbps(stats.downSum / chartData.length)} Mbps`, "#10b981");
    drawSummary(220, "AVG UP", `${formatMbps(stats.upSum / chartData.length)} Mbps`, "#14b8a6");
    drawSummary(420, "BEST DOWN", `${formatMbps(stats.downMax)} Mbps`, "#10b981");
    drawSummary(620, "BEST UP", `${formatMbps(stats.upMax)} Mbps`, "#14b8a6");

    // Footer
    ctx.fillStyle = "#374151";
    ctx.font = "8px sans-serif";
    ctx.fillText("Generated by ZSpeed — Advanced Internet Speed Checker", 24, H - 4);

    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `zspeed-history-${Date.now()}.png`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("History trend saved", {
        description: "Chart exported as shareable PNG",
        icon: <ImageIcon className="h-4 w-4" />,
      });
    });
  }, [chartData]);

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <HistoryIcon className="h-4 w-4 text-emerald-500" />
          Test History
        </CardTitle>
        <CardDescription>
          Your speed tests over time (saved locally)
        </CardDescription>
        {hasHistory && (
          <CardAction>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportImage}
                className="gap-1.5 border-emerald-500/40 text-emerald-600 hover:bg-emerald-500/10 dark:text-emerald-400"
              >
                <ImageIcon className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Save chart</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onClear}
                className="gap-1.5 text-muted-foreground"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Clear all</span>
              </Button>
            </div>
          </CardAction>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        {!hasHistory ? (
          <EmptyState />
        ) : (
          <>
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="rounded-lg border border-border/60 bg-background/40 p-3"
            >
              <div className="mb-2 flex items-center justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground">
                <span>Speed trend</span>
                <span className="flex items-center gap-3">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-emerald-500" />
                    Download
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-teal-500" />
                    Upload
                  </span>
                </span>
              </div>
              <div className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={chartData}
                    margin={{ top: 8, right: 8, left: -16, bottom: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="currentColor"
                      className="text-border/50"
                      vertical={false}
                    />
                    <XAxis
                      dataKey="label"
                      tick={{ fill: "currentColor", fontSize: 10 }}
                      className="text-muted-foreground"
                      stroke="currentColor"
                      axisLine={false}
                      tickLine={false}
                      minTickGap={24}
                    />
                    <YAxis
                      tick={{ fill: "currentColor", fontSize: 10 }}
                      className="text-muted-foreground"
                      stroke="currentColor"
                      axisLine={false}
                      tickLine={false}
                      width={48}
                    />
                    <Tooltip
                      contentStyle={{
                        background: "var(--popover)",
                        border: "1px solid var(--border)",
                        borderRadius: 8,
                        fontSize: 12,
                        color: "var(--popover-foreground)",
                      }}
                      formatter={(v: number, name: string) => [
                        `${formatMbps(v)} Mbps`,
                        name === "download" ? "Download" : "Upload",
                      ]}
                    />
                    <Line
                      type="monotone"
                      dataKey="download"
                      stroke="oklch(0.72 0.19 152)"
                      strokeWidth={2.5}
                      dot={{ r: 2.5, fill: "oklch(0.72 0.19 152)" }}
                      activeDot={{ r: 4 }}
                      isAnimationActive
                      animationDuration={400}
                    />
                    <Line
                      type="monotone"
                      dataKey="upload"
                      stroke="oklch(0.70 0.13 195)"
                      strokeWidth={2.5}
                      dot={{ r: 2.5, fill: "oklch(0.70 0.13 195)" }}
                      activeDot={{ r: 4 }}
                      isAnimationActive
                      animationDuration={400}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            <Separator />

            <div className="space-y-2">
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Past results
              </div>
              <div
                className="max-h-96 space-y-2 overflow-y-auto pr-1 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-track]:bg-transparent"
              >
                {history.map((r, idx) => (
                  <motion.div
                    key={r.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2, delay: Math.min(idx * 0.02, 0.2) }}
                    className="flex flex-col gap-3 rounded-lg border border-border/60 bg-background/40 p-3 transition-colors hover:bg-accent/30 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <span className="font-mono">
                          {format(new Date(r.timestamp), "MMM d, HH:mm:ss")}
                        </span>
                        <span className="text-border">•</span>
                        <span className="truncate">{r.serverName}</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                        <span className="flex items-center gap-1.5">
                          <DownloadIcon className="h-3.5 w-3.5 text-emerald-500" />
                          <span className="font-semibold tabular-nums text-foreground">
                            {formatMbps(r.download.mbps)}
                          </span>
                          <span className="text-xs text-muted-foreground">Mbps</span>
                        </span>
                        <span className="flex items-center gap-1.5">
                          <UploadIcon className="h-3.5 w-3.5 text-teal-500" />
                          <span className="font-semibold tabular-nums text-foreground">
                            {formatMbps(r.upload.mbps)}
                          </span>
                          <span className="text-xs text-muted-foreground">Mbps</span>
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Gauge className="h-3.5 w-3.5 text-amber-500" />
                          <span className="font-semibold tabular-nums text-foreground">
                            {formatMs(r.ping.avg)}
                          </span>
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={gradeClass(r.nqs.grade)}>
                        NQS {r.nqs.grade}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => onDelete(r.id)}
                        aria-label="Delete result"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function EmptyState() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col items-center justify-center gap-3 py-12 text-center"
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted/40">
        <HistoryIcon className="h-6 w-6 text-muted-foreground" />
      </div>
      <div className="space-y-1">
        <p className="text-sm font-medium text-foreground">No saved tests yet</p>
        <p className="text-xs text-muted-foreground">
          Run your first speed test to start building a trend over time.
        </p>
      </div>
    </motion.div>
  );
}
