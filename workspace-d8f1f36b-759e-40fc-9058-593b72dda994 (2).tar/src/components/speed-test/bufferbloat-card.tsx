"use client";

import { motion } from "framer-motion";
import { TrendingUp, Info } from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { formatMs } from "@/lib/speedtest/format";
import type { BufferbloatResult } from "@/lib/speedtest/types";

interface BufferbloatCardProps {
  result: BufferbloatResult;
}

function gradeColor(grade: BufferbloatResult["grade"]): {
  bg: string;
  text: string;
  border: string;
} {
  switch (grade) {
    case "A":
      return {
        bg: "bg-emerald-500/10",
        text: "text-emerald-500",
        border: "border-emerald-500/30",
      };
    case "B":
      return {
        bg: "bg-teal-500/10",
        text: "text-teal-500",
        border: "border-teal-500/30",
      };
    case "C":
      return {
        bg: "bg-amber-500/10",
        text: "text-amber-500",
        border: "border-amber-500/30",
      };
    case "D":
      return {
        bg: "bg-orange-500/10",
        text: "text-orange-500",
        border: "border-orange-500/30",
      };
    case "F":
      return {
        bg: "bg-rose-500/10",
        text: "text-rose-500",
        border: "border-rose-500/30",
      };
  }
}

function gradeLabel(grade: BufferbloatResult["grade"]): string {
  switch (grade) {
    case "A":
      return "Minimal bufferbloat";
    case "B":
      return "Slight latency under load";
    case "C":
      return "Noticeable latency increase";
    case "D":
      return "Significant bufferbloat";
    case "F":
      return "Severe bufferbloat — link is saturated";
  }
}

export function BufferbloatCard({ result }: BufferbloatCardProps) {
  const { baselineLatency, latencyUnderLoad, delta, grade } = result;
  const colors = gradeColor(grade);

  // Bar scaling — cap at 4x baseline so under-load bar is visible
  const baselineRatio = 0.25; // baseline fills 25% of the bar at minimum
  const loadRatio = Math.min(
    1,
    Math.max(baselineRatio, latencyUnderLoad / Math.max(baselineLatency * 4, 1))
  );

  const baselinePct = Math.max(8, (baselineLatency / (latencyUnderLoad * 1.1 || 1)) * 100);
  const loadPct = 100;

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="px-0">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
          Bufferbloat Analysis
        </CardTitle>
        <CardDescription>Latency behavior when the link is under load</CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        <div className="flex flex-col gap-5">
          {/* Top row: stat grid + grade badge */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Baseline" value={formatMs(baselineLatency)} />
            <Stat label="Under Load" value={formatMs(latencyUnderLoad)} />
            <Stat label="Latency Added" value={`+${formatMs(delta).replace(" ", "")}`} />
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Grade
              </span>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 180, damping: 14 }}
                className={`flex h-12 w-12 items-center justify-center rounded-xl border text-2xl font-bold ${colors.bg} ${colors.text} ${colors.border}`}
              >
                {grade}
              </motion.div>
            </div>
          </div>

          {/* Comparison bar */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium uppercase tracking-wider text-muted-foreground">
                Latency comparison
              </span>
              <span className="text-muted-foreground">
                {loadRatio > 2 ? "High added latency" : "Stable under load"}
              </span>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center gap-2">
                <span className="w-16 shrink-0 text-xs text-muted-foreground">Idle</span>
                <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-muted">
                  <motion.div
                    className="h-full rounded-full bg-emerald-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${baselinePct}%` }}
                    transition={{ duration: 0.7, ease: "easeOut" }}
                  />
                </div>
                <span className="w-14 shrink-0 text-right text-xs tabular-nums">
                  {formatMs(baselineLatency)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-16 shrink-0 text-xs text-muted-foreground">Loaded</span>
                <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-muted">
                  <motion.div
                    className={`h-full rounded-full ${
                      grade === "A" || grade === "B"
                        ? "bg-emerald-500"
                        : grade === "C"
                          ? "bg-amber-500"
                          : "bg-rose-500"
                    }`}
                    initial={{ width: 0 }}
                    animate={{ width: `${loadPct}%` }}
                    transition={{ duration: 0.9, ease: "easeOut", delay: 0.1 }}
                  />
                </div>
                <span className="w-14 shrink-0 text-right text-xs tabular-nums">
                  {formatMs(latencyUnderLoad)}
                </span>
              </div>
            </div>
          </div>

          {/* Explanation */}
          <div className="flex items-start gap-2 rounded-lg border border-border/60 bg-muted/30 p-3">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            <p className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Bufferbloat</span> is the
              extra latency caused when your router buffers too much data during heavy
              uploads or downloads. {gradeLabel(grade)}.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <span className="text-2xl font-bold tabular-nums sm:text-3xl">{value}</span>
    </div>
  );
}
