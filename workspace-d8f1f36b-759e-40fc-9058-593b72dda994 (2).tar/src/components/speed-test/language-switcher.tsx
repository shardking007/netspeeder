"use client";

import { useSyncExternalStore, useCallback } from "react";
import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  langStore,
  setLang,
  t,
  type TranslationKey,
} from "@/lib/speedtest/i18n";

export function useLang() {
  return useSyncExternalStore(
    langStore.subscribe,
    langStore.getSnapshot,
    langStore.getServerSnapshot
  );
}

export function useT() {
  const lang = useLang();
  return useCallback((key: TranslationKey) => t(key, lang), [lang]);
}

export function LanguageSwitcher() {
  const lang = useLang();
  return (
    <div className="flex items-center rounded-full border border-border/60 bg-background/60 p-0.5 backdrop-blur">
      <Languages className="mx-1 h-3 w-3 text-muted-foreground" />
      <button
        onClick={() => setLang("en")}
        className={`rounded-full px-2 py-0.5 text-[10px] font-semibold transition-colors ${
          lang === "en"
            ? "bg-emerald-500 text-white"
            : "text-muted-foreground hover:text-foreground"
        }`}
        aria-label="English"
      >
        EN
      </button>
      <button
        onClick={() => setLang("zh")}
        className={`rounded-full px-2 py-0.5 text-[10px] font-semibold transition-colors ${
          lang === "zh"
            ? "bg-emerald-500 text-white"
            : "text-muted-foreground hover:text-foreground"
        }`}
        aria-label="中文"
      >
        中文
      </button>
    </div>
  );
}
