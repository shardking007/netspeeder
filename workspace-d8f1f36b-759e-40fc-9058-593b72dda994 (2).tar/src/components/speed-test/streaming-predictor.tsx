"use client";

import { motion } from "framer-motion";
import { Check, X, MonitorPlay } from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { formatMbps } from "@/lib/speedtest/format";
import type { StreamingCapability } from "@/lib/speedtest/types";

interface StreamingPredictorProps {
  items: StreamingCapability[];
  downloadMbps: number;
}

function resolutionBadgeClass(resolution: string): string {
  const r = resolution.toLowerCase();
  if (r.includes("8k") || r.includes("4k")) {
    return "border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400";
  }
  if (r.includes("1080")) {
    return "border-teal-500/30 bg-teal-500/10 text-teal-600 dark:text-teal-400";
  }
  if (r.includes("720") || r.includes("1440")) {
    return "border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400";
  }
  return "border-rose-500/30 bg-rose-500/10 text-rose-600 dark:text-rose-400";
}

export function StreamingPredictor({
  items,
  downloadMbps,
}: StreamingPredictorProps) {
  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="px-0">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <MonitorPlay className="h-4 w-4 text-muted-foreground" />
          Streaming Quality Predictor
        </CardTitle>
        <CardDescription>
          Maximum resolution your connection supports
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        <div className="mb-4 flex items-baseline gap-2 rounded-lg border border-border/60 bg-muted/30 px-3 py-2">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Measured Download
          </span>
          <span className="text-lg font-bold tabular-nums">
            {formatMbps(downloadMbps)}
          </span>
          <span className="text-xs text-muted-foreground">Mbps</span>
        </div>

        <div className="flex flex-col">
          {items.map((item, i) => (
            <div key={item.platform}>
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.04 }}
                className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-md ${
                      item.canStream
                        ? "bg-emerald-500/10 text-emerald-500"
                        : "bg-rose-500/10 text-rose-500"
                    }`}
                  >
                    {item.canStream ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <X className="h-4 w-4" />
                    )}
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-semibold">{item.platform}</span>
                      <Badge
                        variant="outline"
                        className={`px-1.5 py-0 text-[10px] font-semibold ${resolutionBadgeClass(
                          item.maxResolution
                        )}`}
                      >
                        {item.maxResolution}
                      </Badge>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {item.recommendation}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3 pl-11 sm:pl-0">
                  <div className="flex flex-col items-end gap-0.5">
                    <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      Bitrate
                    </span>
                    <span className="text-xs font-medium tabular-nums">
                      {item.bitrate}
                    </span>
                  </div>
                </div>
              </motion.div>
              {i < items.length - 1 && <Separator className="" />}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
