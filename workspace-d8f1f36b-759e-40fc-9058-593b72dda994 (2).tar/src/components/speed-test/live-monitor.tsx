"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity,
  Play,
  Square,
  Timer,
  TrendingDown,
  TrendingUp,
  Zap,
  Wifi,
  WifiOff,
  Gauge,
  Bell,
  BellRing,
  AlertTriangle,
  History,
  MonitorSmartphone,
  Download,
  Image as ImageIcon,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { runLiveMonitor } from "@/lib/speedtest/engine";
import type { MonitorStats, MonitorSample } from "@/lib/speedtest/engine";
import { SERVERS } from "@/lib/speedtest/servers";
import {
  getNotificationPermission,
  requestNotificationPermission,
  fireNotification,
} from "@/lib/speedtest/notifications";
import { formatMs } from "@/lib/speedtest/format";
import { toast } from "sonner";

const MAX_POINTS = 60;

export function LiveMonitor() {
  const [running, setRunning] = useState(false);
  const [stats, setStats] = useState<MonitorStats | null>(null);
  const [history, setHistory] = useState<MonitorSample[]>([]);
  const [elapsed, setElapsed] = useState(0);
  // Alert configuration
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  const [alertThreshold, setAlertThreshold] = useState(150); // ms
  const [alertActive, setAlertActive] = useState(false);
  const [alertCount, setAlertCount] = useState(0);
  // Browser notifications
  const [desktopNotifs, setDesktopNotifs] = useState(false);
  const [notifPermission, setNotifPermission] = useState<
    "default" | "granted" | "denied" | "unsupported"
  >("default");
  const desktopNotifsRef = useRef(false);
  desktopNotifsRef.current = desktopNotifs;
  // Alert history log
  interface AlertEvent {
    id: number;
    timestamp: number;
    rtt: number;
    threshold: number;
  }
  const [alertHistory, setAlertHistory] = useState<AlertEvent[]>([]);
  const alertIdRef = useRef(0);
  const alertActiveRef = useRef(false);
  const alertsEnabledRef = useRef(alertsEnabled);
  const thresholdRef = useRef(alertThreshold);
  alertsEnabledRef.current = alertsEnabled;
  thresholdRef.current = alertThreshold;

  const abortRef = useRef<AbortController | null>(null);
  const startRef = useRef<number>(0);
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const start = useCallback(async () => {
    setRunning(true);
    setHistory([]);
    setStats(null);
    setElapsed(0);
    setAlertActive(false);
    setAlertCount(0);
    setAlertHistory([]);
    alertActiveRef.current = false;
    startRef.current = Date.now();

    // tick the elapsed counter every second
    if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
    elapsedTimerRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
    }, 1000);

    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    const server = SERVERS[0]; // local edge for monitor
    try {
      await runLiveMonitor(
        server.pingUrl,
        (sample, s) => {
          setStats(s);
          setHistory((prev) => {
            const next = [...prev, sample];
            if (next.length > MAX_POINTS) next.shift();
            return next;
          });
          // Latency alert check
          if (
            sample.rtt !== null &&
            alertsEnabledRef.current &&
            sample.rtt > thresholdRef.current
          ) {
            if (!alertActiveRef.current) {
              alertActiveRef.current = true;
              setAlertActive(true);
              setAlertCount((c) => c + 1);
              const event: AlertEvent = {
                id: ++alertIdRef.current,
                timestamp: sample.timestamp,
                rtt: Math.round(sample.rtt),
                threshold: thresholdRef.current,
              };
              setAlertHistory((prev) => [event, ...prev].slice(0, 20));
              toast.error("Latency alert!", {
                description: `${Math.round(sample.rtt)}ms exceeds ${thresholdRef.current}ms threshold`,
                icon: <AlertTriangle className="h-4 w-4" />,
                duration: 4000,
              });
              // Fire a native OS notification if enabled and tab is backgrounded
              if (desktopNotifsRef.current) {
                fireNotification("ZSpeed — Latency Alert", {
                  body: `${Math.round(sample.rtt)}ms exceeds your ${thresholdRef.current}ms threshold`,
                  tag: "zspeed-latency-alert",
                });
              }
            }
          } else if (alertActiveRef.current) {
            // latency recovered below threshold
            alertActiveRef.current = false;
            setAlertActive(false);
          }
        },
        { intervalMs: 1000, windowSize: MAX_POINTS, signal: ac.signal }
      );
    } catch (e) {
      toast.error("Monitor error", {
        description: e instanceof Error ? e.message : "unknown",
      });
    } finally {
      setRunning(false);
      setAlertActive(false);
      alertActiveRef.current = false;
      if (elapsedTimerRef.current) {
        clearInterval(elapsedTimerRef.current);
        elapsedTimerRef.current = null;
      }
    }
  }, []);

  const stop = useCallback(() => {
    abortRef.current?.abort();
    setRunning(false);
    setAlertActive(false);
    alertActiveRef.current = false;
    if (elapsedTimerRef.current) {
      clearInterval(elapsedTimerRef.current);
      elapsedTimerRef.current = null;
    }
    toast.success("Monitor stopped", {
      description: `Ran for ${elapsed}s · ${stats?.sent ?? 0} pings · ${alertCount} alerts`,
    });
  }, [elapsed, stats, alertCount]);

  // Save the monitor session as a PNG image (canvas-rendered)
  const handleSaveImage = useCallback(() => {
    if (!stats || history.length === 0) {
      toast.error("No data to export", {
        description: "Run the monitor first to capture session data",
      });
      return;
    }
    const canvas = document.createElement("canvas");
    const W = 800;
    const H = 420;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Background
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(0, 0, W, H);

    // Title
    ctx.fillStyle = "#10b981";
    ctx.font = "bold 22px sans-serif";
    ctx.fillText("ZSpeed — Monitor Session", 24, 36);
    ctx.fillStyle = "#6b7280";
    ctx.font = "12px sans-serif";
    const dateStr = new Date().toLocaleString();
    ctx.fillText(`${dateStr} · ${elapsed}s · ${stats.sent} pings`, 24, 56);

    // Stats row
    const statY = 90;
    const drawStat = (
      x: number,
      label: string,
      value: string,
      color: string
    ) => {
      ctx.fillStyle = "#6b7280";
      ctx.font = "10px sans-serif";
      ctx.fillText(label, x, statY);
      ctx.fillStyle = color;
      ctx.font = "bold 24px sans-serif";
      ctx.fillText(value, x, statY + 28);
    };
    drawStat(24, "CURRENT", stats.current ? `${Math.round(stats.current)}ms` : "—", "#06b6d4");
    drawStat(170, "AVERAGE", `${Math.round(stats.avg)}ms`, "#10b981");
    drawStat(316, "MIN / MAX", `${Math.round(stats.min)} / ${Math.round(stats.max)}ms`, "#f59e0b");
    drawStat(500, "JITTER", `${Math.round(stats.jitter)}ms`, "#14b8a6");
    drawStat(646, "LOSS", `${(stats.lossRate * 100).toFixed(1)}%`, "#ef4444");

    // Sparkline area
    const chartX = 24;
    const chartY = 150;
    const chartW = W - 48;
    const chartH = 180;
    ctx.fillStyle = "#111";
    ctx.fillRect(chartX, chartY, chartW, chartH);
    ctx.strokeStyle = "#1f2937";
    ctx.lineWidth = 0.5;
    for (let i = 1; i < 4; i++) {
      const y = chartY + (chartH / 4) * i;
      ctx.beginPath();
      ctx.moveTo(chartX, y);
      ctx.lineTo(chartX + chartW, y);
      ctx.stroke();
    }

    // Plot samples
    const okRtts = history.filter((s) => s.rtt !== null).map((s) => s.rtt as number);
    if (okRtts.length >= 2) {
      const maxR = Math.max(...okRtts, 1);
      const stepX = chartW / Math.max(history.length - 1, 1);
      ctx.strokeStyle = "#10b981";
      ctx.lineWidth = 2;
      ctx.beginPath();
      let started = false;
      history.forEach((s, i) => {
        const x = chartX + i * stepX;
        if (s.rtt === null) {
          // draw a red dot for packet loss
          ctx.fillStyle = "#ef4444";
          ctx.beginPath();
          ctx.arc(x, chartY + chartH - 4, 2, 0, Math.PI * 2);
          ctx.fill();
          started = false;
        } else {
          const y = chartY + chartH - (s.rtt / maxR) * (chartH - 8) - 4;
          if (!started) {
            ctx.moveTo(x, y);
            started = true;
          } else {
            ctx.lineTo(x, y);
          }
        }
      });
      ctx.stroke();

      // gradient fill under the line
      ctx.lineTo(chartX + (history.length - 1) * stepX, chartY + chartH);
      ctx.lineTo(chartX, chartY + chartH);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, chartY, 0, chartY + chartH);
      grad.addColorStop(0, "rgba(16,185,129,0.3)");
      grad.addColorStop(1, "rgba(16,185,129,0.02)");
      ctx.fillStyle = grad;
      ctx.fill();
    }

    // Alert history
    const alertY = 350;
    ctx.fillStyle = "#6b7280";
    ctx.font = "10px sans-serif";
    ctx.fillText(`ALERT HISTORY (${alertHistory.length})`, 24, alertY);
    if (alertHistory.length > 0) {
      alertHistory.slice(0, 5).forEach((event, i) => {
        const y = alertY + 18 + i * 16;
        ctx.fillStyle = "#ef4444";
        ctx.font = "bold 11px monospace";
        ctx.fillText(`${event.rtt}ms`, 24, y);
        ctx.fillStyle = "#6b7280";
        ctx.font = "10px sans-serif";
        ctx.fillText(
          `vs ${event.threshold}ms · ${new Date(event.timestamp).toLocaleTimeString()}`,
          80,
          y
        );
      });
    } else {
      ctx.fillStyle = "#4b5563";
      ctx.font = "11px sans-serif";
      ctx.fillText("No alerts during this session", 24, alertY + 18);
    }

    // Footer
    ctx.fillStyle = "#374151";
    ctx.font = "9px sans-serif";
    ctx.fillText(
      "Generated by ZSpeed — Advanced Internet Speed Checker",
      24,
      H - 12
    );

    // Download
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `zspeed-monitor-${Date.now()}.png`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Session image saved", {
        description: "Monitor sparkline + stats exported as PNG",
        icon: <ImageIcon className="h-4 w-4" />,
      });
    });
  }, [stats, history, elapsed, alertHistory]);

  // cleanup on unmount
  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
    };
  }, []);

  // Check notification permission on mount
  useEffect(() => {
    setNotifPermission(getNotificationPermission());
  }, []);

  const handleDesktopNotifsToggle = useCallback(async (enabled: boolean) => {
    if (enabled) {
      const perm = await requestNotificationPermission();
      setNotifPermission(perm);
      if (perm === "granted") {
        setDesktopNotifs(true);
        toast.success("Desktop notifications enabled", {
          description: "You'll get OS notifications when the tab is backgrounded",
          icon: <MonitorSmartphone className="h-4 w-4" />,
        });
      } else if (perm === "denied") {
        setDesktopNotifs(false);
        toast.error("Notifications blocked", {
          description: "Enable them in your browser settings to use this feature",
        });
      } else {
        setDesktopNotifs(false);
      }
    } else {
      setDesktopNotifs(false);
    }
  }, []);

  const current = stats?.current ?? null;
  const color = current === null
    ? "text-rose-500"
    : current < 30
    ? "text-emerald-500"
    : current < 80
    ? "text-teal-500"
    : current < 150
    ? "text-amber-500"
    : "text-rose-500";

  return (
    <Card
      className={`border bg-card/80 p-5 backdrop-blur transition-colors duration-300 sm:p-6 ${
        alertActive
          ? "border-rose-500/60 shadow-lg shadow-rose-500/10"
          : "border-border/60"
      }`}
    >
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Activity className="h-3.5 w-3.5 text-cyan-500" />
            Live Latency Monitor
            {alertActive && (
              <motion.span
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-1 rounded-full bg-rose-500/15 px-2 py-0.5 text-[10px] font-bold text-rose-600 dark:text-rose-400"
              >
                <AlertTriangle className="h-2.5 w-2.5 animate-pulse" />
                ALERT
              </motion.span>
            )}
          </div>
          <h3 className="mt-1 text-lg font-bold tracking-tight">
            Continuous ping stream
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Real-time latency every 1s with rolling 60-sample stats — a feature
            no standard speed test offers
          </p>
        </div>
        {running ? (
          <Button
            variant="destructive"
            size="sm"
            onClick={stop}
            className="gap-1.5"
          >
            <Square className="h-3.5 w-3.5" />
            Stop
          </Button>
        ) : (
          <Button
            size="sm"
            onClick={start}
            className="gap-1.5 bg-gradient-to-r from-cyan-500 to-teal-500 text-white hover:from-cyan-600 hover:to-teal-600"
          >
            <Play className="h-3.5 w-3.5" />
            Start Monitor
          </Button>
        )}
      </div>

      {/* Big live readout */}
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="col-span-2 rounded-xl border border-border/60 bg-gradient-to-br from-background/60 to-muted/20 p-4 sm:col-span-2">
          <div className="flex items-center justify-between text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            <span className="flex items-center gap-1.5">
              {running && (
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-cyan-500" />
                </span>
              )}
              Current Latency
            </span>
            <span className="tabular-nums">{formatTime(elapsed)}</span>
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <motion.span
              key={current ?? "lost"}
              initial={{ opacity: 0.5, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`text-4xl font-bold tabular-nums sm:text-5xl ${color}`}
            >
              {current === null ? "—" : Math.round(current)}
            </motion.span>
            <span className="text-sm text-muted-foreground">ms</span>
          </div>
          <div className="mt-1 flex items-center gap-2 text-xs">
            {current === null ? (
              <span className="flex items-center gap-1 text-rose-500">
                <WifiOff className="h-3 w-3" /> Packet lost
              </span>
            ) : current < 50 ? (
              <span className="flex items-center gap-1 text-emerald-500">
                <Wifi className="h-3 w-3" /> Excellent
              </span>
            ) : current < 100 ? (
              <span className="flex items-center gap-1 text-teal-500">
                <Wifi className="h-3 w-3" /> Good
              </span>
            ) : (
              <span className="flex items-center gap-1 text-amber-500">
                <Wifi className="h-3 w-3" /> Fair
              </span>
            )}
          </div>
        </div>

        <StatBox
          label="Average"
          value={stats ? formatMs(stats.avg) : "—"}
          icon={<Gauge className="h-3 w-3" />}
        />
        <StatBox
          label="Jitter"
          value={stats ? formatMs(stats.jitter) : "—"}
          icon={<Zap className="h-3 w-3" />}
          accent={
            !stats
              ? ""
              : stats.jitter < 10
              ? "text-emerald-500"
              : stats.jitter < 30
              ? "text-amber-500"
              : "text-rose-500"
          }
        />
      </div>

      {/* Live sparkline */}
      <div className="relative h-32 w-full overflow-hidden rounded-lg border border-border/60 bg-muted/20 p-2">
        <LiveSparkline samples={history} />
        {!running && history.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center text-xs text-muted-foreground">
            <Activity className="mr-1.5 h-3.5 w-3.5" />
            Click "Start Monitor" to begin streaming
          </div>
        )}
      </div>

      {/* Save as Image button — only when there's data */}
      {history.length > 0 && !running && (
        <Button
          onClick={handleSaveImage}
          variant="outline"
          size="sm"
          className="mt-3 w-full gap-2 border-cyan-500/40 text-cyan-600 hover:bg-cyan-500/10 dark:text-cyan-400"
        >
          <Download className="h-3.5 w-3.5" />
          Save session as image
        </Button>
      )}

      {/* Footer stats */}
      <AnimatePresence>
        {stats && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-4 grid grid-cols-4 gap-2 border-t border-border/60 pt-4">
              <FooterStat label="Min" value={formatMs(stats.min)} />
              <FooterStat label="Max" value={formatMs(stats.max)} />
              <FooterStat
                label="Loss"
                value={`${(stats.lossRate * 100).toFixed(1)}%`}
                accent={
                  stats.lossRate === 0
                    ? "text-emerald-500"
                    : stats.lossRate < 0.05
                    ? "text-amber-500"
                    : "text-rose-500"
                }
              />
              <FooterStat
                label="Packets"
                value={`${stats.received}/${stats.sent}`}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Alert configuration */}
      <div className="mt-4 rounded-lg border border-border/60 bg-background/40 p-3.5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {alertsEnabled ? (
              <BellRing className="h-4 w-4 text-amber-500" />
            ) : (
              <Bell className="h-4 w-4 text-muted-foreground" />
            )}
            <div>
              <Label
                htmlFor="alerts-toggle"
                className="cursor-pointer text-xs font-semibold"
              >
                Latency Alert
              </Label>
              <p className="text-[10px] text-muted-foreground">
                Notify when ping exceeds threshold
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {alertCount > 0 && running && (
              <Badge
                variant="outline"
                className="border-rose-500/40 text-rose-600 dark:text-rose-400"
              >
                {alertCount} alert{alertCount !== 1 ? "s" : ""}
              </Badge>
            )}
            <Switch
              id="alerts-toggle"
              checked={alertsEnabled}
              onCheckedChange={setAlertsEnabled}
            />
          </div>
        </div>
        <AnimatePresence>
          {alertsEnabled && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                  <span>Threshold</span>
                  <span
                    className={`tabular-nums ${
                      alertThreshold < 100
                        ? "text-emerald-500"
                        : alertThreshold < 200
                        ? "text-amber-500"
                        : "text-rose-500"
                    }`}
                  >
                    {alertThreshold} ms
                  </span>
                </div>
                <Slider
                  value={[alertThreshold]}
                  onValueChange={(v) => setAlertThreshold(v[0])}
                  min={20}
                  max={500}
                  step={10}
                  className="w-full"
                />
                <div className="flex justify-between text-[9px] text-muted-foreground">
                  <span>20ms</span>
                  <span>250ms</span>
                  <span>500ms</span>
                </div>
              </div>

              {/* Desktop notifications toggle */}
              <div className="mt-3 flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
                <div className="flex items-center gap-2">
                  <MonitorSmartphone className="h-4 w-4 text-cyan-500" />
                  <div>
                    <Label
                      htmlFor="desktop-notifs"
                      className="cursor-pointer text-xs font-semibold"
                    >
                      Desktop notifications
                    </Label>
                    <p className="text-[10px] text-muted-foreground">
                      {notifPermission === "granted"
                        ? "OS notifications when tab is backgrounded"
                        : notifPermission === "denied"
                        ? "Blocked — enable in browser settings"
                        : notifPermission === "unsupported"
                        ? "Not supported in this browser"
                        : "Get OS alerts even when this tab is hidden"}
                    </p>
                  </div>
                </div>
                <Switch
                  id="desktop-notifs"
                  checked={desktopNotifs}
                  onCheckedChange={handleDesktopNotifsToggle}
                  disabled={notifPermission === "denied" || notifPermission === "unsupported"}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Alert history log */}
      <AnimatePresence>
        {alertHistory.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                  <History className="h-3 w-3 text-rose-500" />
                  Alert History ({alertHistory.length})
                </span>
                {running && (
                  <button
                    onClick={() => setAlertHistory([])}
                    className="text-[10px] text-muted-foreground transition-colors hover:text-foreground"
                  >
                    Clear
                  </button>
                )}
              </div>
              <div className="max-h-40 space-y-1 overflow-y-auto scrollbar-thin rounded-lg border border-border/60 bg-background/40 p-2">
                {alertHistory.map((event) => {
                  const date = new Date(event.timestamp);
                  const timeStr = date.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                  });
                  return (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between rounded-md border border-rose-500/20 bg-rose-500/5 px-2.5 py-1.5"
                    >
                      <div className="flex items-center gap-2">
                        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-500/15">
                          <AlertTriangle className="h-2.5 w-2.5 text-rose-500" />
                        </span>
                        <span className="text-[11px] font-semibold tabular-nums text-rose-600 dark:text-rose-400">
                          {event.rtt}ms
                        </span>
                        <span className="text-[10px] text-muted-foreground">
                          vs {event.threshold}ms
                        </span>
                      </div>
                      <span className="font-mono text-[10px] text-muted-foreground">
                        {timeStr}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

function LiveSparkline({ samples }: { samples: MonitorSample[] }) {
  const W = 100;
  const H = 40;
  const okRtts = samples
    .filter((s) => s.rtt !== null)
    .map((s) => s.rtt as number);
  if (okRtts.length < 2) {
    return null;
  }
  const maxR = Math.max(...okRtts, 1);
  const minR = 0;
  const range = Math.max(maxR - minR, 1);
  const stepX = W / Math.max(samples.length - 1, 1);

  const points = samples.map((s, i) => {
    const x = i * stepX;
    const y =
      s.rtt === null
        ? H - 2 // packet loss at the bottom
        : H - ((s.rtt - minR) / range) * (H - 4) - 2;
    return { x, y, rtt: s.rtt };
  });

  // line path (skip null points by moving)
  let pathCmd = "";
  let lastValid: { x: number; y: number } | null = null;
  for (const p of points) {
    if (p.rtt === null) {
      // draw a gap marker
      lastValid = null;
      continue;
    }
    if (lastValid === null) {
      pathCmd += `M ${p.x.toFixed(2)} ${p.y.toFixed(2)} `;
    } else {
      pathCmd += `L ${p.x.toFixed(2)} ${p.y.toFixed(2)} `;
    }
    lastValid = p;
  }

  const gradId = "monitor-grad";

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none"
      className="h-full w-full"
    >
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.72 0.19 152)" stopOpacity={0.4} />
          <stop offset="100%" stopColor="oklch(0.72 0.19 152)" stopOpacity={0.02} />
        </linearGradient>
      </defs>
      {/* baseline grid */}
      {[0.25, 0.5, 0.75].map((f) => (
        <line
          key={f}
          x1="0"
          y1={H * f}
          x2={W}
          y2={H * f}
          stroke="currentColor"
          className="text-muted-foreground/15"
          strokeWidth="0.3"
          strokeDasharray="1 1"
        />
      ))}
      {/* loss markers */}
      {points.map((p, i) =>
        p.rtt === null ? (
          <circle
            key={i}
            cx={p.x}
            cy={H - 2}
            r="0.8"
            fill="oklch(0.65 0.22 25)"
          />
        ) : null
      )}
      <motion.path
        d={pathCmd}
        fill="none"
        stroke="oklch(0.72 0.19 152)"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.3 }}
      />
      {/* current point dot */}
      {points.length > 0 && points[points.length - 1].rtt !== null && (
        <motion.circle
          cx={points[points.length - 1].x}
          cy={points[points.length - 1].y}
          r="1.2"
          fill="oklch(0.72 0.19 152)"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 300 }}
        />
      )}
    </svg>
  );
}

function StatBox({
  label,
  value,
  icon,
  accent,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  accent?: string;
}) {
  return (
    <div className="rounded-xl border border-border/60 bg-background/40 p-3 text-center">
      <div className="flex items-center justify-center gap-1 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {icon}
        {label}
      </div>
      <div
        className={`mt-1 text-xl font-bold tabular-nums sm:text-2xl ${accent ?? ""}`}
      >
        {value}
      </div>
    </div>
  );
}

function FooterStat({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent?: string;
}) {
  return (
    <div className="rounded-lg border border-border/60 bg-background/40 p-2.5 text-center">
      <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className={`mt-0.5 text-sm font-bold tabular-nums ${accent ?? ""}`}>
        {value}
      </div>
    </div>
  );
}

function formatTime(s: number): string {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}:${sec.toString().padStart(2, "0")}`;
}
