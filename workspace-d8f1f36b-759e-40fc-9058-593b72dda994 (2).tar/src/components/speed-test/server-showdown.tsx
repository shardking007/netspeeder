"use client";

import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Swords, Zap, Timer, Trophy, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { runServerShowdown } from "@/lib/speedtest/engine";
import type { ShowdownEntry } from "@/lib/speedtest/engine";
import { SERVERS } from "@/lib/speedtest/servers";
import { formatMbps, formatMs } from "@/lib/speedtest/format";
import { toast } from "sonner";

export function ServerShowdown() {
  const [entries, setEntries] = useState<ShowdownEntry[] | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState("");
  const abortRef = useRef<AbortController | null>(null);

  const run = useCallback(async () => {
    setRunning(true);
    setProgress(0);
    setEntries(null);
    setMessage("Starting parallel showdown…");
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    try {
      const results = await runServerShowdown(
        SERVERS,
        (p) => {
          setProgress(p.progress);
          setMessage(p.message);
        },
        ac.signal
      );
      // Sort by download speed descending so the winner is on top
      results.sort((a, b) => b.downloadMbps - a.downloadMbps);
      setEntries(results);
      const winner = results[0];
      if (winner) {
        toast.success(`${winner.flag ?? ""} ${winner.serverName} wins!`, {
          description: `${formatMbps(winner.downloadMbps)} Mbps · ${formatMs(
            winner.pingMs
          )} ping`,
        });
      }
    } catch (e) {
      toast.error("Showdown failed", {
        description: e instanceof Error ? e.message : "unknown error",
      });
    } finally {
      setRunning(false);
    }
  }, []);

  const cancel = useCallback(() => {
    abortRef.current?.abort();
    setRunning(false);
    setMessage("Showdown cancelled");
  }, []);

  const maxSpeed = entries
    ? Math.max(...entries.map((e) => e.downloadMbps), 1)
    : 1;

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Swords className="h-3.5 w-3.5 text-amber-500" />
            Server Showdown
          </div>
          <h3 className="mt-1 text-lg font-bold tracking-tight">
            Multi-server parallel comparison
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Ping + quick download against all servers simultaneously — a feature
            standard speed tests don't offer
          </p>
        </div>
        {running ? (
          <Button variant="destructive" size="sm" onClick={cancel} className="gap-1.5">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Stop
          </Button>
        ) : (
          <Button
            size="sm"
            onClick={run}
            disabled={running}
            className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600"
          >
            <Swords className="h-3.5 w-3.5" />
            Run Showdown
          </Button>
        )}
      </div>

      <AnimatePresence>
        {running && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mb-4 space-y-2 rounded-lg border border-amber-500/20 bg-amber-500/5 p-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  Battling servers…
                </span>
                <span className="tabular-nums text-muted-foreground">
                  {Math.round(progress * 100)}%
                </span>
              </div>
              <Progress value={progress * 100} className="h-1.5" />
              <div className="text-xs text-muted-foreground">{message}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!entries && !running && (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border/60 bg-background/30 py-10 text-center">
          <Swords className="mb-2 h-8 w-8 text-amber-500/60" />
          <p className="text-sm font-medium">No showdown yet</p>
          <p className="mt-1 max-w-xs text-xs text-muted-foreground">
            Click "Run Showdown" to test all {SERVERS.length} servers in parallel
            and find the fastest.
          </p>
        </div>
      )}

      {entries && (
        <div className="space-y-3">
          {entries.map((e, i) => {
            const isWinner = i === 0;
            const widthPct = Math.max(
              4,
              (e.downloadMbps / maxSpeed) * 100
            );
            return (
              <motion.div
                key={e.serverId}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                className={`relative overflow-hidden rounded-xl border p-3 ${
                  isWinner
                    ? "border-amber-500/50 bg-gradient-to-r from-amber-500/10 to-transparent"
                    : "border-border/60 bg-background/40"
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">{e.flag}</span>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-semibold">
                          {e.serverName}
                        </span>
                        {isWinner && (
                          <Badge className="h-5 gap-1 bg-amber-500 px-1.5 text-[10px] text-white">
                            <Trophy className="h-2.5 w-2.5" /> WIN
                          </Badge>
                        )}
                      </div>
                      <div className="text-[11px] text-muted-foreground">
                        {e.location}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-right">
                    <div>
                      <div className="flex items-center justify-end gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                        <Zap className="h-2.5 w-2.5" />
                        Down
                      </div>
                      <div className="text-sm font-bold tabular-nums">
                        {formatMbps(e.downloadMbps)}
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-end gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                        <Timer className="h-2.5 w-2.5" />
                        Ping
                      </div>
                      <div className="text-sm font-bold tabular-nums">
                        {formatMs(e.pingMs)}
                      </div>
                    </div>
                  </div>
                </div>
                {/* speed bar */}
                <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-muted/60">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${widthPct}%` }}
                    transition={{ duration: 0.6, delay: 0.1 + i * 0.08, ease: "easeOut" }}
                    className={`h-full rounded-full ${
                      isWinner
                        ? "bg-gradient-to-r from-amber-400 to-orange-500"
                        : "bg-muted-foreground/50"
                    }`}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
