"use client";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Toggle } from "@/components/ui/toggle";
import { Gauge, Play, Square, ServerCog, Zap, Rocket, FlaskConical } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useT } from "@/components/speed-test/language-switcher";
import type { TestPhase } from "@/lib/speedtest/types";
import { SERVERS } from "@/lib/speedtest/servers";

interface TestControlPanelProps {
  serverId: string;
  onServerChange: (id: string) => void;
  running: boolean;
  phase: TestPhase;
  progress: number;
  message: string;
  quickMode: boolean;
  onQuickModeChange: (v: boolean) => void;
  onStart: () => void;
  onCancel: () => void;
}

const PHASE_LABEL: Record<TestPhase, string> = {
  idle: "Ready",
  ping: "Ping",
  download: "Download",
  upload: "Upload",
  "bufferbloat-down": "Bufferbloat ↓",
  "bufferbloat-up": "Bufferbloat ↑",
  dns: "DNS",
  complete: "Complete",
  error: "Error",
};

export function TestControlPanel({
  serverId,
  onServerChange,
  running,
  phase,
  progress,
  message,
  quickMode,
  onQuickModeChange,
  onStart,
  onCancel,
}: TestControlPanelProps) {
  const tt = useT();
  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <ServerCog className="h-3.5 w-3.5" />
            {tt("control.testServer")}
          </div>
          <Select value={serverId} onValueChange={onServerChange} disabled={running}>
            <SelectTrigger className="w-full sm:w-[260px]">
              <SelectValue placeholder={tt("control.selectServer")} />
            </SelectTrigger>
            <SelectContent>
              {SERVERS.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  <span className="mr-2">{s.flag}</span>
                  <span className="font-medium">{s.name}</span>
                  <span className="ml-2 text-xs text-muted-foreground">
                    {s.location}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick / Full toggle */}
          <div className="flex rounded-lg border border-border/60 bg-background/40 p-0.5">
            <button
              onClick={() => !running && onQuickModeChange(true)}
              disabled={running}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                quickMode
                  ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              } ${running ? "cursor-not-allowed opacity-50" : ""}`}
            >
              <Rocket className="h-3 w-3" />
              <span className="hidden sm:inline">{tt("control.quick")}</span>
            </button>
            <button
              onClick={() => !running && onQuickModeChange(false)}
              disabled={running}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                !quickMode
                  ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              } ${running ? "cursor-not-allowed opacity-50" : ""}`}
            >
              <FlaskConical className="h-3 w-3" />
              <span className="hidden sm:inline">{tt("control.full")}</span>
            </button>
          </div>

          {running ? (
            <Button
              variant="destructive"
              size="lg"
              onClick={onCancel}
              className="gap-2"
            >
              <Square className="h-4 w-4" />
              {tt("control.stop")}
            </Button>
          ) : (
            <Button
              size="lg"
              onClick={onStart}
              className={`gap-2 ${
                quickMode
                  ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600"
                  : ""
              }`}
            >
              <Play className="h-4 w-4" />
              {quickMode ? tt("control.quickTest") : tt("control.startTest")}
            </Button>
          )}
        </div>
      </div>

      <AnimatePresence>
        {running && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-5 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 font-medium uppercase tracking-wider text-muted-foreground">
                  <Zap className="h-3.5 w-3.5 text-amber-500" />
                  {PHASE_LABEL[phase]}
                </span>
                <span className="text-muted-foreground">
                  {Math.round(progress * 100)}%
                </span>
              </div>
              <Progress value={progress * 100} className="h-2" />
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Gauge className="h-3.5 w-3.5 animate-pulse" />
                {message}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}
