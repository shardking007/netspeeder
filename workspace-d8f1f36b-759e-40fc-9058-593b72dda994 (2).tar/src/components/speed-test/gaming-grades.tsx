"use client";

import { motion } from "framer-motion";
import { Gamepad2 } from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { GamingGrade } from "@/lib/speedtest/types";

interface GamingGradesProps {
  items: GamingGrade[];
}

function gradeBadgeClass(grade: GamingGrade["grade"]): string {
  switch (grade) {
    case "S":
      return "border-emerald-500/40 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300";
    case "A":
      return "border-teal-500/40 bg-teal-500/15 text-teal-600 dark:text-teal-300";
    case "B":
      return "border-amber-500/40 bg-amber-500/15 text-amber-600 dark:text-amber-300";
    case "C":
      return "border-orange-500/40 bg-orange-500/15 text-orange-600 dark:text-orange-300";
    case "D":
      return "border-rose-500/40 bg-rose-500/15 text-rose-600 dark:text-rose-300";
  }
}

export function GamingGrades({ items }: GamingGradesProps) {
  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="px-0">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <Gamepad2 className="h-4 w-4 text-muted-foreground" />
          Gaming Latency Grades
        </CardTitle>
        <CardDescription>
          How well your connection handles each genre of online game
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        {/* Mobile: card list */}
        <div className="flex flex-col gap-3 sm:hidden">
          {items.map((g, i) => (
            <motion.div
              key={g.genre}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.04 }}
              className="rounded-lg border border-border/60 bg-muted/20 p-3"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-semibold">{g.genre}</span>
                <Badge
                  variant="outline"
                  className={`px-2 py-0.5 text-xs font-bold ${gradeBadgeClass(g.grade)}`}
                >
                  {g.grade}
                </Badge>
              </div>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-xs font-medium text-muted-foreground">
                  {g.label}
                </span>
                <span
                  className={`text-[10px] font-semibold uppercase tracking-wider ${
                    g.playable ? "text-emerald-500" : "text-rose-500"
                  }`}
                >
                  {g.playable ? "Playable" : "Not playable"}
                </span>
              </div>
              <p className="mt-1.5 text-xs text-muted-foreground">{g.note}</p>
            </motion.div>
          ))}
        </div>

        {/* Desktop: table */}
        <div className="hidden sm:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="pl-0">Genre</TableHead>
                <TableHead className="w-16 text-center">Grade</TableHead>
                <TableHead>Label</TableHead>
                <TableHead className="w-24 text-center">Playable</TableHead>
                <TableHead className="pr-0">Note</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((g, i) => (
                <motion.tr
                  key={g.genre}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.04 }}
                  className="hover:bg-muted/50 border-b transition-colors"
                >
                  <TableCell className="pl-0 font-medium">{g.genre}</TableCell>
                  <TableCell className="text-center">
                    <Badge
                      variant="outline"
                      className={`px-2 py-0.5 text-xs font-bold ${gradeBadgeClass(g.grade)}`}
                    >
                      {g.grade}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{g.label}</TableCell>
                  <TableCell className="text-center">
                    <span
                      className={`text-xs font-semibold uppercase tracking-wider ${
                        g.playable ? "text-emerald-500" : "text-rose-500"
                      }`}
                    >
                      {g.playable ? "Yes" : "No"}
                    </span>
                  </TableCell>
                  <TableCell className="pr-0 text-xs text-muted-foreground">
                    {g.note}
                  </TableCell>
                </motion.tr>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
