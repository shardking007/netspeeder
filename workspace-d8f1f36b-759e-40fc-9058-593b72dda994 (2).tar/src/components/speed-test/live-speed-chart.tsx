"use client";

import { useId, useMemo } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ThroughputSample } from "@/lib/speedtest/types";

interface LiveSpeedChartProps {
  samples: ThroughputSample[];
  color?: string;
  height?: number;
  unit?: "Mbps" | "ms";
}

export function LiveSpeedChart({
  samples,
  color = "oklch(0.78 0.18 130)",
  height = 220,
  unit = "Mbps",
}: LiveSpeedChartProps) {
  const data = useMemo(
    () =>
      samples.map((s, i) => ({
        i,
        t: Number((s.t / 1000).toFixed(2)),
        v: Number(s.mbps.toFixed(2)),
      })),
    [samples]
  );

  const gradientId = `grad-${useId().replace(/:/g, "")}`;

  if (data.length === 0) {
    return (
      <div
        style={{ height }}
        className="flex items-center justify-center rounded-lg border border-dashed border-border/60 text-xs text-muted-foreground"
      >
        Waiting for samples…
      </div>
    );
  }

  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.55} />
              <stop offset="100%" stopColor={color} stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="currentColor"
            className="text-border/50"
            vertical={false}
          />
          <XAxis
            dataKey="t"
            type="number"
            domain={["dataMin", "dataMax"]}
            tickFormatter={(v) => `${v}s`}
            tick={{ fill: "currentColor", fontSize: 11 }}
            className="text-muted-foreground"
            stroke="currentColor"
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: "currentColor", fontSize: 11 }}
            className="text-muted-foreground"
            stroke="currentColor"
            axisLine={false}
            tickLine={false}
            width={48}
            tickFormatter={(v) => (unit === "ms" ? `${v}` : `${v}`)}
          />
          <Tooltip
            contentStyle={{
              background: "var(--popover)",
              border: "1px solid var(--border)",
              borderRadius: 8,
              fontSize: 12,
              color: "var(--popover-foreground)",
            }}
            labelFormatter={(v) => `${v}s`}
            formatter={(v: number) => [`${v} ${unit}`, "Speed"]}
          />
          <Area
            type="monotone"
            dataKey="v"
            stroke={color}
            strokeWidth={2.5}
            fill={`url(#${gradientId})`}
            isAnimationActive={false}
            dot={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
