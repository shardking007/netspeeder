"use client";

import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { useEffect } from "react";
import { PhoneCall } from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { VoIPScore } from "@/lib/speedtest/types";

interface VoIPScoreCardProps {
  voip: VoIPScore;
}

function qualityBadgeClass(quality: VoIPScore["quality"]): string {
  switch (quality) {
    case "Excellent":
      return "border-emerald-500/40 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300";
    case "Good":
      return "border-teal-500/40 bg-teal-500/15 text-teal-600 dark:text-teal-300";
    case "Fair":
      return "border-amber-500/40 bg-amber-500/15 text-amber-600 dark:text-amber-300";
    case "Poor":
      return "border-orange-500/40 bg-orange-500/15 text-orange-600 dark:text-orange-300";
    case "Bad":
      return "border-rose-500/40 bg-rose-500/15 text-rose-600 dark:text-rose-300";
  }
}

function CountUp({
  to,
  decimals = 1,
  duration = 1,
}: {
  to: number;
  decimals?: number;
  duration?: number;
}) {
  const count = useMotionValue(0);
  const formatted = useTransform(count, (v) => v.toFixed(decimals));

  useEffect(() => {
    const controls = animate(count, to, { duration, ease: "easeOut" });
    return controls.stop;
  }, [to, count, duration]);

  return <motion.span>{formatted}</motion.span>;
}

export function VoIPScoreCard({ voip }: VoIPScoreCardProps) {
  const { mos, quality, rValue, recommendation } = voip;

  // MOS goes 0..5, but practical floor is 1
  const mosRatio = Math.min(1, Math.max(0, (mos - 1) / 4));
  const markerPct = mosRatio * 100;

  // Color zones on the MOS meter
  const zones = [
    { from: 0, to: 25, color: "bg-rose-500" },
    { from: 25, to: 44, color: "bg-orange-500" },
    { from: 44, to: 62, color: "bg-amber-500" },
    { from: 62, to: 76, color: "bg-teal-500" },
    { from: 76, to: 100, color: "bg-emerald-500" },
  ];

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="px-0">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <PhoneCall className="h-4 w-4 text-muted-foreground" />
          VoIP Call Quality
        </CardTitle>
        <CardDescription>
          Estimated voice call clarity using the ITU E-model (MOS)
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        <div className="flex flex-col gap-5">
          {/* Top row: MOS + R-value */}
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                MOS Score
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-4xl font-bold tabular-nums sm:text-5xl">
                  <CountUp to={mos} decimals={1} />
                </span>
                <span className="text-sm text-muted-foreground">/ 5</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Quality
              </span>
              <Badge
                variant="outline"
                className={`px-2.5 py-1 text-xs font-semibold ${qualityBadgeClass(quality)}`}
              >
                {quality}
              </Badge>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                R-Value
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold tabular-nums">
                  <CountUp to={rValue} decimals={0} />
                </span>
                <span className="text-xs text-muted-foreground">/ 100</span>
              </div>
            </div>
          </div>

          {/* MOS meter */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>1.0 — Bad</span>
              <span className="font-medium uppercase tracking-wider">MOS Meter</span>
              <span>5.0 — Excellent</span>
            </div>
            <div className="relative h-3 w-full overflow-hidden rounded-full">
              <div className="absolute inset-0 flex">
                {zones.map((z, i) => (
                  <div
                    key={i}
                    className={z.color}
                    style={{ width: `${z.to - z.from}%` }}
                  />
                ))}
              </div>
              {/* Marker */}
              <motion.div
                className="absolute top-1/2 z-10 h-5 w-1.5 -translate-y-1/2 rounded-full bg-foreground shadow"
                initial={{ left: 0 }}
                animate={{ left: `${markerPct}%` }}
                transition={{ type: "spring", stiffness: 90, damping: 18, delay: 0.2 }}
                style={{ transform: "translate(-50%, -50%)" }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>Poor</span>
              <span>Fair</span>
              <span>Good</span>
              <span>Excellent</span>
            </div>
          </div>

          {/* Recommendation */}
          <div className="rounded-lg border border-border/60 bg-muted/30 p-3">
            <p className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Recommendation. </span>
              {recommendation}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
