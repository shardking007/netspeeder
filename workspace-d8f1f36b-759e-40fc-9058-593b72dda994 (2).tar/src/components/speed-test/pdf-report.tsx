"use client";

import { motion } from "framer-motion";
import { FileText, Download } from "lucide-react";
import { toast } from "sonner";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { SpeedTestResult } from "@/lib/speedtest/types";
import { formatMbps, formatMs } from "@/lib/speedtest/format";

interface PdfReportProps {
  result: SpeedTestResult | null;
}

export function PdfReport({ result }: PdfReportProps) {
  const disabled = !result;

  function handlePrint() {
    if (!result) return;
    const html = buildReportHtml(result);
    const w = window.open("", "_blank");
    if (!w) {
      toast.error("Pop-up blocked", {
        description: "Allow pop-ups to generate a PDF report",
      });
      return;
    }
    w.document.write(html);
    w.document.close();
    // Give the browser a moment to render before printing
    setTimeout(() => {
      w.focus();
      w.print();
    }, 300);
    toast.success("Report opened", {
      description: "Use 'Save as PDF' in the print dialog",
    });
  }

  return (
    <Card className="border-border/60 bg-card/80 p-5 backdrop-blur sm:p-6">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <FileText className="h-4 w-4 text-rose-500" />
          PDF Report
        </CardTitle>
        <CardDescription>Printable results summary</CardDescription>
      </CardHeader>
      <CardContent>
        {disabled ? (
          <motion.p
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-md border border-dashed border-border/60 bg-muted/20 px-4 py-4 text-center text-xs text-muted-foreground"
          >
            Run a test first to generate a report
          </motion.p>
        ) : (
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">
              Opens a print-optimized report in a new tab. Use your browser's
              "Save as PDF" option in the print dialog to save it.
            </p>
            <Button
              onClick={handlePrint}
              className="w-full justify-center gap-2 bg-gradient-to-r from-rose-500 to-orange-500 text-white hover:from-rose-600 hover:to-orange-600"
            >
              <Download className="h-4 w-4" />
              Generate PDF Report
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function buildReportHtml(r: SpeedTestResult): string {
  const date = new Date(r.timestamp).toLocaleString();
  const gradeColor: Record<string, string> = {
    "A+": "#10b981",
    A: "#10b981",
    B: "#14b8a6",
    C: "#f59e0b",
    D: "#f97316",
    F: "#ef4444",
  };
  const nqsColor = gradeColor[r.nqs.grade] ?? "#6b7280";

  const metricRow = (
    label: string,
    value: string,
    sub: string,
    color: string
  ) => `
    <div class="metric">
      <div class="metric-label">${label}</div>
      <div class="metric-value" style="color:${color}">${value}</div>
      <div class="metric-sub">${sub}</div>
    </div>`;

  const streamingRows = r.streaming
    .map(
      (s) => `
      <tr>
        <td>${s.platform}</td>
        <td><span class="badge ${s.canStream ? "badge-ok" : "badge-bad"}">${s.maxResolution}</span></td>
        <td>${s.bitrate}</td>
        <td>${s.recommendation}</td>
      </tr>`
    )
    .join("");

  const gamingRows = r.gaming
    .map(
      (g) => `
      <tr>
        <td>${g.genre}</td>
        <td><span class="grade" style="color:${gradeColor[g.grade] ?? "#6b7280"}">${g.grade}</span></td>
        <td>${g.label}</td>
        <td>${g.playable ? "✓" : "✗"}</td>
      </tr>`
    )
    .join("");

  const dnsRows = r.dns
    .map(
      (d) => `
      <tr>
        <td>${d.domain}</td>
        <td>${d.ok ? Math.round(d.lookupMs) + " ms" : "failed"}</td>
        <td>${d.ok ? "✓" : "✗"}</td>
      </tr>`
    )
    .join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ZSpeed Report — ${date}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #1a1a1a; background: #fff; padding: 40px; max-width: 800px; margin: 0 auto; }
  .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #10b981; padding-bottom: 16px; margin-bottom: 24px; }
  .header h1 { font-size: 28px; font-weight: 800; }
  .header .subtitle { font-size: 12px; color: #6b7280; margin-top: 4px; }
  .nqs-box { text-align: right; }
  .nqs-box .score { font-size: 48px; font-weight: 800; line-height: 1; }
  .nqs-box .grade { font-size: 14px; font-weight: 600; margin-top: 4px; }
  .nqs-box .label { font-size: 10px; color: #6b7280; text-transform: uppercase; letter-spacing: 1px; }
  .section { margin-bottom: 24px; }
  .section-title { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: #6b7280; margin-bottom: 12px; border-bottom: 1px solid #e5e7eb; padding-bottom: 6px; }
  .metrics-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; }
  .metric { text-align: center; border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px 8px; }
  .metric-label { font-size: 9px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #6b7280; }
  .metric-value { font-size: 22px; font-weight: 800; margin: 4px 0 2px; }
  .metric-sub { font-size: 9px; color: #6b7280; }
  .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .info-box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px; }
  .info-box h3 { font-size: 12px; font-weight: 700; margin-bottom: 8px; }
  .info-box dl { display: grid; grid-template-columns: auto 1fr; gap: 4px 12px; font-size: 11px; }
  .info-box dt { color: #6b7280; font-weight: 600; }
  .info-box dd { font-family: monospace; word-break: break-all; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; }
  th { text-align: left; font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #6b7280; padding: 6px 8px; border-bottom: 2px solid #e5e7eb; }
  td { padding: 6px 8px; border-bottom: 1px solid #f3f4f6; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 700; }
  .badge-ok { background: #d1fae5; color: #065f46; }
  .badge-bad { background: #fee2e2; color: #991b1b; }
  .grade { font-size: 16px; font-weight: 800; }
  .footer { margin-top: 32px; padding-top: 16px; border-top: 1px solid #e5e7eb; font-size: 10px; color: #6b7280; text-align: center; }
  @media print { body { padding: 20px; } .no-print { display: none; } }
</style>
</head>
<body>
  <div class="header">
    <div>
      <h1>ZSpeed Report</h1>
      <div class="subtitle">${date} · ${r.serverName} · ${r.connection.timezone ?? "Unknown TZ"}</div>
    </div>
    <div class="nqs-box">
      <div class="score" style="color:${nqsColor}">${r.nqs.total}</div>
      <div class="grade" style="color:${nqsColor}">Grade ${r.nqs.grade}</div>
      <div class="label">${r.nqs.label}</div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Headline Metrics</div>
    <div class="metrics-grid">
      ${metricRow("Download", formatMbps(r.download.mbps), `peak ${formatMbps(r.download.peakMbps)} Mbps`, "#10b981")}
      ${metricRow("Upload", formatMbps(r.upload.mbps), `peak ${formatMbps(r.upload.peakMbps)} Mbps`, "#14b8a6")}
      ${metricRow("Ping", formatMs(r.ping.avg), `min ${formatMs(r.ping.min)}`, "#f59e0b")}
      ${metricRow("Jitter", formatMs(r.ping.jitter), `max ${formatMs(r.ping.max)}`, "#06b6d4")}
      ${metricRow("Loss", (r.ping.packetLoss * 100).toFixed(1) + "%", `${r.ping.received}/${r.ping.sent} pkts`, "#ef4444")}
    </div>
  </div>

  <div class="section">
    <div class="section-title">Bufferbloat Analysis</div>
    <div class="two-col">
      <div class="info-box">
        <h3>Latency Under Load</h3>
        <dl>
          <dt>Baseline</dt><dd>${formatMs(r.bufferbloat.baselineLatency)}</dd>
          <dt>Under load</dt><dd>${formatMs(r.bufferbloat.latencyUnderLoad)}</dd>
          <dt>Added</dt><dd>+${Math.round(r.bufferbloat.delta)} ms</dd>
          <dt>Grade</dt><dd style="color:${gradeColor[r.bufferbloat.grade] ?? "#6b7280"}">${r.bufferbloat.grade}</dd>
        </dl>
      </div>
      <div class="info-box">
        <h3>VoIP Quality</h3>
        <dl>
          <dt>MOS</dt><dd>${r.voip.mos} / 5.0</dd>
          <dt>Quality</dt><dd>${r.voip.quality}</dd>
          <dt>R-value</dt><dd>${r.voip.rValue} / 100</dd>
          <dt>Assessment</dt><dd>${r.voip.recommendation}</dd>
        </dl>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Streaming Quality Predictor</div>
    <table>
      <thead><tr><th>Platform</th><th>Max Resolution</th><th>Bitrate</th><th>Recommendation</th></tr></thead>
      <tbody>${streamingRows}</tbody>
    </table>
  </div>

  <div class="section">
    <div class="section-title">Gaming Latency Grades</div>
    <table>
      <thead><tr><th>Genre</th><th>Grade</th><th>Label</th><th>Playable</th></tr></thead>
      <tbody>${gamingRows}</tbody>
    </table>
  </div>

  <div class="section">
    <div class="section-title">DNS Resolution Speed</div>
    <table>
      <thead><tr><th>Domain</th><th>Lookup Time</th><th>Status</th></tr></thead>
      <tbody>${dnsRows}</tbody>
    </table>
  </div>

  <div class="section">
    <div class="section-title">Network Diagnostics</div>
    <div class="info-box">
      <dl>
        <dt>IP Address</dt><dd>${r.connection.ip ?? "unknown"}</dd>
        <dt>Region</dt><dd>${r.connection.country ?? "unknown"}</dd>
        <dt>City</dt><dd>${r.connection.city ?? "unknown"}</dd>
        <dt>Timezone</dt><dd>${r.connection.timezone ?? "unknown"}</dd>
        <dt>Effective Type</dt><dd>${r.connection.effectiveType ?? "unknown"}</dd>
        <dt>Downlink (est.)</dt><dd>${r.connection.downlink ? r.connection.downlink + " Mbps" : "unknown"}</dd>
        <dt>RTT (est.)</dt><dd>${r.connection.rtt ? r.connection.rtt + " ms" : "unknown"}</dd>
        <dt>Online</dt><dd>${r.connection.online ? "Yes" : "No"}</dd>
        <dt>User Agent</dt><dd style="font-size:9px">${r.connection.userAgent}</dd>
      </dl>
    </div>
  </div>

  <div class="footer">
    Generated by ZSpeed — Advanced Internet Speed Checker · ${new Date().toLocaleDateString()}
  </div>
</body>
</html>`;
}
