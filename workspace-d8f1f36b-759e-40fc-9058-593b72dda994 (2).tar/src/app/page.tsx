"use client";

import { useCallback, useEffect, useMemo, useState, useSyncExternalStore } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity,
  BarChart3,
  Clapperboard,
  Gamepad2,
  Globe,
  History,
  ServerCog,
  Shield,
  Timer,
  Wifi,
  Zap,
  Download,
  Upload,
  ArrowDown,
  ArrowUp,
  Gauge as GaugeIcon,
  PhoneCall,
  Share2,
  Cpu,
} from "lucide-react";
import { useSpeedTest } from "@/hooks/use-speed-test";
import { SERVERS, getServer } from "@/lib/speedtest/servers";
import {
  historyStore,
  clearHistory,
  deleteResult,
} from "@/lib/speedtest/history";
import { formatMbps, formatMs } from "@/lib/speedtest/format";
import { ThemeToggle } from "@/components/speed-test/theme-toggle";
import { SpeedGauge } from "@/components/speed-test/speed-gauge";
import { LiveSpeedChart } from "@/components/speed-test/live-speed-chart";
import { TestControlPanel } from "@/components/speed-test/test-control-panel";
import { ResultOverview } from "@/components/speed-test/result-overview";
import { QualityScoreCard } from "@/components/speed-test/quality-score-card";
import { BufferbloatCard } from "@/components/speed-test/bufferbloat-card";
import { StreamingPredictor } from "@/components/speed-test/streaming-predictor";
import { GamingGrades } from "@/components/speed-test/gaming-grades";
import { VoIPScoreCard } from "@/components/speed-test/voip-score";
import { DnsCard } from "@/components/speed-test/dns-card";
import { HistoryPanel } from "@/components/speed-test/history-panel";
import { DiagnosticsPanel } from "@/components/speed-test/diagnostics-panel";
import { ExportPanel } from "@/components/speed-test/export-panel";
import { GlobalComparison } from "@/components/speed-test/global-comparison";
import { ServerShowdown } from "@/components/speed-test/server-showdown";
import { StabilitySparkline } from "@/components/speed-test/stability-sparkline";
import { SharedResultView } from "@/components/speed-test/shared-result-view";
import { LiveMonitor } from "@/components/speed-test/live-monitor";
import { ResultsComparison } from "@/components/speed-test/results-comparison";
import { ScheduledAutoTest } from "@/components/speed-test/scheduled-auto-test";
import { HistoryStats } from "@/components/speed-test/history-stats";
import { PdfReport } from "@/components/speed-test/pdf-report";
import { useT } from "@/components/speed-test/language-switcher";
import type { TranslationKey } from "@/lib/speedtest/i18n";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { readSharedFromHash } from "@/lib/speedtest/share";
import { settingsStore, updateSettings } from "@/lib/speedtest/settings";

type TabKey =
  | "overview"
  | "quality"
  | "compare"
  | "streaming"
  | "gaming"
  | "voip"
  | "dns"
  | "diagnostics"
  | "history"
  | "monitor"
  | "export";

const TABS: { key: TabKey; labelKey: TranslationKey; icon: React.ReactNode }[] = [
  { key: "overview", labelKey: "tab.overview", icon: <BarChart3 className="h-3.5 w-3.5" /> },
  { key: "quality", labelKey: "tab.quality", icon: <Shield className="h-3.5 w-3.5" /> },
  { key: "compare", labelKey: "tab.compare", icon: <Globe className="h-3.5 w-3.5" /> },
  { key: "streaming", labelKey: "tab.streaming", icon: <Clapperboard className="h-3.5 w-3.5" /> },
  { key: "gaming", labelKey: "tab.gaming", icon: <Gamepad2 className="h-3.5 w-3.5" /> },
  { key: "voip", labelKey: "tab.voip", icon: <PhoneCall className="h-3.5 w-3.5" /> },
  { key: "dns", labelKey: "tab.dns", icon: <Globe className="h-3.5 w-3.5" /> },
  { key: "monitor", labelKey: "tab.monitor", icon: <Activity className="h-3.5 w-3.5" /> },
  { key: "diagnostics", labelKey: "tab.diagnostics", icon: <Cpu className="h-3.5 w-3.5" /> },
  { key: "history", labelKey: "tab.history", icon: <History className="h-3.5 w-3.5" /> },
  { key: "export", labelKey: "tab.export", icon: <Share2 className="h-3.5 w-3.5" /> },
];

export default function Home() {
  const tt = useT();
  const speedTest = useSpeedTest({
    onComplete: () => {
      setTab("overview");
    },
  });
  // Persisted settings (selected server)
  const settings = useSyncExternalStore(
    settingsStore.subscribe,
    settingsStore.getSnapshot,
    settingsStore.getServerSnapshot
  );
  const [serverId, setServerId] = useState(settings.serverId);

  // Shared result from URL hash (#r=...)
  const [sharedResult, setSharedResult] = useState(() => readSharedFromHash());

  // Re-check hash on hashchange (e.g. user pastes a new share link)
  useEffect(() => {
    const onHash = () => setSharedResult(readSharedFromHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const history = useSyncExternalStore(
    historyStore.subscribe,
    historyStore.getSnapshot,
    historyStore.getServerSnapshot
  );
  const [tab, setTab] = useState<TabKey>("overview");

  const [quickMode, setQuickMode] = useState(false);
  const handleStart = useCallback(() => speedTest.run(serverId, quickMode), [speedTest, serverId, quickMode]);
  const handleClearHistory = () => {
    clearHistory();
  };
  const handleDelete = (id: string) => {
    deleteResult(id);
  };
  const handleServerChange = (id: string) => {
    setServerId(id);
    updateSettings({ serverId: id });
  };

  const result = speedTest.result;

  // Keyboard shortcuts: Space = start/stop, 1-9 = tabs
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // Don't intercept when typing in an input/textarea
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable ||
          target.tagName === "SELECT")
      ) {
        return;
      }
      if (e.code === "Space") {
        e.preventDefault();
        if (speedTest.running) speedTest.cancel();
        else handleStart();
        return;
      }
      if (e.key >= "1" && e.key <= "9") {
        const idx = parseInt(e.key, 10) - 1;
        if (idx < TABS.length) setTab(TABS[idx].key);
        return;
      }
      if (e.key === "0" && TABS.length >= 10) {
        setTab(TABS[9].key);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [speedTest.running, serverId, handleStart, speedTest.cancel]);

  // Determine what the gauge shows based on phase
  const gaugeConfig = useMemo(() => {
    if (speedTest.running) {
      if (
        speedTest.phase === "ping" ||
        speedTest.phase === "bufferbloat-down" ||
        speedTest.phase === "bufferbloat-up"
      ) {
        return {
          value: 0,
          pingMode: true,
          pingValue: speedTest.currentPing || 0,
          label: "Ping",
          active: true,
        };
      }
      if (speedTest.phase === "download" || speedTest.phase === "bufferbloat-down") {
        return {
          value: speedTest.currentMbps || 0,
          pingMode: false,
          label: "Download",
          active: true,
        };
      }
      if (speedTest.phase === "upload" || speedTest.phase === "bufferbloat-up") {
        return {
          value: speedTest.currentMbps || 0,
          pingMode: false,
          label: "Upload",
          active: true,
        };
      }
    }
    if (result) {
      return {
        value: result.download.mbps,
        pingMode: false,
        label: "Download",
        active: false,
      };
    }
    return { value: 0, pingMode: false, label: "Ready", active: false };
  }, [speedTest, result]);

  const liveChartColor =
    speedTest.phase === "upload" || speedTest.phase === "bufferbloat-up"
      ? "oklch(0.78 0.18 130)"
      : "oklch(0.72 0.19 152)";

  const hasResult = !!result;

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Decorative grid background */}
      <div className="pointer-events-none fixed inset-0 -z-10 bg-grid bg-grid-fade opacity-[0.35]" />
      {/* Animated gradient orbs */}
      <motion.div
        suppressHydrationWarning
        className="pointer-events-none fixed -left-32 top-20 -z-10 h-96 w-96 rounded-full bg-emerald-500/10 blur-3xl"
        animate={{ x: [0, 40, 0], y: [0, -30, 0], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        suppressHydrationWarning
        className="pointer-events-none fixed -right-32 top-40 -z-10 h-96 w-96 rounded-full bg-teal-500/10 blur-3xl"
        animate={{ x: [0, -40, 0], y: [0, 40, 0], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        suppressHydrationWarning
        className="pointer-events-none fixed left-1/2 top-1/2 -z-10 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-violet-500/5 blur-3xl"
        animate={{ scale: [1, 1.1, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(ellipse_60%_50%_at_50%_-10%,oklch(0.72_0.19_152/0.12),transparent)]" />

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border/40 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/20">
              <GaugeIcon className="h-5 w-5 text-white" />
            </div>
            <div className="leading-tight">
              <div className="flex items-center gap-2">
                <span className="text-base font-bold tracking-tight">{tt("app.title")}</span>
                <Badge
                  variant="secondary"
                  className="hidden h-5 px-1.5 text-[10px] font-semibold uppercase tracking-wider sm:inline-flex"
                >
                  {tt("app.badge")}
                </Badge>
              </div>
              <span className="hidden text-[11px] text-muted-foreground sm:inline">
                {tt("app.subtitle")}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-1.5 rounded-full border border-border/60 bg-card/60 px-3 py-1 text-xs text-muted-foreground md:flex">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              </span>
              {getServer(serverId).flag} {getServer(serverId).name}
            </div>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        {sharedResult ? (
          <SharedResultView data={sharedResult} />
        ) : (
          <>
        {/* Hero */}
        <section className="grid gap-5 lg:grid-cols-[1.1fr_1fr] lg:gap-6">
          {/* Gauge card */}
          <div className="relative overflow-hidden rounded-2xl border border-border/60 bg-card/70 p-6 backdrop-blur-xl sm:p-8">
            {/* Animated ambient glow behind the gauge */}
            <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-gradient-to-br from-emerald-500/20 via-teal-500/10 to-transparent blur-3xl" />
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_0%,oklch(0.72_0.19_152/0.08),transparent)]" />
            <div className="relative">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  <span className="relative flex h-2 w-2">
                    {speedTest.running ? (
                      <>
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-75" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-amber-500" />
                      </>
                    ) : (
                      <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                    )}
                  </span>
                  {speedTest.running ? tt("hero.liveMeasurement") : hasResult ? tt("hero.latestResult") : tt("hero.speedTest")}
                </div>
                <h1 className="mt-1 bg-gradient-to-br from-foreground via-foreground to-foreground/60 bg-clip-text text-xl font-bold tracking-tight text-transparent sm:text-2xl">
                  {speedTest.running
                    ? speedTest.message
                    : hasResult
                    ? tt("hero.latestResult")
                    : tt("hero.testYourConnection")}
                </h1>
              </div>
              {speedTest.running && (
                <Badge className="animate-pulse border-amber-500/40 bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <Zap className="mr-1 h-3 w-3" />
                  {tt("hero.running")}
                </Badge>
              )}
            </div>
            <div className="flex flex-col items-center">
              <SpeedGauge {...gaugeConfig} />
              {/* quick stats under gauge */}
              <div className="mt-6 grid w-full grid-cols-3 gap-3">
                <MiniStat
                  icon={<ArrowDown className="h-3.5 w-3.5" />}
                  label={tt("hero.down")}
                  value={
                    hasResult
                      ? formatMbps(result!.download.mbps)
                      : speedTest.phase === "download"
                      ? formatMbps(speedTest.currentMbps)
                      : "—"
                  }
                  unit="Mbps"
                  color="text-emerald-500"
                />
                <MiniStat
                  icon={<ArrowUp className="h-3.5 w-3.5" />}
                  label={tt("hero.up")}
                  value={
                    hasResult
                      ? formatMbps(result!.upload.mbps)
                      : speedTest.phase === "upload"
                      ? formatMbps(speedTest.currentMbps)
                      : "—"
                  }
                  unit="Mbps"
                  color="text-teal-500"
                />
                <MiniStat
                  icon={<Timer className="h-3.5 w-3.5" />}
                  label={tt("hero.ping")}
                  value={
                    hasResult
                      ? formatMs(result!.ping.avg)
                      : speedTest.currentPing
                      ? formatMs(speedTest.currentPing)
                      : "—"
                  }
                  unit=""
                  color="text-amber-500"
                />
              </div>
            </div>
            </div>
          </div>

          {/* Right column: control + live chart */}
          <div className="flex flex-col gap-5">
            <TestControlPanel
              serverId={serverId}
              onServerChange={handleServerChange}
              running={speedTest.running}
              phase={speedTest.phase}
              progress={speedTest.progress}
              message={speedTest.message}
              quickMode={quickMode}
              onQuickModeChange={setQuickMode}
              onStart={handleStart}
              onCancel={speedTest.cancel}
            />

            <div className="rounded-2xl border border-border/60 bg-card/70 p-5 backdrop-blur-xl sm:p-6">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  <Activity className="h-3.5 w-3.5" />
                  {speedTest.phase === "upload" || speedTest.phase === "bufferbloat-up"
                    ? "Upload Throughput"
                    : "Download Throughput"}
                </div>
                <span className="text-xs tabular-nums text-muted-foreground">
                  {speedTest.running
                    ? `${formatMbps(speedTest.currentMbps)} Mbps`
                    : hasResult
                    ? `${formatMbps(
                        speedTest.phase === "upload" || speedTest.phase === "bufferbloat-up"
                          ? result!.upload.mbps
                          : result!.download.mbps
                      )} Mbps`
                    : "— Mbps"}
                </span>
              </div>
              <LiveSpeedChart
                samples={
                  speedTest.phase === "upload" || speedTest.phase === "bufferbloat-up"
                    ? speedTest.liveUploadSamples
                    : speedTest.liveDownloadSamples
                }
                color={liveChartColor}
                height={200}
              />
            </div>
          </div>
        </section>

        {/* Feature highlights */}
        <section className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <FeatureChip
            icon={<Shield className="h-4 w-4" />}
            label="Network Quality Score"
            color="from-emerald-500/20 to-emerald-500/5 text-emerald-500"
          />
          <FeatureChip
            icon={<Zap className="h-4 w-4" />}
            label="Bufferbloat Analysis"
            color="from-amber-500/20 to-amber-500/5 text-amber-500"
          />
          <FeatureChip
            icon={<Clapperboard className="h-4 w-4" />}
            label="Streaming Predictor"
            color="from-rose-500/20 to-rose-500/5 text-rose-500"
          />
          <FeatureChip
            icon={<Gamepad2 className="h-4 w-4" />}
            label="Gaming & VoIP Grades"
            color="from-teal-500/20 to-teal-500/5 text-teal-500"
          />
        </section>

        {/* Tabs results */}
        <section className="mt-6">
          <Tabs value={tab} onValueChange={(v) => setTab(v as TabKey)}>
            <div className="overflow-x-auto">
              <TabsList className="mb-5 flex h-auto w-max gap-1 bg-card/60 p-1.5 backdrop-blur">
                {TABS.map((t) => (
                  <TabsTrigger
                    key={t.key}
                    value={t.key}
                    className="gap-1.5 px-3 py-1.5 text-xs data-[state=active]:bg-background"
                  >
                    {t.icon}
                    <span className="hidden sm:inline">{tt(t.labelKey)}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={tab}
                suppressHydrationWarning
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18 }}
              >
                {/* OVERVIEW */}
                <TabsContent value="overview" className="mt-0">
                  {hasResult ? (
                    <div className="space-y-5">
                      <ResultOverview result={result!} />
                      <div className="grid gap-5 lg:grid-cols-2">
                        <QualityScoreCard nqs={result!.nqs} />
                        <BufferbloatCard result={result!.bufferbloat} />
                      </div>
                    </div>
                  ) : (
                    <EmptyState />
                  )}
                </TabsContent>

                {/* QUALITY */}
                <TabsContent value="quality" className="mt-0">
                  {hasResult ? (
                    <div className="space-y-5">
                      <div className="grid gap-5 lg:grid-cols-2">
                        <QualityScoreCard nqs={result!.nqs} />
                        <BufferbloatCard result={result!.bufferbloat} />
                      </div>
                      <StabilitySparkline ping={result!.ping} />
                    </div>
                  ) : (
                    <EmptyState />
                  )}
                </TabsContent>

                {/* COMPARE */}
                <TabsContent value="compare" className="mt-0">
                  <div className="space-y-5">
                    {hasResult ? (
                      <GlobalComparison
                        download={result!.download}
                        upload={result!.upload}
                        ping={result!.ping}
                      />
                    ) : (
                      <div className="flex min-h-[200px] flex-col items-center justify-center rounded-2xl border border-dashed border-border/60 bg-card/40 p-8 text-center">
                        <Globe className="mb-2 h-8 w-8 text-violet-500/60" />
                        <p className="text-sm font-medium">Run a test first</p>
                        <p className="mt-1 max-w-xs text-xs text-muted-foreground">
                          The global comparison shows your percentile ranking
                          once you have a measured download speed.
                        </p>
                      </div>
                    )}
                    <ServerShowdown />
                  </div>
                </TabsContent>

                {/* STREAMING */}
                <TabsContent value="streaming" className="mt-0">
                  {hasResult ? (
                    <StreamingPredictor
                      items={result!.streaming}
                      downloadMbps={result!.download.mbps}
                    />
                  ) : (
                    <EmptyState />
                  )}
                </TabsContent>

                {/* GAMING */}
                <TabsContent value="gaming" className="mt-0">
                  {hasResult ? (
                    <GamingGrades items={result!.gaming} />
                  ) : (
                    <EmptyState />
                  )}
                </TabsContent>

                {/* VOIP */}
                <TabsContent value="voip" className="mt-0">
                  {hasResult ? (
                    <VoIPScoreCard voip={result!.voip} />
                  ) : (
                    <EmptyState />
                  )}
                </TabsContent>

                {/* DNS */}
                <TabsContent value="dns" className="mt-0">
                  {hasResult ? (
                    <DnsCard results={result!.dns} />
                  ) : (
                    <EmptyState />
                  )}
                </TabsContent>

                {/* DIAGNOSTICS */}
                <TabsContent value="diagnostics" className="mt-0">
                  <div className="space-y-5">
                    {hasResult ? (
                      <DiagnosticsPanel
                        connection={result!.connection}
                        dns={result!.dns}
                        ping={result!.ping}
                      />
                    ) : (
                      <EmptyState />
                    )}
                    <ScheduledAutoTest
                      onRunTest={(quick) => speedTest.run(serverId, quick)}
                      isRunning={speedTest.running}
                    />
                  </div>
                </TabsContent>

                {/* HISTORY */}
                <TabsContent value="history" className="mt-0">
                  <div className="space-y-5">
                    <HistoryStats history={history} />
                    <HistoryPanel
                      history={history}
                      onClear={handleClearHistory}
                      onDelete={handleDelete}
                    />
                    <ResultsComparison history={history} />
                  </div>
                </TabsContent>

                {/* MONITOR */}
                <TabsContent value="monitor" className="mt-0">
                  <LiveMonitor />
                </TabsContent>

                {/* EXPORT */}
                <TabsContent value="export" className="mt-0">
                  <div className="space-y-5">
                    <ExportPanel result={result} />
                    <PdfReport result={result} />
                  </div>
                </TabsContent>
              </motion.div>
            </AnimatePresence>
          </Tabs>
        </section>

        {/* Server comparison strip */}
        <section className="mt-6">
          <div className="rounded-2xl border border-border/60 bg-card/70 p-5 backdrop-blur-xl sm:p-6">
            <div className="mb-4 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <ServerCog className="h-3.5 w-3.5" />
              Available Test Servers
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {SERVERS.map((s) => (
                <motion.button
                  key={s.id}
                  whileHover={!speedTest.running ? { y: -2, scale: 1.02 } : {}}
                  whileTap={!speedTest.running ? { scale: 0.98 } : {}}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  onClick={() => !speedTest.running && handleServerChange(s.id)}
                  disabled={speedTest.running}
                  className={`group relative flex items-center gap-3 overflow-hidden rounded-xl border p-3 text-left transition-colors ${
                    s.id === serverId
                      ? "border-emerald-500/50 bg-gradient-to-br from-emerald-500/10 to-teal-500/5"
                      : "border-border/60 bg-background/40 hover:border-border hover:bg-accent/40"
                  } ${speedTest.running ? "cursor-not-allowed opacity-60" : ""}`}
                >
                  {s.id === serverId && (
                    <motion.div
                      layoutId="server-active-glow"
                      className="absolute inset-0 -z-10 bg-gradient-to-br from-emerald-500/10 to-transparent"
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                  <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-lg transition-transform group-hover:scale-110 ${
                    s.id === serverId ? "bg-emerald-500/15" : "bg-muted"
                  }`}>
                    {s.flag}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-semibold">{s.name}</div>
                    <div className="truncate text-xs text-muted-foreground">
                      {s.location}
                    </div>
                  </div>
                  {s.id === serverId ? (
                    <Badge className="gap-1 bg-emerald-500 text-white shadow-sm shadow-emerald-500/30">
                      <span className="h-1.5 w-1.5 rounded-full bg-white" />
                      Active
                    </Badge>
                  ) : (
                    <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground/60 opacity-0 transition-opacity group-hover:opacity-100">
                      Select
                    </span>
                  )}
                </motion.button>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <HowItWorks
            step="01"
            icon={<Wifi className="h-5 w-5" />}
            title="Multi-metric ping"
            desc="18 ping samples measure latency, jitter & packet loss — not just one round trip."
          />
          <HowItWorks
            step="02"
            icon={<Download className="h-5 w-5" />}
            title="Streaming download"
            desc="Adaptive chunked downloads with real-time throughput sampling every 200ms."
          />
          <HowItWorks
            step="03"
            icon={<Zap className="h-5 w-5" />}
            title="Bufferbloat"
            desc="Measures latency under load — a key metric speedtest.net hides from you."
          />
          <HowItWorks
            step="04"
            icon={<Shield className="h-5 w-5" />}
            title="Composite NQS"
            desc="A weighted Network Quality Score combining 6 dimensions into one grade."
          />
        </section>
          </>
        )}
      </main>

      {/* Footer (sticky to bottom) */}
      <footer className="mt-auto border-t border-border/40 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-5 text-xs text-muted-foreground sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <GaugeIcon className="h-3.5 w-3.5 text-emerald-500" />
            <span>
              <span className="font-semibold text-foreground">{tt("app.title")}</span> — {tt("footer.tagline")}
            </span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <span className="flex items-center gap-1.5 rounded-md border border-border/40 bg-card/40 px-2 py-1">
              <kbd className="rounded bg-muted px-1.5 py-0.5 font-mono text-[10px] font-semibold text-foreground">Space</kbd>
              <span className="text-[10px]">{tt("footer.startStop")}</span>
            </span>
            <span className="flex items-center gap-1.5 rounded-md border border-border/40 bg-card/40 px-2 py-1">
              <kbd className="rounded bg-muted px-1.5 py-0.5 font-mono text-[10px] font-semibold text-foreground">1-0</kbd>
              <span className="text-[10px]">{tt("footer.switchTabs")}</span>
            </span>
            <span className="flex items-center gap-1">
              <Globe className="h-3 w-3" /> Edge
            </span>
            <span className="flex items-center gap-1">
              <Timer className="h-3 w-3" /> {new Date().getFullYear()}
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function MiniStat({
  icon,
  label,
  value,
  unit,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit: string;
  color: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="group rounded-xl border border-border/60 bg-background/40 p-3 text-center transition-colors hover:border-border hover:bg-background/70"
    >
      <div className="flex items-center justify-center gap-1 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        <span className={`transition-transform group-hover:scale-110 ${color}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-1 text-lg font-bold tabular-nums sm:text-xl">{value}</div>
      {unit && (
        <div className="text-[10px] text-muted-foreground">{unit}</div>
      )}
    </motion.div>
  );
}

function FeatureChip({
  icon,
  label,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  color: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={`flex items-center gap-2.5 rounded-xl border border-border/60 bg-gradient-to-br ${color} p-3 backdrop-blur`}
    >
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-background/60">
        {icon}
      </div>
      <span className="text-xs font-semibold leading-tight">{label}</span>
    </motion.div>
  );
}

function EmptyState() {
  return (
    <div className="flex min-h-[280px] flex-col items-center justify-center rounded-2xl border border-dashed border-border/60 bg-card/40 p-8 text-center">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 15 }}
        className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/10"
      >
        <GaugeIcon className="h-7 w-7 text-emerald-500" />
      </motion.div>
      <h3 className="text-base font-semibold">No results yet</h3>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">
        Run a test to see your Network Quality Score, streaming capabilities,
        gaming grades, VoIP quality, DNS resolution times and full diagnostics.
      </p>
    </div>
  );
}

function HowItWorks({
  step,
  icon,
  title,
  desc,
}: {
  step: string;
  icon: React.ReactNode;
  title: string;
  desc: string;
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border/60 bg-card/70 p-5 backdrop-blur-xl">
      <div className="absolute right-3 top-2 text-3xl font-black text-muted-foreground/10">
        {step}
      </div>
      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-500">
        {icon}
      </div>
      <h4 className="text-sm font-semibold">{title}</h4>
      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{desc}</p>
    </div>
  );
}
