// Server info endpoint — returns basic identifying info (no PII).
import { headers as nextHeaders } from "next/headers";

export const runtime = "nodejs";

export async function GET() {
  const h = await nextHeaders();
  const ip =
    h.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    h.get("x-real-ip") ||
    "unknown";
  const userAgent = h.get("user-agent") ?? "unknown";

  return new Response(
    JSON.stringify({
      ok: true,
      serverTime: Date.now(),
      ip,
      userAgent,
      region: h.get("x-vercel-ip-country") ?? undefined,
      city: h.get("x-vercel-ip-city") ?? undefined,
      note: "Z.ai speed test edge node",
    }),
    {
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
        "Access-Control-Allow-Origin": "*",
      },
    }
  );
}

export async function OPTIONS() {
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "*",
    },
  });
}
