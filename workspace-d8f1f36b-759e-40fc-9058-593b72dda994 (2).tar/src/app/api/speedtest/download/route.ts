// Download endpoint — streams a configurable number of random bytes.
// Used by the speed test to measure downstream throughput.
// Supports CORS so external tabs can also hit it.

export const runtime = "nodejs";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const bytesParam = url.searchParams.get("bytes");
  const bytes = Math.min(
    256 * 1024 * 1024, // 256MB cap per request
    Math.max(1024, parseInt(bytesParam ?? "1048576", 10) || 1048576)
  );

  // We build the payload once (random-ish, no compression benefit) and stream
  // it in chunks so backpressure works correctly.
  const chunkSize = 256 * 1024;
  const fullChunks = Math.floor(bytes / chunkSize);
  const remainder = bytes % chunkSize;
  const chunk = Buffer.allocUnsafe(chunkSize);
  // fill with pseudo-random data so gzip won't deflate it (we send identity)
  for (let i = 0; i < chunkSize; i++) chunk[i] = (i * 31 + 17) & 0xff;

  const headers = new Headers({
    "Content-Type": "application/octet-stream",
    "Content-Length": String(bytes),
    "Cache-Control": "no-store, no-cache, must-revalidate",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "*",
    "X-Speedtest-Download": "1",
  });

  const stream = new ReadableStream({
    async start(controller) {
      // Safety: hard cap how long a single request may run (30s). If the client
      // disconnects without aborting cleanly, this ensures the stream is closed
      // and the server doesn't hold the connection open indefinitely.
      const startedAt = Date.now();
      const MAX_STREAM_MS = 30_000;
      let timedOut = false;
      const watchdog = setTimeout(() => {
        timedOut = true;
        try {
          controller.error(new Error("stream timeout"));
        } catch {
          /* already closed */
        }
      }, MAX_STREAM_MS);

      const onClose = () => {
        clearTimeout(watchdog);
      };
      // Best-effort: detect client cancellation via the request signal.
      request.signal.addEventListener("abort", onClose, { once: true });

      try {
        for (let i = 0; i < fullChunks; i++) {
          if (timedOut || Date.now() - startedAt > MAX_STREAM_MS) break;
          controller.enqueue(chunk.slice(0));
          // yield to the event loop occasionally for fairness
          if (i % 16 === 0) await new Promise((r) => setTimeout(r, 0));
        }
        if (!timedOut && remainder > 0) {
          controller.enqueue(chunk.slice(0, remainder));
        }
      } finally {
        clearTimeout(watchdog);
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
    cancel() {
      // client cancelled the stream — release any resources here
    },
  });

  return new Response(stream, { headers });
}

export async function OPTIONS() {
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "*",
    },
  });
}
