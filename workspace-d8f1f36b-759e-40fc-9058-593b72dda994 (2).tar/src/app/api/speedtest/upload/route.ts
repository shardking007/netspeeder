// Upload endpoint — accepts a POST body of arbitrary size and discards it.
// Used by the speed test to measure upstream throughput.

export const runtime = "nodejs";

export async function POST(request: Request) {
  // Drain the body fully so the full upload is measured.
  // We don't store anything — just consume the stream.
  const contentLength = request.headers.get("content-length");
  let received = 0;
  const reader = request.body?.getReader();
  if (reader) {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value?.byteLength ?? 0;
    }
  } else {
    // fallback
    await request.arrayBuffer();
    received = contentLength ? parseInt(contentLength, 10) : 0;
  }

  return new Response(
    JSON.stringify({ ok: true, bytes: received }),
    {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "*",
        "Cache-Control": "no-store",
      },
    }
  );
}

export async function OPTIONS() {
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "*",
    },
  });
}
