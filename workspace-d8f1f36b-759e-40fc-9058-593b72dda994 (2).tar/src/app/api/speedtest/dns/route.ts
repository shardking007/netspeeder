// DNS resolver endpoint — proxies a DNS-over-HTTPS lookup so the client can
// measure resolution timing without CORS issues.

export const runtime = "nodejs";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const domain = url.searchParams.get("domain") ?? "example.com";
  const type = url.searchParams.get("type") ?? "A";
  const start = Date.now();

  try {
    const upstream = `https://1.1.1.1/dns-query?name=${encodeURIComponent(
      domain
    )}&type=${type}`;
    const res = await fetch(upstream, {
      headers: { Accept: "application/dns-json" },
      cache: "no-store",
    });
    const data = await res.json();
    const elapsed = Date.now() - start;
    return new Response(
      JSON.stringify({
        ok: true,
        domain,
        type,
        elapsedMs: elapsed,
        answers: data.Answer ?? [],
        status: data.Status,
      }),
      {
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-store",
          "Access-Control-Allow-Origin": "*",
        },
      }
    );
  } catch (e) {
    return new Response(
      JSON.stringify({
        ok: false,
        domain,
        error: e instanceof Error ? e.message : "unknown",
        elapsedMs: Date.now() - start,
      }),
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      }
    );
  }
}

export async function OPTIONS() {
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "*",
    },
  });
}
